# Changelog

## Unreleased fork changes

- Keep Operator audit reads and writes under an explicit `HERMES_HOME`, so a
  separate profile does not use another installation's logs or write into the
  program directory. Existing logs are retained without automatic migration.
- Preserve the Windows fork's hidden Operator subprocesses and bounded timeout
  cleanup. If descendant pipes remain open after cleanup, return an explicit
  unverified-cleanup error rather than waiting indefinitely on a pipe reader.
- Read UTF-8 attention-spool fixtures explicitly in budget-enforcement tests on
  non-UTF-8 Windows locales.
- Allow explicit Agent source selection through `HERMES_AGENT_ROOT`, separate
  from `HERMES_HOME` data/profile storage. Invalid overrides and unavailable
  required imports prevent startup instead of selecting an older installation.

## 0.18.0 — Agent readiness and compatibility

- Add read-only Flight Deck Agent readiness: separate server source and CLI identity, static protocol declarations, prior authorized preflight observations, session-control gate state, and an explicit unverified live-acceptance boundary. No Agent code execution, turn submission or configuration changes.
- Bound the existing session-control execution path's help probe by time and output size; failures and uncertain observations refuse submission. Raw help, errors and private paths are not exposed by readiness.
- Support the public `find_all_skills` Agent API with legacy `_find_all_skills` fallback. Keep explicit `skill_view(..., preprocess=False)` authoritative and fail closed if the loader is unavailable.
- Exercise both exact modern and legacy Agent source revisions in CI. These are loader compatibility tests, not certification of a full Agent installation.
- Preserve the default 139-tool MCP inventory (140 with Finance), schemas and all existing authority gates.

## 0.17.0 — Daily Operations

- Add optional stable `request_id` to Mission launch. Commit durable intent before effects, checkpoint completed steps, reject changed payloads, and return the original receipt on replay without redispatch.
- Add Flight Deck New Mission with bounded defaults, explicit budget omission, preview/confirm, and receipt-only recovery after disconnect.
- Link pending contract reviews from the Owner inbox to exact contract/task/delegation evidence. Refuse stale bindings and executing reviewers; retain Owner authorization and separate reconciliation/final approval.
- Add read-only delivery health with masked targets, pending counts, backoff, and `SENT_UNVERIFIED` disclosure. Agent compatibility is explicitly not probed by this page.
- Preserve default tool counts and gates. Launch's additive schema change requires client action/schema refresh. Receipt retention is capped at 10,000 with no automatic expiry.

## 0.16.2 - 2026-10-29

- Session continuation uses a finite, non-auto-approving stream-json CLI turn. Completion requires a matching terminal result and zero exit code. Durable reservations prevent duplicate submission after ambiguous outcomes; bounded parsing excludes tool event bodies from persisted results. Unsupported CLIs are refused before submission. Live Desktop acceptance is not yet certified.
- Publish the exact wheel and sdist validated by CI instead of rebuilding during upload. Tag/version mismatch refuses publication.
- Correct current release documentation and tool counts.

- Autopilot records why a run ended (`max_runtime_exceeded`, or the crash reason) before it terminalizes the job. A status read in between could reconcile the run to `failed` with no `last_error`; this was an intermittent CI failure in `test_real_worker_ends_a_run_that_is_out_of_time_with_nothing_in_flight`.

## 0.16.1 - 2026-10-22

- Flight Deck reject works on a reached gate in any state that may fail, including the `pending` state Autopilot leaves it in. An unreached gate is still refused. The owner inbox now suggests `hermes_plan_approve_gate` for Autopilot gates.
- Attention delivery: iMessage sends that `imsg` cannot confirm (`retry_safe: false` / "Delivery outcome unknown") or that time out after the request was written are recorded as delivered, flagged `SENT_UNVERIFIED` in `last_warning`, and never resent. Previously each relay pass would have resent them, duplicating messages that had already arrived. Found in the first live iMessage test.
- Added `hermes_plan_approve_gate`, an Owner-only way to approve a gated plan node (an approval node or `high_impact`) to `completed` in one call. Before, approving a gate took six separate `hermes_plan_node_transition` calls, and the Flight Deck's **Approve node** was refused for a `pending` gate. The tool computes the shortest legal path from `NODE_TRANSITIONS`, applies it one step at a time through the existing transition with a plan-version compare-and-swap, and dry-runs by default. Intermediate states are ordinary state-machine steps and do not claim that review happened. A refused step stops the walk with no rollback, and the result lists the applied steps. The Flight Deck approve now uses this tool, and the browser transition is reject-only. The tool count is 139 with every optional gate unset and 140 with `HERMES_GPT_ENABLE_FINANCE=1`. See [docs/owner-inbox.md](docs/owner-inbox.md#owner-gate-approval-hermes_plan_approve_gate).

## 0.16.0 - 2026-10-21

Close the loop: what waits on the Owner now reaches them and can be resolved in one place, with no new authority.

- Added the default-off attention delivery relay. It sends new Owner inbox items as short notifications to administrator-configured targets (`HERMES_GPT_ATTENTION_TARGETS`, up to 8 `backend:target` entries). The `hermes` backend runs `hermes send` and reuses the platforms already configured in Hermes Agent; the doc's examples are telegram, discord, slack, and signal. The `imessage` backend sends through `imsg rpc`. The relay adds per-item dedupe, one digest per target when many items are new, per-target exponential backoff, and a minimal child environment, and it holds no platform credentials. It never approves, advances, or replies. Run it as `python -m operator_attention_delivery` or the `hermes-gpt-attention-relay` console script. See [docs/attention-delivery.md](docs/attention-delivery.md).
- Added the read-only `hermes_attention_delivery_status` tool, registered only with `HERMES_GPT_ATTENTION_DELIVERY=1`. It reports the relay's state and sends nothing.
- Added a Work Contract review source to the Owner inbox. A successful delegation whose contract still needs review acceptance appears as `contract_review_pending`. Inbox items now carry stable `item_id`s derived from the item kind, Mission, and a timestamp-free key, so an id does not change when nothing changed.
- Added acknowledgements and `hermes_owner_inbox_ack`. It is always registered, requires workspace level and direct apply mode for a write, and is dry run by default. An acknowledgement hides an item from the inbox and from the relay. It never approves or changes a Mission, plan, Work Contract, or delegation.
- Added Flight Deck inbox actions: Approve Mission, approve or reject an approval-frontier node, Stop Autopilot, and Acknowledge. Each calls the existing gated tool through `POST /api/ops/action`, with a dry-run request before the confirm. Browser node transitions require Owner mode and are limited to approval and `high_impact` nodes. See [docs/owner-inbox.md](docs/owner-inbox.md#flight-deck-actions).
- Security: `POST /api/ops/action` refuses cross-site requests. A non-JSON body returns `415 UNSUPPORTED_MEDIA_TYPE`, and a foreign `Sec-Fetch-Site` or `Origin` returns `403 CROSS_SITE_REFUSED`. These checks apply on loopback too and do not replace the Operator gates. See [UI security boundary](docs/ui-security-boundary.md#6-mutations-remain-auditable-and-gated).
- Added `hermes_mission_launch`, a one-call launch that creates a Mission, derives its plan, optionally sets a budget, and starts Autopilot. It is registered only with `HERMES_GPT_AUTOPILOT=1`, is dry run by default, requires `confirm=true` to apply, stops at the first refusal, and never approves a Mission. Finding: a Mission with no budget envelope is not held by the budget gate. Only a crossed, invalid, or unreadable envelope holds dispatch. See [docs/autopilot.md](docs/autopilot.md#one-call-launch-v016).
- Added `hermes-gpt update --apply --version X.Y.Z` for a safe package-installed upgrade inside one named virtual environment. It verifies the wheel digest, refuses downgrades, snapshots the previous wheel, checks the import, and rolls back on failure. See [docs/updating.md](docs/updating.md).
- Fixed contract review. The validator and the owner inbox now read the whole review-acceptance store, so a late acceptance counts. Previously a busy store could leave a contract unsatisfied after 200 acceptances. `read_review_acceptances`, the Flight Deck recent-records list, now returns the newest records.
- Fixed the `hermes_owner_inbox` MCP tool, whose success path failed because of a positional argument.
- Added an SDK-neutral `wire` fixture in `conftest.py`. It returns MCP objects in protocol alias form, so tests assert on names such as `readOnlyHint` and do not depend on SDK attribute names.
- Tool registration is now declared as per-subsystem tables (behavior-neutral).
- Tool count: 138 tools with every optional gate unset. The connector acceptance surface, which sets `HERMES_GPT_ENABLE_FINANCE=1`, has 139. `HERMES_GPT_AUTOPILOT=1` adds 4 (the three Autopilot tools and `hermes_mission_launch`), `HERMES_GPT_ATTENTION_DELIVERY=1` adds 1, `HERMES_GPT_ENABLE_JEV=1` adds 3, and `hermes_review_assess` adds 1 more when both `HERMES_GPT_ENABLE_JEV=1` and `HERMES_GPT_REVIEW_ASSIST=1` are set.

## 0.15.0 - 2026-10-21

Owner Loop: faster Owner decisions without new authority.

- Added the read-only `hermes_owner_inbox` tool (always registered) and the Flight Deck read-only route `GET /api/ops/owner-inbox` with a read-only Owner inbox panel linked from the Deck overview. It lists Missions awaiting approval, Autopilot runs waiting for the Owner, and controller attention, with source health (`complete`) and suggested existing tools. It never approves, advances, or writes. See [docs/owner-inbox.md](docs/owner-inbox.md).
- Added advisory review assist: `hermes_review_assess` scores a dispatched Work Contract through the pinned Jev adapter. It is registered only with `HERMES_GPT_ENABLE_JEV=1` and `HERMES_GPT_REVIEW_ASSIST=1`, requires the `read_only` Operator level, is advisory only, is never Work Contract evidence or review acceptance, and writes an audit record without a `task_id`. See [docs/review-assist.md](docs/review-assist.md).
- Added `HERMES_GPT_TOOL_PROFILE` connector tool profiles (`full` default, `operator`, `chat-lean`). Profiles only remove tools; invalid values fail closed. See [docs/mcp-compatibility.md](docs/mcp-compatibility.md#connector-tool-profiles).
- Made file backups configurable and safer: `HERMES_GPT_OPERATOR_FILE_BACKUPS` disables backups only for `0`, `false`, `no`, `off`, or `disabled` (case-insensitive). Unset, empty, or unrecognized values keep backups on. Thanks to @brunocasado for #85.
- Added the default-off Jev decision bridge, with three tools reusing the pinned community `jev-mcp` adapter. See [docs/jev.md](docs/jev.md).
- Docs hygiene (#94): corrected the default main-server inventory and source UI build instructions, replaced host-specific runtime notes with a generic provenance guide, and clarified unreleased-source versus package/runtime state.
- Tool count: the default connector surface is 138 tools (137 in v0.14.0, plus `hermes_owner_inbox`). `HERMES_GPT_AUTOPILOT=1` adds 3 tools, `HERMES_GPT_ENABLE_JEV=1` adds 3, and `hermes_review_assess` adds 1 more when both Jev and review-assist gates are set.

## 0.14.0 - 2026-10-03

Acceptance and recovery: declare deliverable checks before dispatch and recover from positively observed artifact failures within existing limits.

- MissionPlan nodes can specify optional `artifact_requirements` for existing artifact basenames: positive `min_bytes`, optional `max_bytes`, and optional lowercase `sha256`. Requirements participate in the node signature, survive bounded rework unchanged, and flow into each attempt's Work Contract. Existing nodes/contracts retain their prior canonical hashes when optional fields are absent.
- Work Contracts enforce size bounds and expected hashes against local files or contract-bound coordinator-verified remote artifact metadata. Local hash reads are binary, bounded to 8 MiB, reject changing/nonregular files, and fail closed on unreadable evidence.
- Delegations persist bounded validation check enums and a restart-safe 30-second artifact delivery grace. Successful execution with confirmed bad artifacts and all other required checks passing becomes `failed` with outcome `validation_failed` after grace; Autopilot can use its existing bounded semantic replan path. Missing run observations, pending review, denied authority, cancellation ambiguity, and unreadable artifacts never trigger this recovery.
- Flight Deck explains per-attempt completion checks, artifact failure reasons, delivery grace, and pending validation without adding browser mutation actions. Completed/failed task evidence stays visible when its current lineage can be resolved.
- No new MCP tools, no default gate changes, and no approval bypass. Autopilot remains default off and final Mission approval remains Owner-only.

## 0.13.0 - 2026-10-03

- Release hardening: enforce required nonempty node artifacts in isolated attempt workspaces; prevent plan replacement from orphaning unfinished work; preserve bounded, classifier-approved recovery during independent Mission reconciliation without hiding failed evidence.
- Flight Deck now renders Autopilot progress, workers, budgets, recovery limits, and owner attention; release packages include the built browser assets. CI exercises the Python/MCP matrix on Windows and Linux.
- Windows process observation leaves terminal publication unblocked; durable state handles transient file-sharing contention and fails closed on persistent read denial. Pi RPC pipe reading is portable and enforces timeouts even for partial JSONL lines.

Autopilot: one durable, default-off runtime that drives a Mission through its MissionPlan without a human re-triggering every node, and never crosses an approval boundary. It is a caller of the existing Mission, plan, placement, Work Contract, delegation, budget, and live-event surfaces, not a new authority. See [docs/autopilot.md](docs/autopilot.md).

- Added `hermes_autopilot_start` / `hermes_autopilot_status` / `hermes_autopilot_stop`, registered only when `HERMES_GPT_AUTOPILOT=1` (default off), so the default connector surface is unchanged at 137 tools and is 140 with the gate set. Start is dry-run first and needs `workspace` level, direct mode, and `confirm=true`; stop is never gated behind the machine gate. A detached worker process (via the durable job supervisor) owns one Mission at a time and survives an MCP server restart, with status re-verified on every read rather than trusted from a cache.
- Parallel scheduling: up to `max_concurrency` ready nodes run at once, dispatched only through the existing placement, contract, and delegation chain (no new dispatch path). Dispatch is idempotent with deterministic task and delegation ids, a crash between dispatch and the node update is adopted rather than redispatched, and controller-dispatched work is adopted rather than duplicated. Plan writes are compare-and-swap on the plan version (`hermes_plan_node_transition` gains an optional `expected_plan_version`).
- Automatic node advancement: nodes complete only when `hermes_delegation_reconcile` validates the Work Contract `SATISFIED` against observed state with evidence bound to the contract hash; a worker's own success claim is never accepted, and missing evidence fails closed.
- Approval frontier: approval nodes and `high_impact` nodes are never dispatched or advanced. Autopilot reports `waiting_for_owner` and dispatches nothing past that node while independent branches continue. It never approves or completes a Mission; once every node is done it calls the existing Mission reconcile, which stops at `awaiting_approval`, and only `hermes_mission_approve` in Owner mode completes it.
- Bounded recovery driven by the existing failure classifier: transient failures are retried with backoff on an alternate peer, semantic failures with an eligible proposal are replanned through a rework clone (the failed node is kept as history; completed nodes, authorization classes, and approval nodes are never touched), and every other class fails the node for a human. New `bump_retries` option on `hermes_plan_node_transition`, plus an internal guarded rework patch.
- Mission model change: a failed or cancelled delegation attempt can be marked superseded by its successor (`superseded_by:<id>` on the attachment relationship) so a successful retry no longer leaves the Mission failed. It is written only by an internal bridge, refused by public `hermes_mission_attach`, honored only while the old attempt is authoritatively failed or cancelled, and ignored when forged, dangling, or cyclic. Approval rules are unchanged. See [docs/missions.md](docs/missions.md).
- Mission limits: `max_attempts_per_node`, `max_runtime_seconds`, `max_concurrency`, and `max_replans` are validated at start. New dispatch is held whenever the budget envelope is not verifiably within its limit, independent of whether the budget hard-block gates are armed; an invalid or unreadable envelope also holds. An expired runtime stops new work, drains what is in flight, and ends the run.
- Event-driven wakeups: the worker long-polls the Mission's live events with a periodic backstop (`HERMES_GPT_AUTOPILOT_IDLE_SECONDS`, default 2.0). Events only end a wait early and are never treated as proof; a broken event store degrades to the timer; ticks are debounced. A cancel that arrives before the worker has registered its process identity is noticed within a second.
- `hermes_autopilot_status` gains an additive, read-only `summary` (progress, workers, the approval frontier, budget, recovery counters, limits, wake-up counters, and an `attention` list with `needs_owner`); every earlier key is unchanged. A status read never enforces a budget.
- Flight Deck: read-only `GET /api/ops/missions/{mission_id}/autopilot`. It writes nothing (unlike the status tool it does not heal the stored record), reports a dead worker as stale, and returns an allow-listed projection only. See [docs/flight-deck-missions.md](docs/flight-deck-missions.md).
- An end-to-end acceptance test runs the whole scenario with a real detached worker: parallel nodes on two placements, a killed peer with a reroute and no duplicate attempt, an approval stop and resume, the owner's final approval in a separate process, and the same run again with the MCP server restarted mid-Mission.
- `operator_autopilot` is now included in the built wheel and sdist (it was missing from the module list).
- Profile-aware skill validation probes the Hermes Agent explicit-load path with `skill_view(..., preprocess=False)`, so a pre-dispatch gate cannot execute `skills.inline_shell` snippets. Linux CI now checks out Hermes Agent so the real-loader integration tests run instead of skipping.

## 0.12.0 - 2026-09-22

- Added the budget D3 hard-block ENFORCEMENT path (v0.12 slice-2, design `docs/design/v0.12-budget-enforcement.md`): `operator_mission_budget.enforce_budget_breaker` executes the on-crossing action set — pause the Mission via the existing transition (reason `budget_breaker`), one fleet-attention INTERRUPT envelope through the existing controller attention spool, one `budget_events` `break` row — behind a fail-closed gate set that is DEFAULT OFF: per-call `confirm`, machine gate `HERMES_GPT_BUDGET_HARD_BLOCK=1`, Operator enabled + `direct` apply mode, and per-mission `hard_block_enabled` + `pause_on_cross` policy flags. INV-11 anti-TOCTOU re-snapshot, idempotent repeat (`already_enforced`, one spool entry max), not-pausable fail-closed `need_attention`, INV-9 bounded fields, and INV-10 loud spool failures are tested. `hermes_budget_check` gains keyword-only `enforce`/`confirm` (default `enforce=False` is byte-identical to the previous dry-run surface; the MCP tool signature is unchanged), and the controller reconcile pass records a `budget_enforcement` outcome only when the machine gate is armed — otherwise pass output is byte-identical and nothing is written. Connector surface stays at 137 tools.
- Added the controller L2-rung execution engine + placement-informed dispatch (v0.12 slice-2, design `docs/design/v0.12-controller-l2.md`): when AND ONLY when the per-call `confirm`, the machine gate `HERMES_GPT_CONTROLLER_EXECUTE=1`, and live Operator policy (enabled + `direct` apply mode + `workspace` level) all hold, a reconcile pass EXECUTES its single smallest recovery action — a placement-scored dispatch through the existing work-contract/delegation authority surface, idempotency-keyed, at most one action per pass, with a pre-dispatch intent record so a crash reconciles fail-closed instead of re-dispatching. Every other combination stays decision-only and returns an additive `execution` block naming a stable refusal reason (`confirm_required`, `operator_policy_required`, `workspace_required`, `dry_run`, `no_action`, `not_executable_attention`, `unsupported_action`, `already_executed`, `no_capable_target`, `authorization_class_not_supported`, `approval_gate`, `secret_like_requirement`). All §7.7 prohibitions are retained and tested: the rung never completes, approves, weakens evidence, auto-redispatchs `reconciling` work, rewrites a plan, retries unboundedly, places without authority, or touches secrets — `no_capable_target` still escalates through the existing attention spool, and high-impact authorization classes keep their human gate. `would_assign` in the new `operator_placement.dispatch_view` is `true` only for a dispatch that actually happened (scoring surfaces are unchanged). `hermes_controller_reconcile` gains a `confirm` parameter (default `False`), `hermes_controller_status` reports `execution_enabled` plus an `executions` rollup, and the existing `controller_plan`/`controller_telemetry` surfaces carry the execution ledger. The rung is DEFAULT OFF: with the machine gate unset the pass envelope is byte-identical to the previous release (same 31 keys, no `execution` member, `would_execute` False), `dry_run=True` stays a byte-identical zero-write preview, and the only durable change is four additive execution-ledger columns on `controller_telemetry` (`executed_idempotency_key`/`executed_result`/`executed_target`/`executed_refused_reason`) that stay empty unless an execution is attempted. Connector surface stays at 137 tools.
## 0.11.0 - 2026-09-21

- Support MCP Python SDK 2.x alongside 1.28.1+, preserving local stdio, HTTP/SSE transport settings, authentication and Operator gates.
- Correct the Codex Operator aliases' return signatures to describe normalized results, avoiding SDK 2 output-validation failures.
- Test both SDK families and minimum versions in CI, with wire-level negotiation and result assertions.
- Added an opt-in Gemini Spark client profile for Google's consumer Gemini Apps "Custom apps for Spark" connector: an additional registered confidential OAuth client (`HERMES_GPT_OAUTH_GEMINI_ENABLE=1` plus `HERMES_GPT_OAUTH_GEMINI_CLIENT_ID` / `_CLIENT_SECRET` / `_REDIRECT_URI`) isolated from the primary client with its own secret and exact-match redirect allowlist; enabling it without complete configuration fails startup validation. Setup guide: `docs/gemini-spark.md`.
- Made MCP session history and control profile-aware and added canonical Bot Chat delivery: session tools resolve the selected Hermes profile home (validated against the operator policy allowlist), pass profile home + identity to Hermes, and key concurrency by profile + session ID; `hermes_bot_chat_get` / `hermes_bot_chat_send` deliver the canonical Bot Chat directly.
- Made the cross-process token-store lock portable on Windows (msvcrt one-byte region locking) while retaining flock on POSIX.
- Security and reliability remediation (post-v0.10 independent review): signed OAuth access tokens now require durable-store presence; revocation retires tokens and advances a durable epoch in one SQLite transaction; atomic refresh rotation; controller reconcile/trigger persistence gated behind workspace + direct apply mode; ledger pagination with per-source watermark cursors; PyYAML promoted to a runtime dependency; plan readiness requires every declared parent to exist and be completed; controller observation binds to the frontier node's contract hash.
- Fleet: generic loopback Agent Card (`/.well-known/agent-card.json`) plus admission of unknown manifest peers at the lowest profile ceiling (default only), so freshly enrolled machines validate without a code change. Profile-ceiling enforcement is unchanged.
- Fixed `hermes_operator_doctor` and mission diagnostics to handle a JSON `gateway.pid` (supersedes #62; reuses the shared gateway-PID reader and hardens it against undecodable JSON bytes).

## 0.10.0 - 2026-09-07

vNext slice-1 derived mission views and the supervised mission controller (shadow): deterministic MissionPlan decomposition, read-only capability-manifest and mission-ledger views, a dry-run budget envelope, dry-run placement scoring, semantic failure classification with a smallest-first recovery matrix, and a shadow/observe controller reconciler — all additive and decision-only, preserving the existing read-only/dry-run, read-only, and shadow authority ladder. This slice adds ~27 new MCP tools; none of them can mutate a Mission, dispatch work, or approve anything in this release.

- Added the `hermes_plan_*` MissionPlan surface (`hermes_plan_create/get/list/validate/decompose/review/node_transition/set_status`): a deterministic, bounded decomposition DAG over a `MissionSpec`. Plan create/node-transition/set-status are additive to an isolated plan store and read-only with respect to the Mission lifecycle; get/list/review/validate/decompose are read-only. The DAG is validated through a state machine with dry-run-first mutation defaults.
- Added read-only derived capability-manifest and mission-ledger views (`hermes_capability_manifest`, `hermes_mission_ledger`, `hermes_mission_ledger_replay`): the manifest folds the Fabric node registry, Fleet authority manifest, profile toolsets/skills, and provider manifests into a single queryable capability index; the ledger is a merged, replayable, cursor-paginated per-mission event timeline. Both carry explicit `readOnlyHint`, enforce a per-client source allowlist, audit every call, and expose no mutation path.
- Added the mission budget envelope (`hermes_budget_set/get/check/record`): a per-mission spend envelope (`budget_accounts`) and a read-only `budget_check` evaluation surface, enforced dry-run-first. The D3 hard-block path (pause Mission + `budget_breaker` signal) is designed but flag-default-off and wired for a later slice.
- Added deterministic placement scoring (`hermes_placement_score/candidates/get/list`): filter-and-score over the derived capability-manifest index (hard filters then soft scores), decision output only — `would_assign` is always `False`, no assignment executes, and actual dispatch remains on the existing contract/fleet/delegation authority surfaces.
- Added semantic failure classification and the recovery matrix (`hermes_failure_classify`, `hermes_failure_taxonomy`, `hermes_recovery_matrix`, `hermes_controller_plan_list`): the Ops 8-class taxonomy classifies an authoritative observation envelope and proposes the deterministic smallest-first recovery action; decision output only, `would_execute` always `False`, and the sole durable write is a `controller_plan` row.
- Added the supervised mission controller shadow loop (`hermes_controller_reconcile/status/lease_list/trigger`): a T1–T5 trigger model, per-mission pass lease (TTL-heartbeat-renewed, crash-reclaimed, conflated), and a single shadow `reconcile` pass that observes authoritative mission/plan/delegation/runner state, classifies it, and emits the smallest recovery action as a proposal. It never dispatches, completes, or approves; its only durable writes are `controller_plan`, `controller_telemetry`, and the pass lease.
- Added controller telemetry/health (`controller_telemetry`, 24h-windowed aggregated counters with truthful stale-lease-reclaim accounting) tiered deterministically as GREEN / YELLOW / RED per pass plus a controller rollup; RED spools a fleet-attention `INTERRUPT` envelope to the existing delivery-broker lane (no self-send) and stale heartbeats are loud (INV-10).
- The vNext authority boundary ladder is preserved and documented: read-only surfaces remain read-only, mutating surfaces are dry-run-first, and the controller is a decision-only shadow in this slice (`would_execute`/`would_assign` always false, no deploy path).
- `serverInfo.version` continues to advertise the checkout version (`versioning.VERSION`) so MCP clients can detect stale processes; the connector surface acceptance gate now pins the merged v0.10.0 tool count (137) with no duplicate registration.

## 0.9.0 - 2026-08-24

First-class Missions, unified delegation lineage, durable live events, runner-neutral job supervision, and the bounded Finance bridge.

- Added the first-class durable Mission runtime: `hermes_mission_create/get/list/update/attach/reconcile/transition/approve` with bounded context/skills manifests, attachments, observed-state reconciliation, and Owner-gated final approval.
- Added the unified delegation lifecycle `hermes_delegation_dispatch/get/list/reconcile/cancel`: normalized durable lineage across runner/Fabric execution preserving underlying authority and dry-run gates.
- Added the durable v0.9 live-event surface `hermes_live_events_cursor`/`hermes_live_events_since` plus runner-neutral `hermes_job_status`/`hermes_job_wait` background-job polling contract.
- Fixed `hermes_cron_create` model serialization to match the Hermes Agent scheduler contract: `model_name` now persists as the string `model` field and `model_provider` as the sibling `provider` field (previously an invalid nested `model` dict).
- Fixed the MCP initialize handshake to advertise the app version (`serverInfo.version`) from `versioning.VERSION` instead of the SDK distribution version, so clients can detect stale processes.
- Fixed clustered ChatGPT MCP authentication: access tokens are now HMAC-signed so a bearer issued by one origin of `gpt.tonysimons.dev` is accepted by the other without a shared process-memory token table. Unauthenticated `/mcp` challenges advertise `resource_metadata`. Opaque legacy access tokens remain valid on the issuing origin until expiry.


- Added an opt-in `hermes_finance_analyze` bridge for the local `finance` profile. The bridge accepts bounded `finance.evidence/v1` JSON, rejects credential-like material, passes evidence over stdin to a fixed tool-free child, disables Hermes persistence/memory/background review for the turn, requires a matching `finance.decision/v1` response, and records only metadata hashes/lengths in Operator audit. The tool is disabled unless `HERMES_GPT_ENABLE_FINANCE=1`.

## 0.8.0 - 2026-08-21

Fabric: authenticated cross-machine Swarm execution with capability-aware routing, remote evidence/artifacts, reconciliation, and Flight Deck visibility.

- Added the packaged `hermes-gpt-fabric-peer` A2A/Fabric runtime for authenticated remote execution. Non-loopback serving requires direct TLS.
- Added durable node capabilities, health/freshness tracking, deterministic `execution.backend=auto` routing, explicit route exclusions, and authority-ceiling preservation.
- Added remote evidence collection and immutable artifact admission. Required missing/unavailable evidence fails closed, and admitted artifacts are hash-verified by the coordinator.
- Added restart/timeout/cancel reconciliation that preserves the original distributed attempt plus write-ownership/write-epoch guards for mutation-capable paths.
- Added read-only Flight Deck Fabric nodes, placement, attempts, evidence, and routing views, including truthful selected-route health/freshness/eligibility/authority fields.
- Completed fresh real two-machine G6 acceptance on final Fabric implementation target `4953c5f23db8d356365af8e18148e63d3c80125c`, including induced transport loss, same-attempt recovery, artifact re-hash, fail-closed validation, approval gating, and independent review.
- Known non-blocking presentation limitation: a completed reconciled attempt may retain a historical `FABRIC_TRANSPORT_TIMEOUT` as a current-looking Flight Deck blocker.
- Added `hermes_export_file`, a workspace-authorized MCP-native binary export surface with mandatory allowed-path confinement, denied-secret-path enforcement, symlink escape refusal, a 4 MiB default / 16 MiB hard size cap, optional extension allowlisting, safe audit metadata, and no base64 text fallback. Client attachment rendering remains client-controlled.
- Added a first-class OpenAI Secure MCP Tunnel deployment path for private ChatGPT/Codex/OpenAI access while Hermes GPT stays bound to loopback. Added a canonical guide, supervised Windows launcher, tunnel-aware status example, package wiring, and cross-links from the README, MCP compatibility, Cloudflare, and Windows Codex docs.
- Documented the tunnel security boundary: no public `HERMES_GPT_ALLOWED_HOSTS` entry is required for the private loopback path, static bearer remains optional defense in depth, and built-in OAuth still requires separately reachable browser-facing authorization-server endpoints.
- Pinned the MCP SDK to the FastMCP-compatible 1.x line (`mcp[cli]>=1.0,<2` in `requirements.txt`): mcp 2.x removes `mcp.server.fastmcp`, which breaks the server and test suite.
- Fixed A2A fleet dispatch timeouts losing track of submitted work: `hermes_fleet_dispatch` and `hermes_fleet_dispatch_work_order` now recover the peer-assigned task id by bounded context lookup and return a structured `FLEET_DISPATCH_TIMEOUT` error with `submission_may_have_succeeded: true` and a pollable `task_id`.
- Fixed `hermes-gpt mcp --http` (curated Codex MCP runner) trusting wildcard proxies: it no longer passes `forwarded_allow_ips="*"` to uvicorn, so proxy trust defaults to loopback-only or the operator-set `FORWARDED_ALLOW_IPS`, matching the main server's authenticated-posture proxy handling.
- Fixed OIDC discovery probing with OIDC disabled: `/.well-known/openid-configuration` is now served as a public 404 instead of an auth challenge, so ChatGPT connectors that probe OIDC discovery after OAuth no longer appear disconnected. No OpenID Provider is implemented.
- Fixed `hermes_operator_doctor` reporting gateway health from a heartbeat file alone: a heartbeat with no live gateway PID now fails closed with `GATEWAY_PID_MISSING` instead of `GATEWAY_OK`.
- Hardened Hermes Agent source-root detection: `is_hermes_root` now requires a regular `tools` package (`tools/__init__.py`) or a top-level `hermes_state.py`, so a stray namespace `tools/` directory at the Hermes data root can no longer masquerade as an agent source root and silently degrade the tool surface to read-only fallbacks.

## 0.7.0 - 2026-08-15

Flight Deck: durable, interactive, verifiable autonomy.

- Added the production review-accept writer `hermes_review_accept` (owner +
  direct + confirm) with distinct-reviewer enforcement at write time, bounded
  verdicts, referenced-not-copied evidence, and a durable append-only
  review-evidence store read by `hermes_contract_validate`.
- Added the structured event history surface `hermes_events_query` /
  `hermes_events_tail`: a read-only, redacted, bounded timeline over audit,
  swarm, codex, cron, and kanban stores with per-source allowlist
  (`HERMES_GPT_EVENTS_ALLOWED_SOURCES`) and retention window
  (`HERMES_GPT_EVENTS_MAX_AGE_DAYS`, default 90).
- Added durable encrypted token storage (ADR-001): OAuth access/refresh
  tokens persist through an AES-256-GCM envelope at
  `<hermes_data>/secrets/hermes_gpt_tokens.json` (0600) with keyring → key
  file → env key precedence; server restarts no longer invalidate issued
  credentials. Added `hermes_oauth_status` (read-only) and
  `hermes_oauth_revoke` (owner-gated, pending legal scope decision).
- Added restart reconciliation `hermes_swarm_reconcile`: marks swarm stages
  stuck in `running` as `blocked` (reason `interrupted_by_restart`), never
  auto-advances, and reloads the durable token envelope. `hermes_swarm_stage_advance`
  is now idempotent for already-validated/done stages.
- Added the MCP compatibility manifest (`docs/mcp-compatibility.md`) pinning
  the minimum supported protocol revision 2024-11-05 through the installed
  SDK's latest (2025-11-25), transport matrix, and auth metadata, with
  compatibility tests against the running SDK.
- Added cross-machine seam interfaces (`seams.py`: `DispatchAdapter`,
  `EvidenceProvider` protocols) validated by a two-process-one-host fake;
  no remote implementation is shipped (stretch).
- Promoted OAuth from Unreleased to shipped and documented: static bearer
  compatibility or a single-confidential-client OAuth authorization-code flow
  with optional PKCE S256, stateless signed authorization codes, one-hour
  access tokens, 30-day rotating refresh tokens with replay rejection,
  explicit direct-TLS or loopback trusted-proxy enforcement, and
  ChatGPT-compatible streamable-HTTP request normalization. Added the
  `cryptography` dependency (required) and `keyring` (optional dev).
- Fixed CI hermeticity: `_call_skill_manager` no longer fails when the Hermes
  Agent source tree is absent (optional-import degradation); profile-scoping
  tests skip only when `hermes_constants` is unavailable.
- Fixed explicit local-runner cancellation on Windows by routing durable worker
  PIDs through the same platform-aware process-tree cleanup used by timeout
  paths. A direct-process fallback now covers missing, timed-out, or failing
  `taskkill` invocations.

- Added explicit per-job Codex `execution_mode` with `normal` default and opt-in `nolo`. NOLO now uses Codex 0.147.0's `-a never` approval policy while retaining the requested read-only/workspace-write sandbox, Hermes approved-workspace, direct-mode, confirmation, audit, timeout, and redaction controls. The write gate is required only for `workspace-write`; NOLO expires with the job and does not create persistent global approval-bypass state.
- Added Codex parity for the four session-history capabilities that were previously available only through the full ChatGPT connector, delivered through the separately installed Hermes GPT Session History integration and verified with direct native-tool calls.
- Added a dedicated session-history guide covering client availability, privacy-preserving arguments, bounded Markdown export, optional read-only working-model inspection, and a no-write Codex smoke-test procedure.
- Added separately gated, bounded asynchronous Hermes session continue/send jobs with status and redacted result tools. Session IDs resolve through the existing read-only adapter; prompts are omitted from metadata; subprocesses use fixed arguments without a shell; timeouts and output are capped; restart reconciliation fails closed.
## 0.6.0 - 2026-08-13

- Added the v0.6 Mission Control, Work Contracts, and Swarm Orchestration surfaces with bounded, audited, fail-closed operator controls.
- Added conservative PII stripping for Mission Control free-text failure, audit, cron, and delegation fields; raw bodies remain excluded.
- Made Work Contract retry selection deterministic and scoped forbidden-action audit evidence to the contract task identity.
- Added documented retention and cleanup windows for request dumps, Codex artifacts, and swarm worktrees/workflow records.
- Documented the remaining fail-closed review-evidence limitation: v0.6 has no production review-accept writer.


- Fixed the Codex runner on Windows selecting a protected `WindowsApps`
  executable and failing with `WinError 5`. The runner now supports an explicit
  `HERMES_GPT_CODEX_EXE` override, validates that the chosen executable is a
  launchable regular file outside `WindowsApps` before use, and skips protected
  or unlaunchable PATH candidates. `hermes_codex_status` and `codex doctor`
  report `codex_path`/`codex_source` so availability is never claimed for an
  executable that cannot launch.
- Upgraded A2A fleet control with canonical structured work orders,
  server-controlled profile authority, explicit authorization classes, safe
  completion bundles, hardened bounded parsing, and read-only authority drift
  validation. Existing fleet tools retain registry-only routing, Operator Mode,
  confirmation, dry-run, hashing, redaction, secret-path, and end-of-options
  controls.
- Added bounded read-only session-history pagination that advances by database rows examined while filtering unsafe roles before client exposure.
- Added the gated `hermes_session_list`, `hermes_session_read`, and in-memory `hermes_session_export` tools alongside the existing plain-text `hermes_session_search` tool.
- Added JSON and Markdown export with `MAX_EXPORT_MESSAGES` and `MAX_RESPONSE_BYTES` limits; file creation, file paths, raw exports, and lineage export remain unavailable.
- Added explicit guidance for the `HERMES_GPT_ENABLE_SESSION_SEARCH=1` and `HERMES_GPT_ENABLE_SESSION_INTERNAL_CONTENT=1` gates, FTS availability limitations, default role filtering, and transcript privacy.

## 0.5.0 - 2026-07-10

- Completed the two-way Codex bridge: opt-in Operator toolsets for Codex and gated asynchronous Codex jobs for trusted Hermes GPT clients.
- Added core/operator connector installation, explicit refresh semantics, toolset-aware doctor checks, and shared runtime version discovery.
- Added Windows/Linux CI across Python 3.10-3.12, publish-after-test enforcement, package checks, and final v0.5.0 release notes.

- Added `hermes-gpt update`: check-first, safe fast-forward updates for clean Git checkouts and explicit pip upgrades for installed packages.
- Added update documentation and aligned the README, Codex guide, release notes, package data, and release checklist.

## 0.5.0b1 - 2026-07-09

- Added the first Codex integration batch: a curated MCP stdio server at `hermes-gpt mcp` (also available as `hermes-gpt codex mcp`).
- Added `hermes-gpt codex install`, `uninstall`, `doctor`, and `print-config` with idempotent, backup-first TOML fallback handling.
- Added Codex-focused planning, local vision path validation, web extraction SSRF protections, dry-run cron planning, skill drafting, and gateway diagnostics.
- Added explicit Codex/MCP capability gates plus strict write gates for cron and skill writes.
- Added recursive response redaction for provider keys, GitHub tokens, cookies/session values, bearer tokens, and private keys.

## 0.4.0 - 2026-07-09

- Added env-gated Hermes tool wrappers: `hermes_vision_analyze` (HERMES_GPT_ENABLE_VISION), `hermes_web_search` / `hermes_web_extract` (HERMES_GPT_ENABLE_WEB).
- Added `hermes_cron_create` operator tool with full field support: schedule, prompt, script, skills, deliver, repeat, workdir, no_agent, model, context_from, enabled_toolsets.
- Fixed gateway status PID fallback on macOS — falls back to gateway_state.json when gateway.pid is missing or unparsable.
- Expanded gateway status diagnostics: exposes gateway_state, gateway_kind, gateway_pid_source, gateway_updated_at, gateway_exit_reason, gateway_active_agents.
- Fixed Vercel static site deployment configuration.
- Updated landing page with v0.3.0 and v0.4.0 feature summaries.
- Fixed flaky HTTP smoke test — now skips by default unless HERMES_HTTP_TEST=1 is set.
- Consolidated duplicate exception handling in `_is_pid_alive`.

## 0.3.0 - 2026-06-25

- Added operator diagnostics and recovery tools: `hermes_operator_doctor`, `hermes_operator_snapshot`, `hermes_release_doctor`, and `hermes_operator_recover`.
- Introduced a structured error envelope (`success`, `ok`, `error`, `layer`, `code`, `safe_message`, `suggested_action`, `trace_id`) for all operator-facing failures.
- Converted operator exception handlers in `operator_config`, `operator_cron`, `operator_skills`, `operator_workspace`, and `server` to the new envelope while preserving legacy `success:false` and `error` fields.
- Added PASS/WARN/FAIL/UNSUPPORTED status vocabulary across diagnostic tools.
- Implemented conservative recovery with dry-run default and `apply=true` gating; connector re-registration is explicitly reported as unsupported.
- Added secret-value and absolute-path redaction in structured error messages.
- Added comprehensive tests for diagnostics, recovery, release readiness, and error-envelope safety.
- Updated operator-mode docs, README, release checklist, and release notes for v0.3.0.

## 0.2.0 - 2026-06-21

- Added tiered Operator / Owner Mode tooling for trusted MCP clients.
- Kept the default posture read-only or dry-run, with direct mutation gated by explicit server and per-call opt-in.
- Added operator policy, status, audit, cron, config, env, gateway, workspace, and owner-scope tools.
- Fixed data-root normalization so operator profile operations resolve back to the Hermes data root.
- Updated packaging to include operator modules and release docs.
- Added a new Operator Mode guide, quickstart, and troubleshooting for new users.

## 0.1.0 - 2026-06-18

- Initial local-dev release.
- Added FastMCP stdio and streamable HTTP server.
- Added Hermes file read/search, memory search, skill list/view, and optional gated write/patch/session/terminal capabilities.
- Added release safety gates for write tools, memory writes, session search, terminal execution, and remote no-auth mode.
- Added pytest coverage for default tool surface, auth metadata, safety gates, timeout capping, remote profile blocking, and HTTP initialize.
