# Operator Mode for Hermes GPT

For the v0.17 guided launch, durable receipt recovery, pending-review workbench and read-only delivery page, see [Daily Operations](daily-operations.md). Existing Operator, direct, Autopilot and Owner gates remain authoritative.


Operator Mode is the policy-gated control plane for trusted MCP clients such as ChatGPT. This document describes the current v0.16.0 behavior, including the durable Mission lifecycle, unified delegation lineage, live-event bus, and Fabric-backed cross-machine Swarm execution, plus the vNext slice-1 additive surfaces (MissionPlan DAG, derived capability-manifest / mission-ledger views, budget envelope, placement scoring, failure classification + recovery matrix, and the shadow/observe mission controller) and the vNext slice-2 gated execution rungs (budget D3 hard-block enforcement behind `HERMES_GPT_BUDGET_HARD_BLOCK=1`, and the controller L2 rung behind `HERMES_GPT_CONTROLLER_EXECUTE=1`). The slice-1 surfaces are decision-only; the slice-2 rungs are default-off, add no tools, and keep every existing surface byte-identical until their gates are armed. They are documented further in [vnext-capability-manifest-and-mission-ledger.md](vnext-capability-manifest-and-mission-ledger.md) and [design/](https://github.com/asimons81/hermes-gpt/tree/master/docs/design).

For documentation authority and historical-artifact rules, see [docs/README.md](README.md).

## Core rule

**Tool visibility is not authority.** A tool can be present in the MCP schema and still refuse to mutate because the required policy gates are not satisfied.

Hermes GPT is designed to run on the user's machine, bound to loopback. Remote clients require a deliberately configured private or authenticated boundary in front of that loopback service. Public unauthenticated Operator hosting is unsupported.

Operator Mode is defense-in-depth, not an OS sandbox. Use OS-level isolation for untrusted input.

## Authority model

Operator authority is determined by four things:

1. `HERMES_GPT_OPERATOR_ENABLED`
2. `HERMES_GPT_OPERATOR_LEVEL`
3. `HERMES_GPT_OPERATOR_APPLY_MODE`
4. the individual tool call's mutation gates, normally `dry_run` and sometimes `confirm`

Owner operations add two more gates:

```text
HERMES_GPT_OWNER_ACTIVE=1
HERMES_GPT_OWNER_ACK=I_UNDERSTAND_THIS_CAN_MUTATE_MY_MACHINE
```

### Operator levels

Higher levels include the capabilities of lower levels.

| Level | What it unlocks |
| --- | --- |
| `read_only` | status, policy, audit, list/view/diff operations, Mission Control |
| `cron` | cron run, pause, copy, move |
| `skills` | skill create, edit, patch, write, copy, sync, delete |
| `skills_config` | non-secret config and environment writes |
| `workspace` | scoped workspace read/write/test, bounded binary export, gateway restart, Codex jobs, contract/swarm dispatch |
| `owner` | break-glass raw command/file operations and final swarm approval; secret paths remain denied |

`skills_config` is a reasonable ceiling for routine configuration work. Use `workspace` only when a task requires scoped workspace operations or delegated execution. Treat `owner` as break-glass.

## Four operating postures

### 1. Read-only default

No Operator environment variables are required.

```powershell
hermes-gpt
```

Expected behavior:

- read/status/list tools work where enabled;
- mutating Operator tools refuse;
- Mission Control remains read-only.

### 2. Dry-run Operator Mode

Recommended for an always-on trusted connector.

```powershell
$env:HERMES_HOME="C:\Users\<YOU>\AppData\Local\hermes"
$env:HERMES_GPT_OPERATOR_ENABLED="1"
$env:HERMES_GPT_OPERATOR_LEVEL="skills_config"
$env:HERMES_GPT_OPERATOR_APPLY_MODE="dry_run"
$env:HERMES_GPT_OPERATOR_ALLOWED_PROFILES="default"

python server.py --http --host 127.0.0.1 --port 4750
```

Mutating tools return plans or previews but do not apply changes.

### 3. Direct Operator Mode

Use only for a deliberate maintenance session.

```powershell
$env:HERMES_HOME="C:\Users\<YOU>\AppData\Local\hermes"
$env:HERMES_GPT_OPERATOR_ENABLED="1"
$env:HERMES_GPT_OPERATOR_LEVEL="workspace"
$env:HERMES_GPT_OPERATOR_APPLY_MODE="direct"
$env:HERMES_GPT_OPERATOR_ALLOWED_PROFILES="default"
$env:HERMES_GPT_OPERATOR_ALLOWED_PATHS="C:\path\to\approved-workspace"
```

Direct mode only permits mutation. It does not force mutation. A mutating call still needs `dry_run=false`, and tools with an explicit confirmation gate also need `confirm=true`.

### 4. Owner Mode

Break-glass only.

```powershell
$env:HERMES_GPT_OPERATOR_ENABLED="1"
$env:HERMES_GPT_OPERATOR_LEVEL="owner"
$env:HERMES_GPT_OPERATOR_APPLY_MODE="direct"
$env:HERMES_GPT_OWNER_ACTIVE="1"
$env:HERMES_GPT_OWNER_ACK="I_UNDERSTAND_THIS_CAN_MUTATE_MY_MACHINE"
```

Configured `owner` authority is clamped unless the Owner activation and exact acknowledgement are present. Owner Mode still cannot access denied secret paths.

Do not use Owner Mode for a public, shared, or always-on connector.

## Dry-run and confirmation semantics

For a normal mutating Operator tool, actual mutation requires:

```text
HERMES_GPT_OPERATOR_APPLY_MODE=direct
```

plus:

```json
{
  "dry_run": false
}
```

Tools that create or dispatch external work also require `confirm=true` when their schema includes that gate.

A refusal caused by a missing gate is expected behavior, not a failure to execute the request.

### Optional file backups

`hermes_workspace_patch`, `hermes_workspace_write_file`, `hermes_owner_patch`, and `hermes_owner_write_file` create timestamped sibling backups (`<name>.bak.<timestamp>`) before replacing an existing file. This remains enabled by default.

Backups are disabled only by an explicit recognized false value of `HERMES_GPT_OPERATOR_FILE_BACKUPS`: `0`, `false`, `no`, `off`, or `disabled` (case-insensitive, surrounding whitespace ignored). Set one of these to skip the backup copies when the target workspace already has an appropriate version-control or rollback strategy. An unset, empty, or unrecognized value (for example a typo such as `flase`) keeps backups on. Disabling backups does **not** change Operator authorization, dry-run/confirmation gates, denied-path policy, or atomic replace writes; successful tool results report `"backup": null` when no copy is created.

## Mission Control

Mission Control is the read-only `hermes_mission_*` operational view of the Hermes deployment.

Surfaces:

- `overview`
- `health`
- `profiles`
- `fleet`
- `codex`
- `cron`
- `delegations`
- `failures`
- `approvals`
- `vault`
- `usage`
- `audit`

Mission Control is structurally read-only:

- SQLite sources are opened read-only;
- no Mission tool accepts write/apply arguments;
- no mutating shell action is performed;
- every Mission call is audited as unchanged/read-only;
- missing optional sources return a bounded unavailable reason instead of crashing the whole view.

### Data boundary

Mission Control never returns raw message, memory, transcript, request-dump, credential, token, vault-secret, or profile-secret bodies.

Prompt-like text is represented by bounded metadata such as `prompt_len` and `prompt_sha256`. Free-text operational fields such as failures, audit summaries, cron names, and delegation summaries receive conservative secret and PII stripping before they leave the host.

### Surface allowlist

`HERMES_GPT_MISSION_ALLOWED_SURFACES` is **restrictive when configured**.

- **unset:** all read-only Mission Control surfaces are available;
- **comma-separated list:** only listed valid surfaces are available;
- **empty value:** every Mission Control surface is denied.

Do not describe the unset state as deny-by-default. The implementation deliberately makes all read-only Mission surfaces available when the variable is absent.

Mission Control requires only `read_only` authority and never needs direct apply mode.

## Missions lifecycle (v0.9)

Beyond the read-only Mission Control overview, v0.9 adds a first-class durable Mission object as the bounded parent record for a larger objective. A Mission groups an objective, acceptance criteria, bounded context references, an explicit skills manifest, Swarm/work/delegation attachments, lifecycle state, and a final Owner approval that defaults on.

Lifecycle: `draft -> running -> awaiting_approval -> completed`, plus `paused` / `blocked`. `final_approval_required` defaults to true and is immutable after creation; disabling it is an Owner-only creation-time decision.

Tools: `hermes_mission_create`, `hermes_mission_get`, `hermes_mission_list`, `hermes_mission_update`, `hermes_mission_attach`, `hermes_mission_transition`, `hermes_mission_reconcile`, `hermes_mission_approve`.

Reads are read-only. Mutations preserve the normal workspace/direct/confirm gates; direct completion is Owner-gated, and approval-required Missions complete only through explicit Owner approval. A public attachment call can never assert `succeeded`. Completion stays based on coordinator-observed evidence and explicit approval, preserving the v0.8 Fabric safety model.

See [Missions (v0.9)](missions.md).

## Delegations (v0.9)

v0.9 adds a durable, normalized delegation lifecycle above Work Contracts and existing runner/Fabric execution. The delegation record is lineage and state metadata, not a second execution authority; runner, Fabric, Work Contract validation, and Operator policy remain authoritative.

Tools: `hermes_delegation_dispatch`, `hermes_delegation_get`, `hermes_delegation_list`, `hermes_delegation_reconcile`, `hermes_delegation_cancel`. Normalized states are `queued`, `running`, `reconciling`, `blocked`, `succeeded`, `failed`, and `cancelled`.

A delegation never marks work successful from a worker's claim: terminal backend success stays `reconciling` until the matching immutable Work Contract lineage has a `SATISFIED` verdict; missing, unreadable, or `UNVERIFIED` evidence fails closed. `opencode` is a first-class local runner backend.

See [Delegations (v0.9)](delegations.md).

## Live events (v0.9)

v0.9 adds a durable, bounded live-event bus for clients and parent orchestrators that need completion/wake-up delivery without polling every underlying store.

MCP tools: `hermes_live_events_cursor()` and `hermes_live_events_since(cursor, mission_id, topic, kind, limit, wait_ms)`. The same durable stream is available over `/events/ws` (Operator mode must be enabled; OAuth-only deployments fail closed for WebSocket). Reads are non-creating.

Live events are notifications, not proof. Mission, Swarm, Work Contract, runner, and Fabric journals remain authoritative; a missing, delayed, duplicated, or reconnected event never advances work. See [Live events (v0.9)](live-events.md).

## Binary file export

`hermes_export_file(path)` is a read-only raw-byte transfer surface gated at Operator `workspace` level. It requires a non-empty `HERMES_GPT_OPERATOR_ALLOWED_PATHS`, resolves paths before authorization so symlink escapes are refused, preserves all denied secret/credential paths even in Owner Mode, enforces a 4 MiB default and 16 MiB hard maximum, and supports an optional `HERMES_GPT_EXPORT_ALLOWED_EXTENSIONS` suffix allowlist. Successful bytes are returned as `EmbeddedResource(BlobResourceContents)` with safe metadata; client download/attachment rendering is client-controlled. See [Binary file export](file-export.md).

## Work Contracts

Work Contracts add a structured, verifiable work-order layer through `hermes_contract_*`.

Since v0.14, `expected_artifacts` entries can include optional `max_bytes` and lowercase `sha256` acceptance checks in addition to `min_bytes`. Local hashing is bounded to 8 MiB and changing/unreadable content fails closed; remote evidence still requires coordinator verification and immutable contract binding. Size/digest checks do not replace semantic review. Autopilot nodes expose the same bounds through optional `artifact_requirements`; confirmed failed artifacts after successful execution use a durable delivery grace and existing bounded recovery. See [Autopilot](autopilot.md#declared-deliverable-acceptance-v014).

| Tool | Authority | Purpose |
| --- | --- | --- |
| `hermes_contract_define(contract_json)` | read-only | Validate and canonicalize a contract. |
| `hermes_contract_dispatch(contract_json, confirm, dry_run)` | workspace | Dispatch a validated contract through the existing fleet authority model. |
| `hermes_contract_validate(contract_json)` | read-only by default | Validate completion from observed evidence. |
| `hermes_contract_status(contract_json)` | read-only | Link the contract to bounded observed run/delegation state. |

For contracts that carry `capability_req`, dispatch revalidates the requested
skills against the assigned profile's effective Hermes Agent loader immediately
before invoking the runner. This is a live guard against profile changes after
planning; rejection is non-mutating. Fabric eligibility remains separate from
logical profile skill ownership.

The catalog adapter prefers Hermes Agent's public `find_all_skills()` API and
supports the older `_find_all_skills()` API. Both require the Agent's
`skill_view()` explicit loader; an absent or incompatible loader refuses
required-skill validation as `skill_resolution_unavailable`. Catalog discovery
only explains provenance. The dispatch guard still calls
`skill_view(..., preprocess=False)` freshly and never executes inline shell
snippets. CI checks these loader interfaces against pinned modern and legacy
Agent source with focused loader dependencies; it does not certify a complete
Agent installation or live session execution.

### Validation model

A worker's claim that work is complete is never proof by itself. Validation inspects observed state such as runs, artifacts, tests, audit evidence, and required review evidence.

Verdicts are bounded to:

- `SATISFIED`
- `NOT_SATISFIED`
- `INCONCLUSIVE`
- `INVALID_CONTRACT`

Missing evidence fails closed. A valid contract with no observed run cannot become `SATISFIED`.

Retry selection is deterministic. Forbidden-action audit evidence is scoped to the contract's task identity so unrelated concurrent work does not contaminate the verdict.

### Review limitation in v0.6.0

v0.6.0 has no production review-accept writer. If a contract requires review, the necessary evidence must already exist through an authorized external reviewer/audit path or human approval reference. If it does not exist, validation returns `NOT_SATISFIED`.

**v0.7 closes this gap**: `hermes_review_accept` (owner-gated, distinct
reviewer enforced) writes review-acceptance records that the validator reads
as evidence. See [Flight Deck (v0.7)](#flight-deck-v07).

Required test checks execute only through the workspace test allowlist and inherit the workspace/direct policy gates.

## Swarm Orchestration

Swarm Orchestration is the `hermes_swarm_*` DAG workflow layer built on Work Contracts.

Canonical workflow shape:

```text
research -> architecture -> implementation/tests/docs
         -> integration review -> Codex review
         -> acceptance validation -> HUMAN APPROVAL
```

Tools:

| Tool | Authority | Purpose |
| --- | --- | --- |
| `hermes_swarm_workflow_validate(workflow_json)` | read-only | Validate schema, owners, caps, contracts, dependencies, and cycles. |
| `hermes_swarm_workflow_create(workflow_json, confirm, dry_run)` | workspace | Register a workflow instance. |
| `hermes_swarm_workflow_list()` | read-only | List bounded workflow status. |
| `hermes_swarm_workflow_status(workflow_id)` | read-only | Return one bounded stage/owner/verdict/handoff view. |
| `hermes_swarm_stage_dispatch(workflow_id, stage_id, confirm, dry_run)` | workspace | Dispatch one ready stage as a Work Contract. |
| `hermes_swarm_stage_advance(workflow_id, stage_id, confirm, dry_run)` | workspace | Validate observed completion, record handoff, and promote ready children. |
| `hermes_swarm_approve(workflow_id, confirm, dry_run)` | owner | Record the final human approval. |

Default caps, unless explicitly overridden by the supported environment variables:

- 3 concurrent stages per workflow;
- 4 concurrent stages per board;
- 12 stages per workflow.

A Swarm stage may carry an optional `capability_req` with the logical profile and
required skills. The generated Work Contract preserves that requirement, and
dispatch revalidates it against the live Hermes Agent loader before invoking a
runner. The probe uses `skill_view(..., preprocess=False)`, matching Hermes
preload, so validating a required skill does not execute `skills.inline_shell`
snippets. Removing a required skill after workflow creation therefore rejects the
dispatch without starting work; Fabric remains a separate physical placement
question.

Failed validation can return a stage for one bounded rework retry. A second failure blocks the stage for human attention.

Codex may provide a bounded review verdict, but Codex is never an implementation owner. Final workflow approval is human and Owner-gated.

## Fabric execution (v0.8)

v0.8 extends Swarm execution across authenticated Hermes machines without moving completion authority to the worker. A stage using `execution.backend=auto` can be placed on an eligible local or remote runtime from the current capability snapshot; explicit backend/placement choices remain available where the workflow supports them.

The packaged remote endpoint is `hermes-gpt-fabric-peer`. Loopback HTTP is permitted for same-machine development. Non-loopback peer serving requires both `--cert` and `--key`; the peer refuses insecure remote transport.

Fabric routing is fail-closed. Placement considers node health and capability freshness, backend support, profile/workspace policy, and the server-controlled authority ceiling. A remote peer cannot widen the coordinator's authority. Remote worker self-report is transport data, not Work Contract completion evidence.

Remote evidence and artifacts are admitted through coordinator-controlled paths. Required unavailable evidence cannot become `SATISFIED`; artifact bytes are verified before admission. Restart, timeout, and cancellation reconciliation preserve the original attempt where recovery is possible rather than silently creating a replacement writer.

Flight Deck adds read-only Fabric node, placement, attempt, evidence, and routing views. The selected-route record carries the authoritative health, capability-freshness, eligibility, transport-backend, and authority-ceiling fields used to explain placement.

See [v0.8.0 release notes](release-notes-v0.8.0.md) for the two-machine acceptance boundary and the known historical-timeout presentation limitation.

## Flight Deck (v0.7 foundation, v0.8 Fabric views)

Flight Deck began in v0.7 with production review evidence, structured event history, durable encrypted token storage, and restart reconciliation. v0.8 layers read-only Fabric nodes, placement, attempts, evidence, and routing visibility onto that foundation. Existing authority classes and final human approval remain authoritative.

### Review evidence (`hermes_review_accept`)

| Tool | Authority | Purpose |
| --- | --- | --- |
| `hermes_review_accept(contract_sha256, task_id, assignee, reviewer, verdict, evidence_refs, approval_reference, dry_run, confirm)` | **owner** + direct + confirm | Write a review-acceptance record for a Work Contract. Distinct reviewer is enforced at write time (`reviewer != assignee`); verdicts are bounded to `SATISFIED` / `NOT_SATISFIED`; evidence is referenced, never copied. |

The Work Contract validator reads the review-evidence store as an additional
evidence source while keeping the v0.6 audit + human-approval paths. A
`SATISFIED` acceptance by a reviewer distinct from the assignee satisfies the
review check; a self-review record never does.

### Structured event history (`hermes_events_*`)

| Tool | Authority | Purpose |
| --- | --- | --- |
| `hermes_events_query(source, subject_id, kind, since, until, limit)` | read_only + allowlist | Query the normalized, redacted event timeline (audit / swarm / codex / cron / kanban). |
| `hermes_events_tail(limit)` | read_only + allowlist | Recent events across all allowed sources. |

The event surface is a derived read-model over existing durable stores; it
never writes. Allowlist: `HERMES_GPT_EVENTS_ALLOWED_SOURCES` (unset = all
read-only sources; list = only listed; empty = none). Retention:
`HERMES_GPT_EVENTS_MAX_AGE_DAYS` (default 90). Redaction invariants match
Mission Control; prompts appear only as length/sha when present in the source.

### Durable token storage (`hermes_oauth_*`)

| Tool | Authority | Purpose |
| --- | --- | --- |
| `hermes_oauth_status()` | read_only | Durable token store presence/expiry only; never exposes token material. |
| `hermes_oauth_revoke(confirm, dry_run, rotate_key)` | **owner** + direct + confirm (pending legal scope decision) | Retire every durable token + advance the revocation epoch in one transaction; optionally rotate the active master key. |

OAuth access/refresh tokens are persisted through `token_store` (a
transactional SQLite store at `<hermes_data>/secrets/hermes_gpt_tokens.db`,
0600; per-row AES-256-GCM ciphertext; keyring → key file → env key
precedence) so a server restart does not invalidate credentials. No token
material is ever written to the audit log or any MCP response. The
`secrets/` directory is a denied path for all tools.

### Restart reconciliation (`hermes_swarm_reconcile`)

| Tool | Authority | Purpose |
| --- | --- | --- |
| `hermes_swarm_reconcile(apply)` | workspace/owner + direct (dry-run first) | Mark swarm stages stuck in `running` as `blocked` with `reason: interrupted_by_restart`; reload the durable token envelope; report a bounded summary. |

Reconciliation is fail-closed: it never auto-advances or auto-dispatches
work. The operator explicitly re-advances through the existing gated
`hermes_swarm_stage_advance`, which is idempotent for already-validated or
done stages (a re-advance returns current state as a no-op).

### v0.7 surface manifest

| Tool | Authority class | Gates | Audit | Allowlist |
| --- | --- | --- | --- | --- |
| `hermes_review_accept` | owner | direct + confirm | every call | n/a |
| `hermes_events_query` | read_only | allowlist | every call | `HERMES_GPT_EVENTS_ALLOWED_SOURCES` |
| `hermes_events_tail` | read_only | allowlist | every call | `HERMES_GPT_EVENTS_ALLOWED_SOURCES` |
| `hermes_oauth_status` | read_only | none | every call | n/a |
| `hermes_oauth_revoke` | owner | direct + confirm (pending legal) | every call | n/a |
| `hermes_swarm_reconcile` | workspace/owner | dry-run-first + apply | every call | n/a |

## Session history and session control

These surfaces are independent from the Operator level hierarchy and remain hidden unless their explicit legacy gates are enabled.

`HERMES_GPT_ENABLE_SESSION_SEARCH=1` exposes bounded read-only `hermes_session_search`, `hermes_session_list`, `hermes_session_read`, and `hermes_session_export`. Default transcript roles are `user` and `assistant`; internal roles additionally require `HERMES_GPT_ENABLE_SESSION_INTERNAL_CONTENT=1`. Export is in-memory and bounded, creates no files or paths, and lineage export fails closed.

`HERMES_GPT_ENABLE_SESSION_CONTROL=1` exposes `hermes_session_continue`, `hermes_session_send`, `hermes_session_job_status`, and `hermes_session_job_result`. Session-control jobs use a fixed `hermes --resume <id> --oneshot <prompt>` argv with `shell=False`, bound prompt/timeout/result sizes, permit one active job per session, and persist prompt length/hash rather than raw prompt text. Restart reconciliation marks unowned running jobs orphaned rather than signaling a process from a persisted PID. The configured Hermes provider/model is used and may consume quota.

See [session history](session-history.md) and [session control](session-control.md). Treat transcript content as private local data.

## Fleet routing through the local A2A registry

Fleet routing uses only peers already present in the authenticated local Hermes A2A registry.

| Tool | Authority | Behavior |
| --- | --- | --- |
| `hermes_fleet_list` | read-only | List named peers without exposing tokens or peer URLs. |
| `hermes_fleet_status` | read-only | Return bounded compatibility metadata for one peer. |
| `hermes_fleet_dispatch` | workspace + direct + confirm | Submit bounded work to one named peer. |
| `hermes_fleet_task` | read-only | Return bounded task state. |
| `hermes_fleet_dispatch_work_order` | workspace + direct + confirm | Validate and submit a structured profile-aware work order. |
| `hermes_fleet_result` | read-only | Return a validated safe completion bundle. |
| `hermes_fleet_authority_drift` | read-only | Report registry/manifest/profile/role/Agent Card drift. |

MCP callers cannot supply an arbitrary peer endpoint, bearer token, SSH command, or executable.

If the peer reply times out after a dispatch was submitted, the dispatch tools do not lose the task: the peer-assigned task id is recovered by a bounded context lookup and returned in a structured `FLEET_DISPATCH_TIMEOUT` error with `submission_may_have_succeeded: true`, so the operator can poll `hermes_fleet_task` instead of guessing whether the remote side accepted the work.

### Fleet authority manifest

Set `HERMES_GPT_FLEET_AUTHORITY_MANIFEST` to an absolute JSON path or use the default location under the Hermes data root:

```text
<Hermes data root>/config/fleet-authority.json
```

Start from `examples/fleet-authority.example.json`.

The manifest defines expected peer identity/role/profile authority. It must not contain URLs, credentials, or tokens. Before direct structured dispatch, Hermes GPT rechecks live peer identity and role against this server-controlled manifest. A mismatch stops dispatch.

High-impact structured work additionally requires bounded approval metadata. Public-action detection and role authority are enforced locally before work is sent.

## Codex CLI jobs through the Operator server

This is different from installing Hermes GPT as an MCP server inside Codex.

The normal Operator server exposes asynchronous delegated Codex tools:

- `hermes_codex_status`
- `hermes_codex_plan`
- `hermes_codex_start`
- `hermes_codex_review_start`
- `hermes_codex_jobs`
- `hermes_codex_job_status`
- `hermes_codex_job_result`
- `hermes_codex_cancel`

Real execution requires:

- Operator Mode at `workspace` or acknowledged `owner` level;
- an allowed work directory;
- `HERMES_GPT_ENABLE_CODEX_RUNNER=1`;
- direct apply mode;
- `confirm=true`;
- `dry_run=false`.

`HERMES_GPT_ALLOW_CODEX_WRITE=1` is required only for `workspace-write`. Read-only Codex jobs do not need it.

Jobs default to `execution_mode="normal"`. An explicit per-job `execution_mode="nolo"` adds Codex's `-a never` approval policy while retaining the requested `read-only` or `workspace-write` sandbox. NOLO therefore removes Codex approval interruptions without granting `danger-full-access` or bypassing Hermes path, direct-mode, confirmation, or write gates. It ends with the job and creates no persistent global approval-bypass state.

`HERMES_GPT_CODEX_EXE` can pin an absolute standalone Codex CLI executable. Hermes GPT rejects protected WindowsApps shims and executables that fail a version probe.

For Codex acting as an MCP client, use [docs/codex.md](codex.md). For the Windows ChatGPT -> Hermes GPT -> Codex CLI deployment, use [windows-chatgpt-codex.md](windows-chatgpt-codex.md).

## Audit behavior

When `HERMES_HOME` is set, audit reads and writes use that exact data/profile
directory, including a named profile:

```text
<HERMES_HOME>/logs/hermes_gpt_operator_audit.jsonl
```

The log directory is created on the first write. An unavailable destination does
not redirect records into another installation or the program directory. Audit
writes retain their best-effort behavior: the tool returns the record even if it
cannot be persisted. Existing logs are not moved or merged automatically; retain
them separately when changing `HERMES_HOME`.

Without `HERMES_HOME`, the legacy Windows path is used if its parent exists:

```text
%USERPROFILE%\AppData\Local\hermes\logs\hermes_gpt_operator_audit.jsonl
```

Otherwise, the legacy fallback is:

```text
<hermes-gpt>\logs\hermes_gpt_operator_audit.jsonl
```

Audit records contain bounded operational metadata such as tool, level, apply mode, dry-run state, changed/success state, relevant IDs, and length/hash metadata for content-bearing operations.

Audit records do not intentionally persist raw prompts, `.env` values, vault contents, credentials, or full secret-bearing config values.

## Diagnostics and recovery

### `hermes_operator_doctor`

Read-only deep health check across the Operator surface. Checks include gateway state, config/env readability, cron/skills, policy, audit readability, and connector capability.

Gateway state is fail-closed: `hermes_operator_doctor` never reports the gateway as healthy on a heartbeat file alone. A heartbeat with no live gateway PID fails with `GATEWAY_PID_MISSING`; a dead PID fails with `GATEWAY_DEAD_PID`; an unreachable gateway fails with `GATEWAY_UNREACHABLE`. Stale heartbeat files surface as `GATEWAY_STALE_HEARTBEAT` warnings.

Status vocabulary:

- `PASS`
- `WARN`
- `FAIL`
- `UNSUPPORTED`

### `hermes_operator_snapshot`

Returns one bounded current-state summary with a recommended next action.

### `hermes_operator_recover`

Conservative recovery planner. Dry-run is the default. Use `apply=false` first.

Actual recovery mutation requires `apply=true` plus the normal direct/workspace policy gates.

### `hermes_release_doctor`

Use before preparing a release. It checks repository state, secret-file hygiene, package version/docs consistency, import/compile health, and that the server is not left in direct mode. `full_tests=true` also runs the test suite.

Release statuses are `PASS`, `WARN`, or `BLOCKED`.

## Profile and path normalization

Typical Hermes data roots:

- Windows: `C:\Users\<YOU>\AppData\Local\hermes`
- Unix/macOS: `~/.hermes`

If `HERMES_HOME` points at a named profile or the Hermes Agent source directory, Operator profile operations normalize back to the Hermes data root. The default profile maps to that root; named profiles map under `profiles/<profile-name>`.

`HERMES_GPT_OPERATOR_ALLOWED_PATHS` should contain only the workspaces the Operator server is expected to touch.

## Remote access posture

Keep the MCP server bound to `127.0.0.1`.

For a remote client:

1. keep Hermes GPT on loopback;
2. put an authenticated/private boundary in front of it;
3. use `dry_run` for routine always-on access;
4. switch to `direct` only for a deliberate maintenance session;
5. switch back after the session;
6. never leave Owner Mode enabled on an always-on connector.

Operator Mode itself does not add public-network authentication.

## Secret-path policy

The server refuses or redacts access to secret-looking locations even at high authority, including categories such as:

- `.env` files;
- auth/token/cookie stores;
- vault secrets;
- SSH keys;
- AWS credential paths;
- MCP token files;
- other secret-looking filenames.

Owner Mode does not disable this policy.

## Troubleshooting

### Connector shows an old or incomplete tool list

- Verify the running server process is the one you expect.
- Inspect the MCP tool list directly.
- Reconnect or recreate the client connector if it cached an older schema.
- Do not rely on a fixed expected tool count; the count changes as gated surfaces evolve.

### A profile appears missing

- Check `HERMES_HOME`.
- Confirm root normalization.
- Remember that `default` resolves to the data root while named profiles live under `profiles/<profile-name>`.

### A mutating tool refuses

Check the exact tool's requirements plus:

- `HERMES_GPT_OPERATOR_ENABLED`
- `HERMES_GPT_OPERATOR_LEVEL`
- `HERMES_GPT_OPERATOR_APPLY_MODE`
- `dry_run`
- `confirm` when the tool defines that gate

A policy refusal is often the correct result.

### Owner tools refuse

Verify both Owner activation and the exact acknowledgement string:

```powershell
$env:HERMES_GPT_OWNER_ACTIVE="1"
$env:HERMES_GPT_OWNER_ACK="I_UNDERSTAND_THIS_CAN_MUTATE_MY_MACHINE"
```

## Related docs

- [Documentation map](README.md)
- [Missions (v0.9)](missions.md)
- [Delegations (v0.9)](delegations.md)
- [Live events (v0.9)](live-events.md)
- [Codex integration](codex.md)
- [Windows ChatGPT -> Codex](windows-chatgpt-codex.md)
- [Updating](updating.md)
- [Retention policy](retention-policy.md)
- [v0.8.0 release notes](release-notes-v0.8.0.md)
- [v0.7.0 release notes](release-notes-v0.7.0.md)
- [v0.6.0 release notes](release-notes-v0.6.0.md)


## Runner backend trust boundaries

Runner backends are execution transports for already-authorized work contracts;
they are not completion authorities. Contract validation, expected artifacts,
review requirements, and forbidden-action checks remain outside the backend.

### Filesystem confinement

Every `pi_rpc` session is gated on **OS-level filesystem confinement**, not on
the process working directory. CWD is not a sandbox: absolute paths, `..`
traversal, shell `cd`, and outward symlinks can escape a plain current working
directory.

Confinement uses bubblewrap (`bwrap`) on Linux and `sandbox-exec` on macOS to
make `allowed_scope.workspaces` a physical read boundary. Read-only Pi sessions
receive the authorized workspace read-only. Write-capable sessions receive that
workspace read-write only after the independent authorization and sandbox gates
have passed. Only the minimal read-only runtime trees required to execute Pi are
exposed outside the workspace.

Configuration:

- `HERMES_GPT_ENABLE_RUNNER_CONFINEMENT=1` — opt in to confinement (off by
  default; when off, `pi_rpc` dispatch fails closed, including read-only runs,
  because workspace read scope cannot otherwise be enforced).

Every `pi_rpc` contract requires an allowed workspace and a successful bounded
capability probe for its exact posture. A write-capable contract additionally
requires **all** of:

1. a write-authorized class (`reversible_write` or `high_impact`); `none` and
   `read_only` can never enable `bash`, `edit`, or `write`,
2. `execution.options.sandbox=workspace-write`,
3. `HERMES_GPT_ENABLE_RUNNER_CONFINEMENT=1` with the OS confinement binary
   installed **and a bounded capability probe succeeding on the current host**.

Binary presence alone is not treated as availability. The capability probe
launches the same confinement posture used for the runner child. Both postures
prove that the workspace is readable while absolute, `..`, and outward-symlink
reads cannot reach a sibling host file. Writable posture additionally proves an
in-workspace host write succeeds while an out-of-scope host write cannot modify
the corresponding host path. Read-only posture proves the workspace itself
cannot be mutated. Probe failure, timeout, or an unusable namespace/profile
causes dispatch to fail closed with a `PermissionError` before Pi starts.

Before any Pi child is wrapped, the workspace boundary is validated for
path/inode/mount aliases. Pre-existing outward symlinks, hard links with any
alias outside the workspace, special filesystem entries (device nodes, FIFOs,
sockets, etc.), and nested mount points/filesystems are rejected. This matters
for reads as well as writes: any of those aliases/channels can expose
out-of-scope host data through an in-workspace pathname even when the workspace
itself is read-only. Artifact/path validation also rejects absolute paths, `..`
traversal, and symlink escapes where Hermes itself resolves paths
(`runner_confinement.confine_path`). Pi's built-in read tool is protected by
the OS confinement boundary rather than by that helper.

On Linux, the wrapper exposes only the read-only system/runtime trees needed
to launch the runner, plus a narrowly selected read-only runtime tree when the
runner executable is installed outside system prefixes (for example Pi below
`~/.local/.../node_modules`). The rest of the user's home directory is not
mounted into the sandbox. `/tmp` and `/run` are private sandbox filesystems, so
host temporary files and Unix-domain service sockets are not exposed. The
authorized workspace is bound read-only for read-only sessions and read-write
only for authorized write sessions. All Linux capabilities are dropped so a
privileged launch cannot remount the boundary writable. On macOS, the
`sandbox-exec` profile likewise denies host reads outside the workspace and a
narrow runtime allowlist. System code is limited to required system/runtime
roots, while host configuration trees such as `/Library`, `/etc`, and
`/private/etc` are not exposed wholesale; only concrete runtime files needed
for name resolution, service lookup, devices, and time data are allowed. A
non-system Pi/Node installation is exposed only through its narrowly selected
runtime tree. Writable posture adds a workspace write exception and nothing
broader.

Install `bubblewrap` (e.g. `apt install bubblewrap`) and verify it works in your
environment; some containerized hosts restrict user namespaces. In any case,
capability-probe failure disables `pi_rpc` entirely rather than silently
falling back to an unconfined read-only child.

External runner plugins are trusted in-process code. Setting
`HERMES_GPT_ENABLE_RUNNER_PLUGINS=1` only enables discovery; each external entry
point must also be named in `HERMES_GPT_RUNNER_PLUGIN_ALLOWLIST`. Plugin code runs
inside the Hermes GPT process and should be installed only from sources trusted
as much as Hermes GPT itself.

Deployments can constrain autonomous routing with comma-separated allowlists:

- `HERMES_GPT_RUNNER_BACKEND_ALLOWLIST` for backend names such as `fleet`,
  `pi_rpc`, `omx`, and `codex`.
- `HERMES_GPT_RUNNER_PROVIDER_ALLOWLIST` for provider names selected by Pi.
- `HERMES_GPT_RUNNER_MODEL_ALLOWLIST` for model names selected by Pi, OMX, or
  Codex.

Unset allowlists preserve compatibility and allow all values. Set allowlists are
enforced before dispatch so contracts cannot silently route work into an
unexpected backend, provider, or model.

Local runner request envelopes are transient. Workers unlink `*.request.json`
files immediately after loading them, and runner listing/status performs TTL
cleanup of stale envelopes left by a process that died before loading its
request. Durable runner metadata intentionally remains bounded state/exit data,
not prompt text or model output.

Local runner timeout and explicit-cancellation cleanup share one platform-aware
path. POSIX signals the runner process group. Windows uses `taskkill /T /F` for
the process tree and falls back to direct process termination if `taskkill` is
unavailable, times out, or reports failure.

Shared `run_argv` commands (including cron, fleet probes and release diagnostics)
also launch without console windows on Windows and bound process-tree cleanup.
If descendant pipes remain open, the call returns code 124 with an explicit
cleanup-unverified message. It does not wait indefinitely on a pipe reader;
this is not proof that every descendant exited. Existing authority gates and
fixed-argv execution remain unchanged.

## Autopilot (v0.13)

Autopilot is an optional, default-off runtime that drives one Mission through its MissionPlan. It is enabled by the machine gate `HERMES_GPT_AUTOPILOT=1`, which registers `hermes_autopilot_start`, `hermes_autopilot_status`, and `hermes_autopilot_stop`; with the gate unset none of them exist. Starting needs `workspace` level, direct apply mode, `dry_run=false`, and `confirm=true` (a dry run previews and writes nothing); stopping never needs the machine gate. It adds no authority: every dispatch goes through the existing placement, Work Contract, and delegation surfaces, it never dispatches or advances an approval or `high_impact` node, and it cannot approve a Mission. See [autopilot.md](autopilot.md).


Autopilot carries node artifact requirements into Work Contracts, refuses replacement of plans with unfinished work (`PLAN_IN_FLIGHT`), and exposes bounded recovery deferral in Mission reconciliation. See [autopilot.md](autopilot.md) for the exact acceptance and recovery rules. Its read-only browser panel is included in release wheels; browser access still requires the existing UI/authentication gates.
