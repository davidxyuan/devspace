# Release Checklist

Use this checklist before publishing a Hermes GPT release artifact.

## 1. Establish release state

- Confirm the intended version in `pyproject.toml`.
- Confirm `CHANGELOG.md` contains that version.
- Confirm the release notes describe a final release rather than a candidate once publication is approved.
- Read `docs/README.md` and confirm current operational docs are the documents being updated, not historical files under `docs/design/` or `docs/releases/`.
- Verify each distribution channel separately. A GitHub release does not prove the same version is already available from PyPI.

## 2. Core verification

- `python -m py_compile server.py test_server.py`
- `python -m pytest`
- `python -m pytest test_operator_mission.py`
  - Mission Control redaction, no-raw-body, read-only, audit, bounds, and allowlist behavior must be green.
- `python -m pytest test_operator_contract.py`
  - Work Contract schema, observed-state validation, false-done rejection, test gating, redaction, read-only behavior, and audit must be green.
- `python -m pytest test_operator_swarm.py`
  - DAG validation, scheduler caps, contract dispatch, observed completion, bounded rework, worktree plans, Codex review posture, approval gate, mutation gates, audit, and redaction must be green.
- `python -m pytest test_operator_codex.py`
  - Codex executable resolution, runner gates, bounded argv, redaction, and retention behavior must be green.
- `python -m pytest test_operator_session.py`
  - Session-control gating, prompt non-persistence, fixed argv, concurrency bounds, timeout/result bounds, redaction, and restart orphan reconciliation must be green.
- `python -m pytest test_operator_mission_runtime.py test_operator_delegations.py test_operator_live_events.py test_operator_finance.py test_operator_job_supervisor.py`
  - First-class Missions, unified delegation lineage, durable live-event delivery, bounded Finance bridge behavior, and restart-safe durable job supervision must all be green.
- `python -m pytest test_operator_autopilot.py test_operator_autopilot_scheduler.py test_operator_autopilot_advance.py test_operator_autopilot_frontier.py test_operator_autopilot_recovery.py test_operator_autopilot_limits.py test_operator_autopilot_wakeup.py test_operator_autopilot_status.py test_operator_mission_supersede.py test_operator_plan_rework.py test_ui_autopilot.py test_operator_autopilot_deliverables.py test_operator_autopilot_acceptance.py`
  - Autopilot must stay default off (tools registered only with `HERMES_GPT_AUTOPILOT=1`), must never dispatch or advance an approval or `high_impact` node, must never approve or complete a Mission, must complete nodes only on observed evidence, must hold new dispatch when the budget envelope is not verifiably within its limit, and must keep the same worker across an MCP server restart. The `superseded_by` marker tests (a forged or stale marker has no effect) must be green.
- `python -m pytest -q test_v015_registration.py test_v016_registration.py test_tool_inventory.py test_tool_profiles.py test_operator_owner_inbox.py test_operator_review.py test_operator_review_assist.py test_ui_owner_inbox.py test_operator_attention_delivery.py`
  - Owner inbox read-only behavior and acknowledgement, the whole review-acceptance store read for contract validation, review-assist gates and evidence isolation, attention relay gating, tool profiles, and the default/gated tool inventory must be green.
- Run the Agent readiness and skill-loader tests under both MCP SDK families; readiness must keep the `health` gate, suppress private paths/raw output, and never launch a subprocess or submit a turn. Verify bounded help output/time in the existing authorized session-preflight path. Verify modern and legacy pinned Agent loader CI jobs independently.
- Run the Windows/Linux Python 3.10-3.12 CI matrix.
- Run `npm ci`, `npm test`, and `npm run build` in `web/`; verify installed `/ui/ops/missions` navigation and read-only Autopilot supervision.

## 3. Release doctor

- Run `hermes_release_doctor(full_tests=true)`.
- Require `PASS` or understood non-blocking `WARN` results.
- Do not publish with `BLOCKED`.
- Confirm the server is not accidentally left in direct/Owner posture as part of release preparation.

## 4. Package build and hygiene

- Build the web UI first; confirm a clean wheel installation resolves the bundled Flight Deck index and assets.
- `python -m build`
- `python -m twine check dist/*`
- Confirm wheel and sdist contain the current public docs expected by `pyproject.toml` / `MANIFEST.in`, including:
  - `README.md`
  - `docs/README.md`
  - `docs/operator-mode.md`
  - `docs/codex.md`
  - `docs/session-history.md`
  - `docs/session-control.md`
  - `docs/windows-chatgpt-codex.md`
  - `docs/updating.md`
  - `docs/runtime-checkout.md`
  - `docs/agent-readiness.md`
  - `docs/jev.md`
  - `docs/owner-inbox.md`
  - `docs/attention-delivery.md`
  - `docs/review-assist.md`
  - `docs/vnext-capability-manifest-and-mission-ledger.md`
  - `docs/retention-policy.md`
  - `docs/release-notes-v0.16.0.md` (and the current release notes for any later release)
- Run `python tools/check_package_hygiene.py dist/*` and require exit `0` / `CLEAN`.
- Confirm package artifacts contain no absolute private machine paths, RFC1918/Tailscale addresses, machine hostnames, live operational metrics, or private release-planning packets.

## 5. Security invariants

- Confirm default tools exclude write, patch, terminal, session search/history, and session control unless their explicit gates are enabled.
- With `HERMES_GPT_ENABLE_SESSION_SEARCH=1`, confirm `hermes_session_search`, `hermes_session_list`, `hermes_session_read`, `hermes_session_export`, and the canonical `hermes_bot_chat_get` resolver are exposed. `hermes_bot_chat_send` additionally requires `HERMES_GPT_ENABLE_SESSION_CONTROL=1`.
- Confirm session history defaults to `user`/`assistant`; internal roles require `HERMES_GPT_ENABLE_SESSION_INTERNAL_CONTENT=1`.
- Confirm session export stays in memory, enforces message/response bounds, creates no files or paths, and fails closed for lineage.
- Confirm unavailable session FTS/search reports an unavailable limitation rather than falsely reporting no matches.
- Confirm the default surface includes `hermes_owner_inbox` (read-only) and excludes `hermes_review_assess` unless both `HERMES_GPT_ENABLE_JEV=1` and `HERMES_GPT_REVIEW_ASSIST=1` are set. `HERMES_GPT_TOOL_PROFILE` only removes tools; it never adds a tool or bypasses an env gate, a confirm or dry-run check, or Operator/Owner policy.
- Confirm session-control jobs use fixed argv with `shell=False`, persist no raw prompt, enforce concurrency/timeout/result bounds, redact results, and fail closed on restart reconciliation.
- Confirm Mission Control never returns raw messages, memory bodies, transcripts, request dumps, credentials, tokens, or profile-secret bodies.
- Confirm Mission Control allowlist semantics match implementation:
  - unset = all read-only Mission surfaces;
  - explicit list = listed valid surfaces only;
  - empty = none.
- Confirm runner metadata and Operator audit records contain no raw prompts.
- Confirm danger/bypass argv cannot be constructed through protected execution paths.
- Confirm Owner Mode still denies secret paths.
- Confirm `--profile remote` requires configured authentication and the existing TLS/loopback-proxy boundary. With neither authentication nor the two-part unsafe acknowledgement, startup must refuse; the unsafe no-auth experiment path is not release-safe.
- Confirm README still states public unauthenticated Operator exposure is unsupported.
- Confirm attention delivery is default off: `HERMES_GPT_ATTENTION_DELIVERY` must be exactly `1`, targets and executables come only from administrator environment variables (no MCP tool sets them), and the relay is notification-only. Its messages never carry approvals or commands, and no MCP tool sends. `hermes_attention_delivery_status` is the only MCP surface and is read-only.
- Confirm `POST /api/ops/action` refuses cross-site requests before parsing the body: a non-JSON `Content-Type` returns `415 UNSUPPORTED_MEDIA_TYPE`, and a foreign `Sec-Fetch-Site` or `Origin` returns `403 CROSS_SITE_REFUSED`.
- Confirm browser approvals still enforce Owner gates server-side. Mission approval needs Owner Mode in `hermes_mission_approve`, browser approval-node transitions need Owner Mode in the `ui_ops` precheck and are limited to approval and `high_impact` nodes, Autopilot stop and inbox acknowledgement need workspace level with direct apply mode, and none of them bypasses the tool's own gate.

## 6. Retention

- Confirm `docs/retention-policy.md` matches current implementation.
- Confirm Codex artifact cleanup still uses the implemented 30-day reconciliation window.
- Confirm request-dump and Swarm cleanup windows are actionable and are not falsely described as a global automatic deletion daemon.

## 7. Update behavior

- `hermes-gpt update --help`
- Run the check-only `hermes-gpt update` path and confirm it does not modify the checkout/package.
- Confirm Git checkout updates remain clean-tree, default-branch, fast-forward-only.
- Confirm installed-package updates check PyPI independently of GitHub release state.

## 8. Private-file scan

Confirm release artifacts do not contain:

- `*.pem`
- `*.key`
- `*.log`
- `*.err.log`
- `.env` / `.env.*`
- auth/token/cookie files
- `__pycache__/`
- `.pytest_cache/`
- internal `docs/design/*`
- internal `docs/releases/*`

## 9. Documentation consistency

Before publication, inspect at minimum:

- `README.md`
- `docs/README.md`
- `docs/operator-mode.md`
- `docs/codex.md`
- `docs/session-history.md`
- `docs/session-control.md`
- `docs/windows-chatgpt-codex.md`
- `docs/updating.md`
- `docs/retention-policy.md`
- `docs/agent-readiness.md`
- current release notes
- `CHANGELOG.md`

Check exact tool names and environment variables against the implementation. In particular, do not confuse main-server `hermes_web_extract` with Codex-focused MCP `hermes_extract_page`.

## 10. Publication

Only after the checks above pass:

- authorize the intended channels before pushing the tag: every `v*` tag (including RC tags) triggers CI and the PyPI publishing job through the `pypi` environment;
- create/push the intended tag only when PyPI publication is intended;
- publish the GitHub release artifacts;
- verify the tag-triggered PyPI workflow publishes the exact CI `distributions` artifact; do not rebuild or blindly retry an uncertain upload;
- verify the public version on each published channel;
- restart/reconnect any live MCP deployments whose tool schema changed;
- for ChatGPT MCP apps/connectors, refresh or rescan the app actions after any tool-schema change and review/enable newly discovered actions before acceptance. ChatGPT may retain a frozen approved tool snapshot even after the MCP server and tunnel restart; if the workspace/plan does not expose an action refresh, recreate/re-publish the app connection;
- verify the refreshed ChatGPT action count/set against the live MCP `tools/list`, then prove representative newly added tools from a new chat;
- run the automated connector acceptance gate `python -m pytest -q test_server.py::test_v09_connector_surface_acceptance` (Finance enabled, optional env gates neutralized): it must report the exact expected tool count (140 with Finance enabled (`HERMES_GPT_ENABLE_FINANCE=1`, which the gate sets) and every other optional gate neutralized: 137 through v0.14, plus `hermes_owner_inbox` in v0.15, `hermes_owner_inbox_ack` in v0.16 and `hermes_plan_approve_gate` in v0.16.1. With every optional gate unset the count is 139; the v0.12 slice-2 budget-enforcement and controller-L2 rungs add no tools and stay invisible with their machine gates unset) with all release additions present, no duplicates, and `serverInfo.version` equal to `versioning.VERSION` for this checkout;
- confirm the advertised `serverInfo/version` seen by a real MCP client handshake (not just the SDK default) matches the version being published before accepting the connector.
