# Unified Delegation Lifecycle

## v0.14 acceptance and delivery grace

Delegation reads include a bounded `validation` summary (verdict, check kinds/statuses, fixed artifact failure codes) and `validation_failure_since`. No raw validation details or artifact bodies are persisted in these fields. Two metadata columns are migrated only on authorized writes; read-only calls do not migrate existing stores.

Successful backend execution with confirmed bad required artifacts stays `reconciling` for a durable 30-second delivery grace. If the defect remains and every other required check passes, it becomes `failed` with `outcome="validation_failed"`. Autopilot may use its existing bounded semantic replan path. Missing/unreadable evidence, pending required review, authorization failures, and unresolved cancellation do not enter that path and never trigger optimistic redispatch. See [Autopilot acceptance](autopilot.md#declared-deliverable-acceptance-v014).

Hermes GPT v0.9 adds a durable delegation lifecycle above Work Contracts and the existing execution backends. The delegation record is **lineage and state metadata**, not a second execution authority: runner, Fabric, Work Contract validation, and Operator policy remain authoritative for dispatch, observation, cancellation, and completion evidence.

## Tools

- `hermes_delegation_dispatch` — dry-run-first dispatch of a canonical Work Contract with optional Mission linkage.
- `hermes_delegation_get` — read one durable delegation and its bounded lifecycle events.
- `hermes_delegation_list` — list/filter delegation records by Mission or normalized state.
- `hermes_delegation_reconcile` — derive normalized state from authoritative runner/Fabric observations; applying the derived state requires workspace/direct authority.
- `hermes_delegation_cancel` — route cancellation to the selected backend while preserving existing backend cancellation and Operator gates.

Normalized states are `queued`, `running`, `reconciling`, `blocked`, `succeeded`, `failed`, and `cancelled`.

## Data and authority boundaries

The delegation database stores only bounded lineage and lifecycle metadata: delegation id, Mission id, Work Contract task id and SHA-256, selected backend, normalized/backend state, bounded backend references, timestamps, and event hashes. It does **not** store Work Contract objectives/prompts or model responses.

A delegation never marks work successful because a worker says it succeeded. Reconciliation reads the existing runner/Fabric observations for the Work Contract task id, but backend terminal success remains `reconciling` until the matching immutable Work Contract lineage has a `SATISFIED` validation verdict. Missing, unreadable, or `UNVERIFIED` evidence therefore fails closed. When a Work Contract is supplied to reconciliation, its canonical SHA and task id must match the stored lineage before validation can contribute evidence.

Mission linkage uses the existing `delegation` attachment kind. Dispatch creates/updates a pending/running attachment. A Mission attachment becomes `succeeded` only when delegation reconciliation has both authoritative backend completion and a `SATISFIED` Work Contract verdict; that bridge records the contract digest as its verification reference. Cancellation records `cancelled` only when the backend explicitly confirms `cancelled`/`canceled`. Other successful backend responses remain reconciling. An explicit unsuccessful, unchanged backend response releases the provisional cancellation latch; ambiguous failures remain latched for authoritative reconciliation.

An exact cancellation retry does not invoke backend cancellation again while `cancellation_in_progress` is set for that lineage. It returns an explicit in-progress/ambiguous idempotent response and leaves the latch in place for the first caller or authoritative reconciliation.

Authoritative reconciliation resolves that provisional latch only from a terminal backend observation demonstrably ordered after the durable cancellation claim. The observation must carry a parseable, timezone-aware backend terminal timestamp such as `ended_at` or `completed_at`, and that timestamp must be strictly later than `cancellation_claimed_at`. Payload/hash differences, visibility time, generic update time, and equal timestamps do not establish ordering. A backend without a trustworthy post-attempt terminal timestamp or advancing authoritative generation therefore remains latched fail-closed. A post-claim explicit `cancelled`/`canceled` observation promotes durable cancellation; post-claim terminal failure clears the latch and records failure; post-claim terminal completion clears the latch but still requires the normal matching Work Contract validation before success. Missing, stale, ambiguous, unknown, or nonterminal observation retains `cancel_requested` and `cancellation_in_progress` and remains `reconciling`.

## OpenCode backend

v0.9 also adds `opencode` as a first-class local runner backend. Hermes invokes the installed non-interactive OpenCode CLI using `opencode run --format json --pure --dir <workspace>`. The objective is piped over stdin rather than placed on process argv. `--auto` is never enabled by Hermes.

Filesystem authority is enforced externally by the same Hermes confinement layer used for local coding runners. Read-only contracts receive read-only workspace confinement; write-authorized contracts require `workspace-write` posture. Optional `model`, `agent`, and `variant` execution options are bounded, and model selection remains subject to the existing runner model allowlist.

Provider authorization stays in the trusted Hermes worker. The confined OpenCode process receives a fresh per-job random relay capability and a sanitized provider configuration; the loopback relay rejects missing or incorrect capabilities before forwarding and substitutes the upstream authorization only after that check. The upstream authorization is never serialized into the child config, argv, workspace, or child environment.

## Live events

Delegation lifecycle changes publish bounded wake-up events on the v0.9 live-event bus. These notifications are non-authoritative pointers back to durable delegation/runner/Fabric state; notification failure cannot advance or complete work.
