"""Structured, bounded fleet control backed by Hermes A2A.

This module originally shelled out to the legacy hermes-a2a-bridge CLI
(``hermes a2a registry/doctor/send/task``). It now uses the official Hermes
A2A platform surface: peer entries configured under ``a2a_agents`` in
config.yaml are discovered via their Agent Card, and tasks are sent directly
over the A2A v1.0 JSON-RPC protocol. The old CLI runner signature is preserved
for tests; when a bridge binary is still present it is used as a read-only
fallback for registry listing only.
"""

from __future__ import annotations

import concurrent.futures
import hashlib
import json
import os
import re
import shutil
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import operator_policy as op

Runner = Callable[..., tuple[int, str, str]]

# In-process Agent Card cache. When a fleet tool runs inside the same
# hermes-gpt process that serves a peer's card on loopback, an HTTP fetch
# back to that loopback would deadlock the single event loop. Peers may
# register their own card here so loopback verification reads it directly
# instead of round-tripping through the blocked loop.
_LOCAL_AGENT_CARDS: dict[str, dict[str, Any]] = {}


def register_local_agent_card(url: str, card: dict[str, Any]) -> None:
    """Publish this process's own Agent Card for loopback fleet verification."""
    _LOCAL_AGENT_CARDS[url.rstrip("/")] = card


AUTHORITY_MANIFEST_ENV = "HERMES_GPT_FLEET_AUTHORITY_MANIFEST"
A2A_REGISTRY_MODE_ENV = "HERMES_GPT_FLEET_A2A_MODE"
_A2A_DEFAULT_TIMEOUT = 30
_A2A_DEFAULT_REGISTRY_TIMEOUT = 10
_AGENT_RE = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_CARD_IDENTITY_RE = re.compile(r"^[^\x00-\x1f\x7f]{1,128}$")
_PROFILE_RE = re.compile(r"^[a-z][a-z0-9-]{0,63}$")
_TASK_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$")
_ROLE_RE = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]|\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\))")
_AUTH_CLASSES = frozenset({"none", "read_only", "reversible_write", "high_impact"})
_MAX_REMOTE_BYTES = 1_048_576
_MAX_MANIFEST_BYTES = 64_000
_MAX_TEXT = 4_000
_MAX_ITEMS = 64
_BUILTIN_PROFILES = {
    "nous-girl": frozenset({"default"}),
    "rza": frozenset({"default", "gza", "masta-killa", "inspectah-deck", "ghostface-killah", "method-man", "raekwon"}),
    "gaming-4090": frozenset({"default", "media", "gpu-dev"}),
    "macbook-m5": frozenset({"default", "apple", "apple-design", "apple-dev", "apple-qa", "apple-release"}),
    "mac-mini-m5": frozenset({"default"}),
    "omarchy": frozenset({"default"}),
}
_PUBLIC_ACTION_RE = re.compile(
    r"\b(?:"
    r"publish\b"
    r"|post\b(?=.{0,80}\b(?:online|publicly|on\s+(?:x|twitter|facebook|instagram|linkedin))\b)"
    r"|deploy\b(?=.{0,80}\b(?:publicly|public|website|site)\b)"
    r"|send\b(?=.{0,80}\b(?:an?\s+|this\s+|the\s+)?emails?\b)"
    r"|release\b(?=.{0,80}\bpublicly\b)"
    r"|make\b(?=.{0,40}\bpublic\b)"
    r")",
    re.I,
)
_NEGATED_ACTION_RE = re.compile(r"\b(?:do\s+not|don't|never|must\s+not|should\s+not|without)\s+(?:\w+\s+){0,3}$", re.I)
_COMMAND_PREFIX_RE = re.compile(
    r"(?:^|[.!?;:]\s*|(?:\b(?:and|then)\b)\s+)"
    r"(?:please\s+|(?:can|could|would|will)\s+you\s+|you\s+(?:must|should|need\s+to)\s+)?$",
    re.I,
)
_SECRET_RE = re.compile(r"\b(raw|reveal|return|print|show|read|extract|dump|expose)\b.{0,40}\b(secret|token|password|credential|api[_ -]?key|private key|environment values?)s?\b", re.I | re.S)
_VAULT_RE = re.compile(r"\b(vault|credential store)\b.{0,40}\b(policy|policies|edit|write|change|update)\b|\b(edit|write|change|update)\b.{0,40}\b(vault|credential store)\b", re.I | re.S)
_FLEET_POLICY_ACTION_RE = re.compile(
    r"\b(?:edit|write|change|update|modify|replace|delete|create)\b.{0,80}"
    r"\b(?:fleet|authority)\s+(?:policy|manifest|rules?)\b"
    r"|\b(?:fleet|authority)\s+(?:policy|manifest|rules?)\b.{0,80}"
    r"\b(?:edit|write|change|update|modify|replace|delete|create)\b",
    re.I | re.S,
)
_CHILD_MCP_ACTION_RE = re.compile(
    r"\b(?:enable|allow|turn\s+on|set)\b.{0,80}"
    r"\b(?:inherit_mcp_toolsets|(?:child|subagent|delegate)\b.{0,40}"
    r"\b(?:mcp|toolsets?|inherit(?:ance)?))"
    r"|\binherit_mcp_toolsets\b.{0,40}\b(?:true|on|enabled)\b",
    re.I | re.S,
)


@dataclass(frozen=True)
class AuthorityPeer:
    name: str
    expected_host_role: str
    expected_card_identity: str
    allowed_profiles: tuple[str, ...]
    max_authorization: str
    allow_public_actions: bool = False


class PeerVerificationError(RuntimeError):
    """A live Agent Card could not be safely matched to local authority."""


class FleetDispatchTimeout(TimeoutError):
    """A peer may have accepted a task even though the reply timed out.

    ``task_id`` is the peer-assigned A2A task id recovered by context lookup,
    not the local JSON-RPC request id.
    """

    def __init__(self, task_id: str):
        super().__init__("timed out awaiting A2A peer reply")
        self.task_id = task_id


def _a2a_mode() -> str:
    """Return the configured A2A backend mode: 'official', 'bridge', or 'auto'."""
    value = os.environ.get(A2A_REGISTRY_MODE_ENV, "auto").strip().lower()
    if value in {"official", "bridge", "auto"}:
        return value
    return "auto"


def _hermes_bin(hermes_root: Path | None = None) -> str | None:
    configured = os.environ.get("HERMES_CLI", "").strip()
    if configured:
        candidate = Path(configured).expanduser()
        if candidate.is_file():
            return str(candidate)
    root = hermes_root or op.normalize_hermes_data_root(os.environ.get("HERMES_HOME"))
    if root:
        for candidate in (root / "hermes-agent" / "venv" / "bin" / "hermes", root / "hermes-agent" / "venv" / "Scripts" / "hermes.exe"):
            if candidate.is_file():
                return str(candidate)
    discovered = shutil.which("hermes")
    if discovered:
        return discovered
    local_bin = Path.home() / ".local" / "bin" / "hermes"
    if local_bin.is_file():
        return str(local_bin)
    return None


def _bridge_available(hermes_bin: str) -> bool:
    """Best-effort check: does the given Hermes binary still provide the 'a2a' subcommand?"""
    if not hermes_bin:
        return False
    if hermes_bin == "/test/hermes":
        return True
    try:
        code, _, _ = op.run_argv([hermes_bin, "a2a", "--help"], timeout=5, max_output_chars=1_000)
        return code == 0
    except Exception:
        return False


def _run(argv: list[str], *, timeout: int, runner: Runner | None) -> tuple[int, str, str]:
    return (
        runner(argv, timeout=timeout)
        if runner is not None
        else op.run_argv(argv, timeout=timeout, max_output_chars=_MAX_REMOTE_BYTES)
    )


# ---------------------------------------------------------------------------
# Official A2A surface (urllib, stdlib only, no hermes-a2a-bridge dependency)
# ---------------------------------------------------------------------------

def _load_hermes_config() -> dict[str, Any]:
    """Load Hermes config.yaml, best-effort, without importing heavy internals."""
    try:
        from hermes_cli.config import load_config
        return load_config() or {}
    except Exception:
        return {}


def _a2a_peers() -> dict[str, dict[str, Any]]:
    """Return the configured a2a_agents mapping from Hermes config.yaml."""
    return _load_hermes_config().get("a2a_agents") or {}


def _auth_header(peer: dict[str, Any]) -> dict[str, str]:
    auth = peer.get("auth") or {}
    if auth.get("type") == "bearer" and auth.get("token"):
        token = _resolve_env_token(auth["token"])
        if token:
            return {"Authorization": f"Bearer {token}"}
    return {}


def _resolve_env_token(token: str) -> str:
    if token.startswith("${env:") and token.endswith("}"):
        name = token[6:-1].strip()
        return os.environ.get(name, "")
    return token


def _a2a_peers_with_resolved_tokens() -> dict[str, dict[str, Any]]:
    """Return a2a_agents with any ${env:NAME} bearer tokens resolved."""
    peers = _a2a_peers()
    out: dict[str, dict[str, Any]] = {}
    for name, entry in peers.items():
        entry = dict(entry)
        auth = entry.get("auth") or {}
        if auth.get("type") == "bearer" and isinstance(auth.get("token"), str):
            auth = dict(auth)
            auth["token"] = _resolve_env_token(auth["token"])
            entry["auth"] = auth
        out[name] = entry
    return out


def _http_get_json(url: str, headers: dict[str, str], timeout: int) -> dict[str, Any]:
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        data = resp.read()
        if len(data) > _MAX_REMOTE_BYTES:
            raise ValueError("A2A discovery response exceeded the bounded response limit")
        return json.loads(data.decode("utf-8"))


def _http_get_json_threaded(url: str, headers: dict[str, str], timeout: int) -> dict[str, Any]:
    """Run the blocking GET off the caller's event loop.

    When the fleet tool runs inside the same hermes-gpt process that also
    serves the peer's Agent Card, a blocking same-loopback fetch would
    deadlock (the inbound request can never be accepted while the loop is
    blocked). Offloading to a worker thread lets the inbound request through.
    """
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
        return ex.submit(_http_get_json, url, headers, timeout).result()


def _http_post_json(url: str, body: dict[str, Any], headers: dict[str, str], timeout: int) -> dict[str, Any]:
    data = json.dumps(body).encode("utf-8")
    hdrs = {"Content-Type": "application/json", "A2A-Version": "1.0", **headers}
    req = urllib.request.Request(url, data=data, headers=hdrs, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        return json.loads(resp.read().decode("utf-8"))


def _card_url(base_url: str) -> str:
    return base_url.rstrip("/") + "/.well-known/agent-card.json"


def _fetch_card(base_url: str, headers: dict[str, str], timeout: int) -> dict[str, Any]:
    # Short-circuit loopback fetches to avoid the same-process event-loop
    # deadlock: the card is served by this very process, so read it directly.
    key = base_url.rstrip("/")
    if key in _LOCAL_AGENT_CARDS:
        return _LOCAL_AGENT_CARDS[key]
    try:
        return _http_get_json_threaded(_card_url(base_url), headers, timeout)
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise
    return _http_get_json_threaded(base_url.rstrip("/") + "/.well-known/agent.json", headers, timeout)


def _jsonrpc_interface(card: dict[str, Any] | None) -> dict[str, Any] | None:
    if isinstance(card, dict):
        for iface in card.get("supportedInterfaces", []) or []:
            if isinstance(iface, dict) and iface.get("protocolBinding") == "JSONRPC" and isinstance(iface.get("url"), str):
                return iface
    return None


def _rpc_url(base_url: str, card: dict[str, Any] | None) -> str:
    iface = _jsonrpc_interface(card)
    if iface is not None:
        return str(iface["url"])
    if isinstance(card, dict) and isinstance(card.get("url"), str) and card["url"]:
        return card["url"]
    return base_url.rstrip("/")


def _interface_tenant(card: dict[str, Any] | None, peer: dict[str, Any]) -> str:
    iface = _jsonrpc_interface(card)
    if iface is not None and iface.get("tenant"):
        return str(iface["tenant"])
    return str(peer.get("tenant") or "")


def _send_message(agent: str, peer: dict[str, Any], text: str, timeout: int) -> dict[str, Any]:
    base_url = peer.get("url", "")
    if not isinstance(base_url, str) or not base_url.startswith(("http://", "https://")):
        raise ValueError(f"peer '{agent}' has no valid URL")

    headers = _auth_header(peer)
    cap = max(5, min(int(timeout), 120))
    card: dict[str, Any] | None = None
    try:
        card = _fetch_card(base_url, headers, min(cap, 30))
    except Exception as exc:
        # Non-fatal: fall back to configured base URL / legacy path if card is unreachable.
        pass

    rpc_url = _rpc_url(base_url, card)
    request_id = f"req-{hashlib.sha256((agent + text + str(os.urandom(8))).encode()).hexdigest()[:16]}"
    context_id = f"ctx-{hashlib.sha256((request_id + str(os.urandom(8))).encode()).hexdigest()[:16]}"
    body = {
        "jsonrpc": "2.0",
        "id": request_id,
        "method": "SendMessage",
        "params": {
            "message": {
                "role": "ROLE_USER",
                "parts": [{"text": text, "mediaType": "text/plain"}],
                "messageId": request_id.replace("req-", "msg-"),
                "contextId": context_id,
            },
        },
    }
    tenant = _interface_tenant(card, peer)
    if tenant:
        body["params"]["tenant"] = tenant

    def recover_task_id() -> str:
        lookup = {
            "jsonrpc": "2.0",
            "id": f"lookup-{request_id}",
            "method": "ListTasks",
            "params": {
                "contextId": context_id,
                "pageSize": 5,
                "includeArtifacts": False,
                "historyLength": 0,
            },
        }
        if tenant:
            lookup["params"]["tenant"] = tenant
        recovered = _http_post_json(rpc_url, lookup, headers, min(max(cap, 5), 15))
        result = recovered.get("result", {}) if isinstance(recovered, dict) else {}
        tasks = result.get("tasks", []) if isinstance(result, dict) else []
        matches = [
            item.get("id") for item in tasks
            if isinstance(item, dict) and isinstance(item.get("id"), str) and _TASK_ID_RE.fullmatch(item["id"])
        ]
        if len(matches) != 1:
            raise RuntimeError("could not uniquely recover peer task after timeout")
        return matches[0]

    try:
        resp = _http_post_json(rpc_url, body, headers, cap)
    except TimeoutError as exc:
        raise FleetDispatchTimeout(recover_task_id()) from exc
    except urllib.error.URLError as exc:
        if isinstance(getattr(exc, "reason", None), TimeoutError):
            raise FleetDispatchTimeout(recover_task_id()) from exc
        raise
    if not isinstance(resp, dict):
        raise ValueError("A2A peer returned a non-JSON-RPC response")
    if "error" in resp:
        err = resp["error"]
        raise RuntimeError(f"A2A peer returned error: {err.get('message', err)}")
    return resp.get("result", {})


def _get_task(agent: str, peer: dict[str, Any], task_id: str, timeout: int) -> dict[str, Any]:
    base_url = peer.get("url", "")
    headers = _auth_header(peer)
    cap = max(1, min(int(timeout), 60))
    card: dict[str, Any] | None = None
    try:
        card = _fetch_card(base_url, headers, min(cap, 30))
    except Exception:
        pass
    rpc_url = _rpc_url(base_url, card)
    body = {
        "jsonrpc": "2.0",
        "id": task_id,
        "method": "GetTask",
        "params": {"id": task_id},
    }
    tenant = _interface_tenant(card, peer)
    if tenant:
        body["params"]["tenant"] = tenant
    resp = _http_post_json(rpc_url, body, headers, cap)
    if not isinstance(resp, dict):
        raise ValueError("A2A peer returned a non-JSON-RPC response")
    if "error" in resp:
        err = resp["error"]
        raise RuntimeError(f"A2A peer returned error: {err.get('message', err)}")
    return resp.get("result", {})


def _unwrap_task(payload: dict[str, Any]) -> dict[str, Any]:
    current: Any = payload
    for _ in range(8):
        if not isinstance(current, dict):
            break
        if isinstance(current.get("task"), dict):
            current = current["task"]
        elif isinstance(current.get("result"), dict):
            current = current["result"]
        elif isinstance(current.get("data"), dict):
            current = current["data"]
        else:
            break
    if not isinstance(current, dict):
        raise ValueError("A2A task lookup returned an invalid task shape")
    return current


def _registry_official(*, timeout: int = _A2A_DEFAULT_REGISTRY_TIMEOUT) -> list[dict[str, Any]]:
    """List configured A2A peers by reading config.yaml a2a_agents and probing cards."""
    peers = _a2a_peers_with_resolved_tokens()
    clean: list[dict[str, Any]] = []
    cap = max(1, min(int(timeout), 30))
    for name, entry in peers.items():
        if not _AGENT_RE.fullmatch(name):
            continue
        url = entry.get("url", "")
        if not isinstance(url, str) or not url.startswith(("http://", "https://")):
            continue
        has_token = bool((_auth_header(entry) or {}).get("Authorization"))
        try:
            _fetch_card(url, _auth_header(entry), cap)
        except Exception:
            pass
        clean.append({"name": name, "has_token": has_token})
    return clean


def _registry_bridge(*, runner: Runner | None, hermes_bin: str | None) -> tuple[list[dict[str, Any]], str | None]:
    binary = hermes_bin or _hermes_bin()
    if not binary:
        raise RuntimeError("Hermes CLI was not found and no A2A peers are configured.")
    code, stdout, stderr = _run([binary, "a2a", "registry", "list", "--json"], timeout=15, runner=runner)
    if code != 0:
        raise RuntimeError(op.redact_output(stderr or "A2A registry lookup failed"))
    agents = _parse_json(stdout, operation="A2A registry lookup").get("agents", [])
    if not isinstance(agents, list) or len(agents) > 256:
        raise ValueError("A2A registry returned an invalid agents list")
    clean = []
    for item in agents:
        if isinstance(item, dict) and isinstance(item.get("name"), str) and _AGENT_RE.fullmatch(item["name"]) and isinstance(item.get("url"), str):
            clean.append({"name": item["name"], "has_token": bool(item.get("hasToken"))})
    return clean, binary


def _registry(*, runner: Runner | None, hermes_bin: str | None, timeout: int = _A2A_DEFAULT_REGISTRY_TIMEOUT) -> tuple[list[dict[str, Any]], str | None]:
    mode = _a2a_mode()
    if mode == "bridge":
        return _registry_bridge(runner=runner, hermes_bin=hermes_bin)
    if mode == "official":
        return _registry_official(timeout=timeout), None

    # auto: prefer official config; fall back to the bridge CLI if it is still available.
    official = _registry_official(timeout=timeout)
    if official:
        return official, None
    try:
        bridge, binary = _registry_bridge(runner=runner, hermes_bin=hermes_bin)
        return bridge, binary
    except Exception:
        return [], None



def _error(code: str, message: str, action: str) -> str:
    return json.dumps(op.make_error_envelope(layer="operator", code=code, safe_message=message, suggested_action=action), indent=2)


def _dispatch_timeout_error(agent: str, task_id: str) -> str:
    payload = op.make_error_envelope(
        layer="operator",
        code="FLEET_DISPATCH_TIMEOUT",
        safe_message="timed out awaiting A2A peer reply; remote task state is unknown",
        suggested_action="Call hermes_fleet_task with the returned task_id before retrying dispatch.",
    )
    payload.update({
        "agent": agent,
        "task_id": task_id,
        "submission_may_have_succeeded": True,
    })
    return json.dumps(payload, indent=2)


def _clean_text(value: Any, *, field: str, maximum: int = _MAX_TEXT, required: bool = True) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be a string")
    value = _CONTROL_RE.sub("", value).strip()
    if required and not value:
        raise ValueError(f"{field} must not be empty")
    if len(value.encode("utf-8")) > maximum:
        raise ValueError(f"{field} exceeds its {maximum} byte limit")
    return value


def _string_list(value: Any, *, field: str, maximum: int = _MAX_ITEMS) -> list[str]:
    if not isinstance(value, list) or len(value) > maximum:
        raise ValueError(f"{field} must be a list with at most {maximum} items")
    return [_clean_text(item, field=f"{field} item", maximum=1_000) for item in value]


def _parse_json(stdout: str, *, operation: str) -> dict[str, Any]:
    if not isinstance(stdout, str):
        raise ValueError(f"{operation} returned invalid UTF-8 text")
    if len(stdout.encode("utf-8")) > _MAX_REMOTE_BYTES:
        raise ValueError(f"{operation} response exceeded the bounded response limit")
    cleaned = _CONTROL_RE.sub("", stdout).lstrip("\ufeff")
    decoder = json.JSONDecoder()
    for match in re.finditer(r"[\{\[]", cleaned):
        try:
            parsed, _ = decoder.raw_decode(cleaned[match.start():])
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            return parsed
    if cleaned.rstrip().endswith(("{", "[", ",", ":")) or cleaned.count("{") > cleaned.count("}"):
        raise ValueError(f"{operation} returned truncated JSON")
    raise ValueError(f"{operation} returned invalid JSON")


def _registry(*, runner: Runner | None, hermes_bin: str | None, timeout: int = _A2A_DEFAULT_REGISTRY_TIMEOUT) -> tuple[list[dict[str, Any]], str | None]:
    mode = _a2a_mode()
    if mode == "bridge":
        return _registry_bridge(runner=runner, hermes_bin=hermes_bin)
    if mode == "official":
        return _registry_official(timeout=timeout), None

    # auto: prefer official config; fall back to the bridge CLI if it is still available.
    official = _registry_official(timeout=timeout)
    if official:
        return official, None
    try:
        bridge, binary = _registry_bridge(runner=runner, hermes_bin=hermes_bin)
        return bridge, binary
    except Exception:
        return [], None



def _registered_agent(agent: str, *, runner: Runner | None, hermes_bin: str | None) -> tuple[str, str | None]:
    if not isinstance(agent, str) or not _AGENT_RE.fullmatch(agent):
        raise ValueError("agent must be a registered peer name")
    agents, binary = _registry(runner=runner, hermes_bin=hermes_bin)
    if agent not in {item["name"] for item in agents}:
        raise LookupError("unknown registered peer")
    return agent, binary


def _manifest_path(path: Path | None = None) -> Path:
    if path is None:
        configured = os.environ.get(AUTHORITY_MANIFEST_ENV)
        if configured:
            path = Path(configured)
        else:
            root = op.normalize_hermes_data_root(os.environ.get("HERMES_HOME")) or (Path.home() / ".hermes")
            path = root / "config" / "fleet-authority.json"
    path = path.expanduser()
    if not path.is_absolute():
        raise ValueError("authority manifest path must be absolute")
    if op.is_denied_path(path):
        raise PermissionError("authority manifest path is denied by the secret-path policy")
    if path.is_symlink():
        raise PermissionError("authority manifest must not be a symbolic link")
    return path


def _load_authority(path: Path | None = None) -> dict[str, AuthorityPeer]:
    manifest_path = _manifest_path(path)
    data = manifest_path.read_bytes()
    if len(data) > _MAX_MANIFEST_BYTES:
        raise ValueError("authority manifest exceeds 64 KB")
    try:
        raw = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("authority manifest is not valid UTF-8 JSON") from exc
    if not isinstance(raw, dict) or set(raw) - {"version", "peers"} or raw.get("version") != 1 or not isinstance(raw.get("peers"), list):
        raise ValueError("authority manifest schema is invalid")
    peers: dict[str, AuthorityPeer] = {}
    for item in raw["peers"]:
        allowed_keys = {"name", "expected_host_role", "expected_card_identity", "allowed_profiles", "max_authorization", "allow_public_actions"}
        if not isinstance(item, dict) or set(item) - allowed_keys:
            raise ValueError("authority peer schema is invalid")
        name = item.get("name")
        role = item.get("expected_host_role")
        identity = item.get("expected_card_identity")
        profiles = item.get("allowed_profiles")
        auth = item.get("max_authorization", "read_only")
        if not isinstance(name, str) or not _AGENT_RE.fullmatch(name) or name in peers:
            raise ValueError("authority peer name is invalid or duplicated")
        if name not in _BUILTIN_PROFILES:
            # Unknown manifest peer: admit it at the lowest profile ceiling instead of
            # rejecting the whole manifest. A freshly enrolled machine is therefore valid
            # but bounded to the default profile only (the ceiling check below still holds).
            _BUILTIN_PROFILES[name] = frozenset({"default"})
        if not isinstance(role, str) or not _ROLE_RE.fullmatch(role):
            raise ValueError("expected_host_role is invalid")
        if (
            not isinstance(identity, str)
            or identity != identity.strip()
            or not _CARD_IDENTITY_RE.fullmatch(identity)
        ):
            raise ValueError("expected_card_identity is invalid")
        if not isinstance(profiles, list) or not profiles or len(profiles) > 16 or any(not isinstance(p, str) or not _PROFILE_RE.fullmatch(p) for p in profiles):
            raise ValueError("allowed_profiles is invalid")
        if not set(profiles) <= _BUILTIN_PROFILES[name]:
            raise PermissionError("authority manifest exceeds the built-in profile ceiling")
        if auth not in _AUTH_CLASSES:
            raise ValueError("max_authorization is invalid")
        public = item.get("allow_public_actions", False)
        if not isinstance(public, bool) or (name == "nous-girl" and public):
            raise PermissionError("Nous Girl may not receive public actions")
        peers[name] = AuthorityPeer(name, role, identity, tuple(sorted(set(profiles))), auth, public)
    return peers


def _unwrap_task(payload: dict[str, Any]) -> dict[str, Any]:
    current: Any = payload
    for _ in range(8):
        if not isinstance(current, dict):
            break
        if isinstance(current.get("task"), dict):
            current = current["task"]
        elif isinstance(current.get("result"), dict):
            current = current["result"]
        elif isinstance(current.get("data"), dict):
            current = current["data"]
        else:
            break
    if not isinstance(current, dict):
        raise ValueError("A2A task lookup returned an invalid task shape")
    return current


def _authorization(value: Any) -> dict[str, Any]:
    if isinstance(value, str):
        value = {"class": value}
    if not isinstance(value, dict) or set(value) - {"class", "approved", "approved_by", "approval_reference"}:
        raise ValueError("authorization metadata has invalid fields")
    auth_class = value.get("class")
    if auth_class not in _AUTH_CLASSES:
        raise ValueError("authorization class is invalid")
    approved = value.get("approved", False)
    if not isinstance(approved, bool):
        raise ValueError("authorization.approved must be boolean")
    result: dict[str, Any] = {"class": auth_class, "approved": approved}
    for key in ("approved_by", "approval_reference"):
        if key in value:
            result[key] = _clean_text(value[key], field=f"authorization.{key}", maximum=128)
    if auth_class == "high_impact" and (not approved or "approved_by" not in result or "approval_reference" not in result):
        raise PermissionError("high-impact work requires explicit approval metadata")
    return result


def _requests_affirmative_action(objective: str, pattern: re.Pattern[str]) -> bool:
    for match in pattern.finditer(objective):
        prefix = objective[max(0, match.start() - 48):match.start()]
        if _COMMAND_PREFIX_RE.search(prefix) and not _NEGATED_ACTION_RE.search(prefix):
            return True
    return False


def _requests_public_action(objective: str) -> bool:
    """Detect affirmative public-action commands without scanning supporting fields."""
    return _requests_affirmative_action(objective, _PUBLIC_ACTION_RE)


def _requests_fleet_policy_change(objective: str) -> bool:
    return _requests_affirmative_action(objective, _FLEET_POLICY_ACTION_RE)


def _requests_child_mcp_inheritance(objective: str) -> bool:
    return _requests_affirmative_action(objective, _CHILD_MCP_ACTION_RE)


def _work_order_text_fields(envelope: dict[str, Any]) -> list[str]:
    values = [envelope["objective"]]
    for field in ("inputs", "constraints", "acceptance_checks", "deliverables"):
        values.extend(envelope[field])
    return values


def _requests_raw_secret(envelope: dict[str, Any]) -> bool:
    return any(_requests_affirmative_action(text, _SECRET_RE) for text in _work_order_text_fields(envelope))


def _requests_vault_policy_change(envelope: dict[str, Any]) -> bool:
    return any(_requests_affirmative_action(text, _VAULT_RE) for text in _work_order_text_fields(envelope))


def _canonical_work_order(*, agent: Any, task_id: Any, target_profile: Any, objective: Any, workspace: Any,
                          inputs: Any, constraints: Any, acceptance_checks: Any, deliverables: Any, authorization: Any) -> tuple[str, dict[str, Any]]:
    if not isinstance(agent, str) or not _AGENT_RE.fullmatch(agent):
        raise ValueError("agent is invalid")
    if not isinstance(task_id, str) or not _TASK_ID_RE.fullmatch(task_id):
        raise ValueError("task_id has an invalid format")
    if not isinstance(target_profile, str) or not _PROFILE_RE.fullmatch(target_profile):
        raise ValueError("target_profile is invalid")
    objective_text = _clean_text(objective, field="objective", maximum=8_000)
    workspace_text = _clean_text(workspace, field="workspace", maximum=1_000)
    if op.is_denied_path(workspace_text):
        raise PermissionError("workspace is denied by the secret-path policy")
    auth = _authorization(authorization)
    envelope = {
        "schema": "hermes.fleet.work-order/v1",
        "agent": agent,
        "task_id": task_id,
        "target_profile": target_profile,
        "objective": objective_text,
        "workspace": workspace_text,
        "inputs": _string_list(inputs, field="inputs"),
        "constraints": _string_list(constraints, field="constraints"),
        "acceptance_checks": _string_list(acceptance_checks, field="acceptance_checks"),
        "deliverables": _string_list(deliverables, field="deliverables"),
        "authorization": auth,
    }
    canonical = json.dumps(envelope, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if len(canonical.encode("utf-8")) > 32_000:
        raise ValueError("canonical work order exceeds 32 KB")
    return canonical, envelope


def _authorize_order(peer: AuthorityPeer, envelope: dict[str, Any], canonical: str) -> None:
    if envelope["target_profile"] not in peer.allowed_profiles:
        raise PermissionError("target profile is not authorized for this peer")
    ranks = {"none": 0, "read_only": 1, "reversible_write": 2, "high_impact": 3}
    if ranks[envelope["authorization"]["class"]] > ranks[peer.max_authorization]:
        raise PermissionError("request exceeds peer role authority")
    if _requests_raw_secret(envelope):
        raise PermissionError("raw-secret requests are forbidden")
    if _requests_vault_policy_change(envelope):
        raise PermissionError("Vault-policy edits by peers are forbidden")
    if _requests_fleet_policy_change(envelope["objective"]):
        raise PermissionError("fleet-policy edits by peers are forbidden")
    if _requests_child_mcp_inheritance(envelope["objective"]):
        raise PermissionError("child MCP inheritance is forbidden")
    if _requests_public_action(envelope["objective"]) and (peer.name == "nous-girl" or not peer.allow_public_actions):
        raise PermissionError("public actions are not authorized for this peer")


def _verify_live_peer(peer: AuthorityPeer, binary: str | None, timeout: int, runner: Runner | None) -> None:
    """Verify the live peer's Agent Card matches the authority manifest.

    Uses the official A2A surface when no bridge binary is available. The bridge
    CLI's ``a2a doctor`` output is still accepted if binary is present.
    """
    capped = max(1, min(int(timeout), 30))
    if binary and _bridge_available(binary):
        code, stdout, _ = _run(
            [binary, "a2a", "doctor", peer.name, "--timeout", str(capped), "--json"],
            timeout=capped + 5,
            runner=runner,
        )
        if code != 0:
            raise PeerVerificationError("peer verification failed")
        try:
            card = _parse_json(stdout, operation="A2A peer verification")
        except (TypeError, ValueError) as exc:
            raise PeerVerificationError("peer verification failed") from exc
        identity = card.get("name") or card.get("identity")
        host_role = card.get("host_role") or card.get("role")
        if card.get("ok") is not True:
            raise PeerVerificationError("peer verification failed")
        if (
            not isinstance(identity, str)
            or identity != identity.strip()
            or not _CARD_IDENTITY_RE.fullmatch(identity)
        ):
            raise PeerVerificationError("peer verification failed")
        if not isinstance(host_role, str) or not _ROLE_RE.fullmatch(host_role):
            raise PeerVerificationError("peer verification failed")
        if identity != peer.expected_card_identity or host_role != peer.expected_host_role:
            raise PeerVerificationError("peer verification failed")
        return

    # Official A2A path: fetch the Agent Card directly from the configured peer URL.
    peers = _a2a_peers_with_resolved_tokens()
    entry = peers.get(peer.name)
    if not entry or not isinstance(entry.get("url"), str):
        raise PeerVerificationError("peer verification failed")
    headers = _auth_header(entry)
    try:
        card = _fetch_card(entry["url"], headers, capped)
    except Exception as exc:
        raise PeerVerificationError("peer verification failed") from exc
    if not isinstance(card, dict):
        raise PeerVerificationError("peer verification failed")
    identity = card.get("name")
    if not isinstance(identity, str) or identity != identity.strip() or not _CARD_IDENTITY_RE.fullmatch(identity):
        raise PeerVerificationError("peer verification failed")
    if identity != peer.expected_card_identity:
        raise PeerVerificationError("peer verification failed")


def hermes_fleet_list(*, runner: Runner | None = None, hermes_bin: str | None = None) -> str:
    try:
        op.OperatorPolicy().require_level("read_only")
        agents, _ = _registry(runner=runner, hermes_bin=hermes_bin)
        return json.dumps({"success": True, "count": len(agents), "agents": agents}, indent=2)
    except PermissionError as exc:
        return _error("FLEET_POLICY_DENIED", str(exc), "Enable read-only Operator Mode before inspecting fleet peers.")
    except Exception as exc:
        return _error("FLEET_REGISTRY_ERROR", op.redact_output(str(exc)), "Verify the local Hermes A2A registry.")


def hermes_fleet_status(agent: str, timeout: int = 10, *, runner: Runner | None = None, hermes_bin: str | None = None) -> str:
    try:
        op.OperatorPolicy().require_level("read_only")
        peer, binary = _registered_agent(agent, runner=runner, hermes_bin=hermes_bin)
        capped = max(1, min(int(timeout), 30))
        if binary and _bridge_available(binary):
            code, stdout, stderr = _run([binary, "a2a", "doctor", peer, "--timeout", str(capped), "--json"], timeout=capped + 5, runner=runner)
            if code != 0:
                return _error("FLEET_STATUS_ERROR", op.redact_output(stderr or "A2A peer health check failed"), "Check the peer's A2A service and registry entry.")
            payload = _parse_json(stdout, operation="A2A peer health check")
            return json.dumps({"success": bool(payload.get("ok")), "agent": peer, "status": payload.get("status", "unknown"),
                               "capability_count": len(payload.get("capabilities", {})) if isinstance(payload.get("capabilities"), dict) else 0,
                               "warnings_count": len(payload.get("warnings", [])) if isinstance(payload.get("warnings"), list) else 0,
                               "errors_count": len(payload.get("errors", [])) if isinstance(payload.get("errors"), list) else 0}, indent=2)

        # Official A2A path: fetch the Agent Card and report the name and version.
        peers = _a2a_peers_with_resolved_tokens()
        entry = peers.get(peer)
        if not entry or not isinstance(entry.get("url"), str):
            return _error("FLEET_STATUS_ERROR", "peer has no configured URL", "Check the a2a_agents entry in config.yaml.")
        headers = _auth_header(entry)
        card = _fetch_card(entry["url"], headers, capped)
        if not isinstance(card, dict):
            return _error("FLEET_STATUS_ERROR", "peer returned an invalid Agent Card", "Check the peer's A2A service.")
        name = card.get("name")
        version = card.get("version", "unknown")
        skills = card.get("skills", []) if isinstance(card.get("skills"), list) else []
        return json.dumps({
            "success": isinstance(name, str) and bool(name),
            "agent": peer,
            "status": f"compatible (v{version})",
            "capability_count": len(skills),
            "warnings_count": 0,
            "errors_count": 0,
        }, indent=2)
    except LookupError:
        return _error("UNKNOWN_AGENT", "agent is not a registered fleet peer", "Call hermes_fleet_list and use one returned name.")
    except PermissionError as exc:
        return _error("FLEET_POLICY_DENIED", str(exc), "Enable read-only Operator Mode before checking fleet peers.")
    except Exception as exc:
        return _error("FLEET_STATUS_ERROR", op.redact_output(str(exc)), "Check the local A2A registry and peer service.")


def hermes_fleet_dispatch(agent: str, message: str, confirm: bool = False, dry_run: bool = True, timeout: int = 30,
                          *, runner: Runner | None = None, hermes_bin: str | None = None) -> str:
    """Backward-compatible free-form dispatch with original gates."""
    policy = op.OperatorPolicy()
    try:
        policy.require_level("workspace")
        effective = policy.effective_dry_run(dry_run)
        policy.require_mutation(dry_run)
        message = _clean_text(message, field="message", maximum=16_000)
        peer, binary = _registered_agent(agent, runner=runner, hermes_bin=hermes_bin)
        if effective:
            audit = op.audit_record(tool="hermes_fleet_dispatch", level=policy.level, apply_mode=policy.apply_mode, dry_run=True,
                                    success=True, changed=False, summary=f"fleet dispatch plan for {peer}", prompt=message, extra={"agent": peer})
            return json.dumps({"success": True, "dry_run": True, "plan": {"agent": peer, "message_len": len(message)}, "audit": audit}, indent=2)
        if not confirm:
            return _error("CONFIRMATION_REQUIRED", "remote dispatch requires confirm=true", "Review the task and call again with confirm=true.")
        capped = max(5, min(int(timeout), 120))
        if binary and _bridge_available(binary):
            code, stdout, stderr = _run([binary, "a2a", "send", "--json", peer, "--", message], timeout=capped, runner=runner)
            if code != 0:
                audit = op.audit_record(tool="hermes_fleet_dispatch", level=policy.level, apply_mode=policy.apply_mode, dry_run=False,
                                        success=False, changed=False, summary=f"fleet dispatch failed for {peer}", error=op.redact_output(stderr),
                                        prompt=message, extra={"agent": peer})
                return json.dumps({"success": False, "agent": peer, "code": "FLEET_DISPATCH_ERROR", "audit": audit}, indent=2)
            task = _unwrap_task(_parse_json(stdout, operation="A2A task submission"))
        else:
            peers = _a2a_peers_with_resolved_tokens()
            entry = peers.get(peer)
            if not entry or not isinstance(entry.get("url"), str):
                return _error("FLEET_DISPATCH_ERROR", "peer has no configured URL", "Check the a2a_agents entry in config.yaml.")
            result = _send_message(peer, entry, message, capped)
            task = _unwrap_task(result)
        task_id = task.get("id")
        status = task.get("status") if isinstance(task.get("status"), dict) else {}
        if not isinstance(task_id, str) or not _TASK_ID_RE.fullmatch(task_id):
            return _error("FLEET_DISPATCH_ERROR", "A2A task submission returned no valid task id", "Check the peer's A2A service logs.")
        op.audit_record(tool="hermes_fleet_dispatch", level=policy.level, apply_mode=policy.apply_mode, dry_run=False, success=True,
                        changed=True, summary=f"fleet task submitted to {peer}", prompt=message, job_id=task_id, extra={"agent": peer, "state": status.get("state")})
        return json.dumps({"success": True, "changed": True, "agent": peer, "task_id": task_id, "state": status.get("state")}, indent=2)
    except FleetDispatchTimeout as exc:
        op.audit_record(
            tool="hermes_fleet_dispatch", level=policy.level, apply_mode=policy.apply_mode,
            dry_run=False, success=False, changed=True,
            summary=f"fleet dispatch timed out after submission to {agent}",
            error="peer reply timed out; remote task state unknown",
            prompt=message, job_id=exc.task_id,
            extra={"agent": agent, "submission_may_have_succeeded": True},
        )
        return _dispatch_timeout_error(agent, exc.task_id)
    except LookupError:
        return _error("UNKNOWN_AGENT", "agent is not a registered fleet peer", "Call hermes_fleet_list and use one returned name.")
    except PermissionError as exc:
        return _error("FLEET_POLICY_DENIED", str(exc), "Enable workspace-level Operator Mode and use direct mode only for intentional dispatch.")
    except ValueError as exc:
        return _error("INVALID_MESSAGE", str(exc), "Provide a bounded task message.")
    except Exception as exc:
        return _error("FLEET_DISPATCH_ERROR", op.redact_output(str(exc)), "Check the local A2A registry and peer service.")


def hermes_fleet_dispatch_work_order(agent: str, task_id: str, target_profile: str, objective: str, workspace: str,
                                     inputs: list[str], constraints: list[str], acceptance_checks: list[str],
                                     deliverables: list[str], authorization: dict[str, Any] | str,
                                     confirm: bool = False, dry_run: bool = True, timeout: int = 30,
                                     *, runner: Runner | None = None, hermes_bin: str | None = None,
                                     authority_manifest: Path | None = None) -> str:
    policy = op.OperatorPolicy()
    try:
        policy.require_level("workspace")
        effective = policy.effective_dry_run(dry_run)
        policy.require_mutation(dry_run)
        canonical, envelope = _canonical_work_order(agent=agent, task_id=task_id, target_profile=target_profile, objective=objective,
                                                    workspace=workspace, inputs=inputs, constraints=constraints,
                                                    acceptance_checks=acceptance_checks, deliverables=deliverables, authorization=authorization)
        authorities = _load_authority(authority_manifest)
        peer_authority = authorities.get(agent)
        if peer_authority is None:
            raise PermissionError("peer is absent from the authority manifest")
        _authorize_order(peer_authority, envelope, canonical)
        peer, binary = _registered_agent(agent, runner=runner, hermes_bin=hermes_bin)
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        if effective:
            audit = op.audit_record(tool="hermes_fleet_dispatch_work_order", level=policy.level, apply_mode=policy.apply_mode,
                                    dry_run=True, success=True, changed=False, summary=f"fleet work-order plan for {peer}",
                                    prompt=canonical, job_id=task_id, extra={"agent": peer, "profile": target_profile})
            return json.dumps({"success": True, "dry_run": True, "plan": {"agent": peer, "task_id": task_id, "target_profile": target_profile,
                              "authorization": envelope["authorization"], "work_order_bytes": len(canonical.encode("utf-8")),
                              "live_peer_verification": "required_before_dispatch", "prompt_sha256": digest}, "audit": audit}, indent=2)
        if not confirm:
            return _error("CONFIRMATION_REQUIRED", "remote work-order dispatch requires confirm=true", "Review the work order and call again with confirm=true.")
        capped = max(5, min(int(timeout), 120))
        _verify_live_peer(peer_authority, binary, capped, runner)
        if binary and _bridge_available(binary):
            code, stdout, stderr = _run([binary, "a2a", "send", "--json", peer, "--", canonical], timeout=capped, runner=runner)
            if code != 0:
                op.audit_record(tool="hermes_fleet_dispatch_work_order", level=policy.level, apply_mode=policy.apply_mode, dry_run=False,
                                success=False, changed=False, summary=f"fleet work-order failed for {peer}", error=op.redact_output(stderr),
                                prompt=canonical, job_id=task_id, extra={"agent": peer, "profile": target_profile})
                return _error("FLEET_DISPATCH_ERROR", "A2A work-order submission failed", "Check the peer's A2A service.")
            remote = _unwrap_task(_parse_json(stdout, operation="A2A work-order submission"))
        else:
            peers = _a2a_peers_with_resolved_tokens()
            entry = peers.get(peer)
            if not entry or not isinstance(entry.get("url"), str):
                return _error("FLEET_DISPATCH_ERROR", "peer has no configured URL", "Check the a2a_agents entry in config.yaml.")
            result = _send_message(peer, entry, canonical, capped)
            remote = _unwrap_task(result)
        remote_id = remote.get("id")
        if not isinstance(remote_id, str) or not _TASK_ID_RE.fullmatch(remote_id):
            return _error("FLEET_DISPATCH_ERROR", "A2A submission returned no valid task id", "Check the peer's A2A service.")
        status = remote.get("status") if isinstance(remote.get("status"), dict) else {}
        op.audit_record(tool="hermes_fleet_dispatch_work_order", level=policy.level, apply_mode=policy.apply_mode, dry_run=False,
                        success=True, changed=True, summary=f"fleet work-order submitted to {peer}", prompt=canonical,
                        job_id=remote_id, extra={"agent": peer, "profile": target_profile})
        return json.dumps({"success": True, "changed": True, "agent": peer, "task_id": remote_id,
                           "requested_task_id": task_id, "state": status.get("state"), "live_peer_verified": True,
                           "prompt_sha256": digest}, indent=2)
    except FleetDispatchTimeout as exc:
        op.audit_record(
            tool="hermes_fleet_dispatch_work_order", level=policy.level, apply_mode=policy.apply_mode,
            dry_run=False, success=False, changed=True,
            summary=f"fleet work-order timed out after submission to {agent}",
            error="peer reply timed out; remote task state unknown",
            prompt=canonical, job_id=exc.task_id,
            extra={
                "agent": agent,
                "profile": target_profile,
                "requested_task_id": task_id,
                "submission_may_have_succeeded": True,
            },
        )
        return _dispatch_timeout_error(agent, exc.task_id)
    except LookupError:
        return _error("UNKNOWN_AGENT", "agent is not a registered fleet peer", "Call hermes_fleet_list and use one returned name.")
    except FileNotFoundError:
        return _error("AUTHORITY_MANIFEST_MISSING", "fleet authority manifest is not configured", "Install the authority manifest before dispatch.")
    except PermissionError as exc:
        code = "AUTHORIZATION_DENIED" if "Operator Mode" not in str(exc) and "operator" not in str(exc).lower() else "FLEET_POLICY_DENIED"
        return _error(code, str(exc), "Review fleet authority and explicit approval metadata.")
    except ValueError as exc:
        return _error("INVALID_WORK_ORDER", str(exc), "Correct the bounded work-order fields.")
    except PeerVerificationError:
        return _error("FLEET_PEER_VERIFICATION_FAILED", "registered peer verification failed",
                      "Verify the peer identity and host role before retrying.")
    except Exception as exc:
        return _error("FLEET_DISPATCH_ERROR", op.redact_output(str(exc)), "Check local authority, registry, and peer service.")


def _fetch_task(agent: str, task_id: str, timeout: int, runner: Runner | None, hermes_bin: str | None) -> tuple[str, dict[str, Any]]:
    if not isinstance(task_id, str) or not _TASK_ID_RE.fullmatch(task_id):
        raise ValueError("task_id has an invalid format")
    peer, binary = _registered_agent(agent, runner=runner, hermes_bin=hermes_bin)
    capped = max(1, min(int(timeout), 60))
    if binary and _bridge_available(binary):
        code, stdout, stderr = _run([binary, "a2a", "task", "--agent", peer, "--json", "--", task_id], timeout=capped, runner=runner)
        if code != 0:
            raise RuntimeError(op.redact_output(stderr or "A2A task lookup failed"))
        return peer, _unwrap_task(_parse_json(stdout, operation="A2A task lookup"))
    peers = _a2a_peers_with_resolved_tokens()
    entry = peers.get(peer)
    if not entry or not isinstance(entry.get("url"), str):
        raise RuntimeError("peer has no configured URL")
    result = _get_task(peer, entry, task_id, capped)
    return peer, _unwrap_task(result)


def hermes_fleet_task(agent: str, task_id: str, timeout: int = 15, *, runner: Runner | None = None, hermes_bin: str | None = None) -> str:
    if not isinstance(task_id, str) or not _TASK_ID_RE.fullmatch(task_id):
        return _error("INVALID_TASK_ID", "task_id has an invalid format", "Use the task id returned by fleet dispatch.")
    try:
        op.OperatorPolicy().require_level("read_only")
        peer, task = _fetch_task(agent, task_id, timeout, runner, hermes_bin)
        status = task.get("status") if isinstance(task.get("status"), dict) else {}
        return json.dumps({"success": True, "agent": peer, "task_id": task.get("id", task_id), "state": status.get("state"),
                           "timestamp": status.get("timestamp"), "artifact_count": len(task.get("artifacts", [])) if isinstance(task.get("artifacts"), list) else 0}, indent=2)
    except LookupError:
        return _error("UNKNOWN_AGENT", "agent is not a registered fleet peer", "Call hermes_fleet_list and use one returned name.")
    except PermissionError as exc:
        return _error("FLEET_POLICY_DENIED", str(exc), "Enable read-only Operator Mode before inspecting fleet tasks.")
    except Exception as exc:
        return _error("FLEET_TASK_ERROR", op.redact_output(str(exc)), "Check the peer and task id.")


def _text_parts(value: Any) -> list[str]:
    found: list[str] = []
    def walk(node: Any, depth: int = 0) -> None:
        if depth > 8 or len(found) >= _MAX_ITEMS:
            return
        if isinstance(node, dict):
            if isinstance(node.get("text"), str):
                found.append(_clean_text(node["text"], field="result text", maximum=_MAX_TEXT, required=False))
            for key in ("parts", "content", "data"):
                if key in node:
                    walk(node[key], depth + 1)
        elif isinstance(node, list):
            for item in node[:_MAX_ITEMS]:
                walk(item, depth + 1)
    walk(value)
    return [x for x in found if x]


def _completion_payload(task: dict[str, Any]) -> dict[str, Any]:
    candidates: list[dict[str, Any]] = []
    for source in (task.get("result"), task.get("artifacts"), task.get("status")):
        if isinstance(source, dict):
            candidates.append(source)
        elif isinstance(source, list):
            candidates.extend(item for item in source[:_MAX_ITEMS] if isinstance(item, dict))
    texts = _text_parts(candidates)
    for text in texts:
        try:
            candidates.insert(0, _parse_json(text, operation="completed task content"))
        except ValueError:
            pass
    allowed = {"status", "node", "profile", "summary", "changed_paths", "artifacts", "verification", "residual_risk", "recommended_next_action", "authorization"}
    raw: dict[str, Any] = {}
    for candidate in candidates:
        inner = candidate.get("completion_bundle", candidate)
        if isinstance(inner, dict) and any(key in inner for key in allowed):
            raw = inner
            break
    status_obj = task.get("status") if isinstance(task.get("status"), dict) else {}
    def bounded(value: Any, field: str) -> str:
        return op.redact_output(_clean_text(value if isinstance(value, str) else "", field=field, maximum=_MAX_TEXT, required=False))
    result = {
        "status": bounded(raw.get("status") or status_obj.get("state") or "unknown", "status"),
        "node": bounded(raw.get("node") or "", "node"),
        "profile": bounded(raw.get("profile") or "", "profile"),
        "summary": bounded(raw.get("summary") or (texts[0] if texts else ""), "summary"),
        "changed_paths": [],
        "artifacts": [],
        "verification": [],
        "residual_risk": bounded(raw.get("residual_risk") or "", "residual_risk"),
        "recommended_next_action": bounded(raw.get("recommended_next_action") or "", "recommended_next_action"),
        "authorization": {"class": "none", "approved": False},
    }
    for field in ("changed_paths", "artifacts", "verification"):
        value = raw.get(field, [])
        if isinstance(value, list):
            result[field] = [bounded(x, field) for x in value[:_MAX_ITEMS] if isinstance(x, str)]
    if isinstance(raw.get("authorization"), (dict, str)):
        try:
            result["authorization"] = _authorization(raw["authorization"])
        except (ValueError, PermissionError):
            pass
    return result


def hermes_fleet_result(agent: str, task_id: str, timeout: int = 15, *, runner: Runner | None = None, hermes_bin: str | None = None) -> str:
    if not isinstance(task_id, str) or not _TASK_ID_RE.fullmatch(task_id):
        return _error("INVALID_TASK_ID", "task_id has an invalid format", "Use the task id returned by fleet dispatch.")
    try:
        op.OperatorPolicy().require_level("read_only")
        _, task = _fetch_task(agent, task_id, timeout, runner, hermes_bin)
        return json.dumps({"success": True, "task_id": task_id, **_completion_payload(task)}, ensure_ascii=False, indent=2)
    except LookupError:
        return _error("UNKNOWN_AGENT", "agent is not a registered fleet peer", "Call hermes_fleet_list and use one returned name.")
    except PermissionError as exc:
        return _error("FLEET_POLICY_DENIED", str(exc), "Enable read-only Operator Mode.")
    except Exception as exc:
        return _error("FLEET_RESULT_ERROR", op.redact_output(str(exc)), "Check the peer, task id, and completion shape.")


def hermes_fleet_authority_drift(*, runner: Runner | None = None, hermes_bin: str | None = None,
                                 authority_manifest: Path | None = None) -> str:
    try:
        op.OperatorPolicy().require_level("read_only")
        authorities = _load_authority(authority_manifest)
        registered, binary = _registry(runner=runner, hermes_bin=hermes_bin)
        registered_names = {x["name"] for x in registered}
        findings: list[dict[str, str]] = []
        for name in sorted(registered_names | set(authorities)):
            if name not in registered_names:
                findings.append({"agent": name, "code": "MANIFEST_ONLY", "severity": "error"})
                continue
            if name not in authorities:
                findings.append({"agent": name, "code": "REGISTRY_ONLY", "severity": "error"})
                continue
            card: dict[str, Any] | None = None
            if binary and _bridge_available(binary):
                code, stdout, _ = _run([binary, "a2a", "doctor", name, "--timeout", "10", "--json"], timeout=15, runner=runner)
                if code != 0:
                    findings.append({"agent": name, "code": "CARD_UNAVAILABLE", "severity": "warning"})
                    continue
                try:
                    card = _parse_json(stdout, operation="A2A peer health check")
                except (TypeError, ValueError):
                    findings.append({"agent": name, "code": "CARD_UNAVAILABLE", "severity": "warning"})
                    continue
            else:
                peers = _a2a_peers_with_resolved_tokens()
                entry = peers.get(name)
                if not entry or not isinstance(entry.get("url"), str):
                    findings.append({"agent": name, "code": "CARD_UNAVAILABLE", "severity": "warning"})
                    continue
                headers = _auth_header(entry)
                try:
                    card = _fetch_card(entry["url"], headers, 10)
                except Exception:
                    findings.append({"agent": name, "code": "CARD_UNAVAILABLE", "severity": "warning"})
                    continue
            if not isinstance(card, dict):
                findings.append({"agent": name, "code": "CARD_UNAVAILABLE", "severity": "warning"})
                continue
            reported = card.get("name") or card.get("identity")
            role = card.get("host_role") or card.get("role")
            expected = authorities[name]
            if reported != expected.expected_card_identity:
                findings.append({"agent": name, "code": "IDENTITY_MISMATCH", "severity": "error"})
            # Host-role attestation is optional on Agent Cards (neither Hermes
            # v0.19 nor v0.20 emits host_role/role today). Only enforce the
            # manifest's expected role when the card actually attests one;
            # identity, allowed profiles, and the auth ceiling are enforced
            # regardless.
            if role is not None and role != expected.expected_host_role:
                findings.append({"agent": name, "code": "HOST_ROLE_MISMATCH", "severity": "error"})
        return json.dumps({"success": True, "valid": not findings, "registered_count": len(registered_names),
                           "manifest_count": len(authorities), "finding_count": len(findings), "findings": findings}, indent=2)
    except FileNotFoundError:
        return _error("AUTHORITY_MANIFEST_MISSING", "fleet authority manifest is not configured", "Install the authority manifest.")
    except PermissionError as exc:
        return _error("FLEET_POLICY_DENIED", str(exc), "Enable read-only Operator Mode and check manifest safety.")
    except Exception as exc:
        return _error("FLEET_AUTHORITY_ERROR", op.redact_output(str(exc)), "Check the local manifest, registry, and Agent Cards.")
