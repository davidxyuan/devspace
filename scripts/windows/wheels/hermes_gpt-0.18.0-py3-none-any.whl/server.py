from __future__ import annotations

import argparse
import asyncio
import ipaddress
import importlib.metadata
import inspect
import json
import os
import re
import sqlite3
import sys
import urllib.parse
from pathlib import Path
from typing import Any, Callable, List

from starlette.applications import Starlette
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import BaseRoute, Mount, Route

import oauth_auth
import operator_policy as op_policy
import operator_cron as op_cron
import operator_skills as op_skills
import operator_config as op_config
import operator_workspace as op_workspace
import operator_export as op_export
import operator_diagnostics as op_diagnostics
import operator_codex as op_codex
import operator_fleet as op_fleet
import operator_session as op_session
import operator_mission as op_mission
import operator_mission_runtime as op_mission_runtime
import operator_mission_plan as op_mission_plan
import operator_contract as op_contract
import operator_delegations as op_delegations
import operator_job_supervisor as op_jobs
import operator_runners as op_runners
import operator_review as op_review
import operator_events as op_events
import operator_live_events as op_live_events
import operator_capability_manifest as op_capability_manifest
import operator_mission_ledger as op_mission_ledger
import operator_mission_budget as op_mission_budget
import operator_placement as op_placement
import operator_failure_semantics as op_failure_semantics
import operator_controller as op_controller
import operator_oauth as op_oauth
import operator_swarm as op_swarm
import operator_recovery as op_recovery
import operator_autopilot as op_autopilot
import operator_finance as op_finance
import operator_owner_inbox as op_owner_inbox
import operator_review_assist as op_review_assist
import operator_mission_launch as op_mission_launch
import operator_attention_delivery as op_attention_delivery
import jev_bridge
import tool_profiles
import tool_registry
from versioning import VERSION


LOCAL_DEV_PROFILE = "local-dev"
REMOTE_PROFILE = "remote"
UNSAFE_REMOTE_ACK = "--i-understand-this-is-unsafe"
UNSAFE_REMOTE_ENV = "HERMES_GPT_UNSAFE_REMOTE_NOAUTH"
TRUSTED_PROXY_IPS_ENV = "HERMES_GPT_TRUSTED_PROXY_IPS"
ALLOWED_HOSTS_ENV = "HERMES_GPT_ALLOWED_HOSTS"
ENABLE_WRITE_ENV = "HERMES_GPT_ENABLE_WRITE"
ENABLE_MEMORY_WRITE_ENV = "HERMES_GPT_ENABLE_MEMORY_WRITE"
ENABLE_SESSION_SEARCH_ENV = "HERMES_GPT_ENABLE_SESSION_SEARCH"
ENABLE_SESSION_INTERNAL_CONTENT_ENV = "HERMES_GPT_ENABLE_SESSION_INTERNAL_CONTENT"
ENABLE_SESSION_CONTROL_ENV = op_session.ENABLE_SESSION_CONTROL_ENV
ENABLE_TERMINAL_ENV = "HERMES_GPT_ENABLE_TERMINAL"
ENABLE_VISION_ENV = "HERMES_GPT_ENABLE_VISION"
ENABLE_WEB_ENV = "HERMES_GPT_ENABLE_WEB"
CODEX_BATCH_VERSION = VERSION
NOAUTH_META = {"securitySchemes": [{"type": "noauth"}]}

MAX_LIST_LIMIT = 100
MAX_PAGE_SIZE = 100
MAX_EXPORT_MESSAGES = 500
MAX_OFFSET = 10_000
MAX_ID_LENGTH = 256
MAX_QUERY_LENGTH = 512
MAX_RESPONSE_BYTES = 262_144
MAX_MESSAGE_SCAN_ROWS = 1_000
DEFAULT_SESSION_OFFSET = 0
DEFAULT_SESSION_TIMEOUT = 900

_DEFAULT_MESSAGE_ROLES = {"user", "assistant"}
_INTERNAL_MESSAGE_ROLES = {"system", "tool", "function"}


class _SessionSearchUnavailable(RuntimeError):
    """Raised when the read-only session search/FTS API is unavailable."""
_SENSITIVE_KEY_RE = re.compile(
    r"(?i)(?:token|secret|password|passwd|api[_-]?key|authorization|cookie|private[_-]?key)"
)
_ABSOLUTE_PATH_RE = re.compile(
    r"(?i)(?:[A-Z]:[\\/]|\\\\|/(?:Users|home|mnt|var|tmp)/)[^\s\"']+"
)

HERMES_ROOT: Path | None = None
IMPORT_ERROR: str | None = None
file_tools: Any = None
terminal_tool: Any = None
memory_tool: Any = None
skill_manager_tool: Any = None
SessionDB: Any = None
get_hermes_home: Any = None
vision_tool: Any = None
web_tool: Any = None


def eprint(message: str) -> None:
    print(message, file=sys.stderr)


def env_enabled(name: str) -> bool:
    return os.environ.get(name) == "1"


def is_loopback_host(host: str) -> bool:
    return host in {"127.0.0.1", "localhost", "::1"}


def is_hermes_root(path: Path) -> bool:
    """Return True when ``path`` looks like a Hermes agent SOURCE root.

    Requires a regular ``tools`` package (``tools/__init__.py``) or a top-level
    ``hermes_state.py``. A bare ``tools/`` directory is not enough: stray
    namespace ``tools/`` dirs at the Hermes DATA root (e.g. an unrelated tool
    install under ``~/.hermes/tools``) must not make the data root masquerade
    as a source root — that poisoned ``sys.path`` and broke ``import tools``
    (audit t_9d200636 Class C).
    """
    if not path.exists():
        return False
    tools_dir = path / "tools"
    if tools_dir.is_dir() and (tools_dir / "__init__.py").is_file():
        return True
    return (path / "hermes_state.py").is_file()


def candidate_roots() -> list[Path]:
    explicit = os.environ.get("HERMES_AGENT_ROOT")
    if explicit is not None:
        root = Path(explicit).expanduser()
        if not explicit.strip() or not root.is_absolute() or not is_hermes_root(root):
            raise RuntimeError("HERMES_AGENT_ROOT must name an existing absolute Hermes Agent source root.")
        return [root.resolve()]
    candidates: list[Path] = []
    env_home = os.environ.get("HERMES_HOME")
    if env_home:
        env_path = Path(env_home).expanduser()
        candidates.extend([env_path, env_path / "hermes-agent"])

    home = Path.home()
    candidates.extend(
        [
            home / "AppData" / "Local" / "hermes" / "hermes-agent",
            home / ".hermes" / "hermes-agent",
        ]
    )

    for package in ("hermes-agent", "hermes_agent"):
        try:
            dist = importlib.metadata.distribution(package)
            base = Path(dist.locate_file("")).resolve()
        except Exception:
            continue
        for parent in [base, *base.parents]:
            if parent.name == "hermes-agent":
                candidates.append(parent)
                break

    unique: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        try:
            resolved = candidate.expanduser().resolve()
        except Exception:
            continue
        key = str(resolved).lower()
        if key not in seen:
            unique.append(resolved)
            seen.add(key)
    return unique


def find_hermes_root() -> Path:
    for candidate in candidate_roots():
        if is_hermes_root(candidate):
            return candidate
    raise RuntimeError("Could not find a Hermes Agent source root with a tools directory.")


def add_path_once(path: Path, *, prepend: bool = True) -> None:
    value = str(path)
    existing = {str(Path(p).resolve()).lower() for p in sys.path if p}
    if str(path.resolve()).lower() not in existing:
        if prepend:
            sys.path.insert(0, value)
        else:
            sys.path.append(value)


def add_hermes_to_syspath(root: Path) -> None:
    add_path_once(root)
    if os.name == "nt":
        site_packages = root / "venv" / "Lib" / "site-packages"
    else:
        candidates = sorted((root / "venv" / "lib").glob("python*/site-packages")) if (root / "venv" / "lib").exists() else []
        site_packages = candidates[0] if candidates else root / "venv" / "lib" / "site-packages"
    if site_packages.exists():
        # Keep Hermes' bundled dependencies available for Hermes internals, but do
        # not let them shadow the MCP SDK used to run this sidecar.
        add_path_once(site_packages, prepend=False)


def import_hermes() -> None:
    global HERMES_ROOT, IMPORT_ERROR, file_tools, terminal_tool, memory_tool
    global skill_manager_tool, SessionDB, get_hermes_home
    global vision_tool, web_tool
    try:
        HERMES_ROOT = find_hermes_root()
        add_hermes_to_syspath(HERMES_ROOT)
        from tools import file_tools as ft
        from tools import memory_tool as mt
        from tools import terminal_tool as tt

        if "HERMES_AGENT_ROOT" in os.environ:
            for module in (ft, mt, tt):
                if not getattr(module, "__file__", None) or not Path(module.__file__).resolve().is_relative_to(HERMES_ROOT):
                    raise RuntimeError("Required Agent module was loaded outside HERMES_AGENT_ROOT; restart with the selected source.")
        file_tools = ft
        terminal_tool = tt
        memory_tool = mt

        try:
            from tools import vision_tools as vt

            vision_tool = vt
        except Exception as exc:
            eprint(f"hermes-gpt: vision tool unavailable: {exc}")

        try:
            from tools import web_tools as wt

            web_tool = wt
        except Exception as exc:
            eprint(f"hermes-gpt: web tool unavailable: {exc}")

        try:
            from tools import skill_manager_tool as smt

            skill_manager_tool = smt
        except Exception as exc:
            eprint(f"hermes-gpt: skill manager unavailable: {exc}")

        try:
            from hermes_state import SessionDB as SDB
            from hermes_state import get_hermes_home as ghh

            SessionDB = SDB
            get_hermes_home = ghh
        except Exception as exc:
            eprint(f"hermes-gpt: session search unavailable: {exc}")
    except Exception as exc:
        IMPORT_ERROR = str(exc)
        eprint(f"hermes-gpt: Hermes imports failed: {exc}")


def call_with_supported_kwargs(func: Any, **kwargs: Any) -> Any:
    params = inspect.signature(func).parameters
    supported = {key: value for key, value in kwargs.items() if key in params}
    return func(**supported)


def expand_path(value: str | None) -> str | None:
    if value is None:
        return None
    return str(Path(value).expanduser())


def require_imports() -> None:
    if IMPORT_ERROR:
        raise RuntimeError(f"Hermes imports are unavailable: {IMPORT_ERROR}")
    missing = [
        name
        for name, module in {
            "file_tools": file_tools,
            "terminal_tool": terminal_tool,
            "memory_tool": memory_tool,
        }.items()
        if module is None
    ]
    if missing:
        raise RuntimeError(f"Hermes imports are unavailable: missing {', '.join(missing)}")


def _validate_limit(value: int, name: str, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be an integer.")
    if value < 0:
        raise ValueError(f"{name} must not be negative.")
    if value > maximum:
        raise ValueError(f"{name} exceeds the maximum of {maximum}.")
    return value


def _validate_offset(value: int) -> int:
    return _validate_limit(value, "offset", MAX_OFFSET)


def _validate_bool(value: bool, name: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{name} must be a boolean.")
    return value


def _validate_session_id(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("session_id must be a string.")
    normalized = value.strip()
    if not normalized:
        raise ValueError("session_id must not be empty.")
    if len(normalized) > MAX_ID_LENGTH:
        raise ValueError(f"session_id exceeds the maximum of {MAX_ID_LENGTH} characters.")
    return normalized


def _validate_query(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("query must be a string.")
    normalized = value.strip()
    if not normalized:
        raise ValueError("query must not be empty.")
    if len(normalized) > MAX_QUERY_LENGTH:
        raise ValueError(f"query exceeds the maximum of {MAX_QUERY_LENGTH} characters.")
    return normalized


def _utf8_response_bytes(value: str) -> int:
    if not isinstance(value, str):
        raise TypeError("response value must be a string.")
    return len(value.encode("utf-8"))


def _redact_text(value: Any) -> str:
    text = op_policy.redact_output(str(value))
    text = _ABSOLUTE_PATH_RE.sub("[REDACTED_PATH]", text)
    return text


def _redact_error(exc: BaseException) -> str:
    return _redact_text(f"{type(exc).__name__}: {exc}")


def _redact_value(value: Any, *, key: str | None = None) -> Any:
    if key and key != "session_id" and _SENSITIVE_KEY_RE.search(key):
        return "[REDACTED]"
    if isinstance(value, str):
        return _redact_text(value)
    if isinstance(value, dict):
        return {str(item_key): _redact_value(item, key=str(item_key)) for item_key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_redact_value(item) for item in value]
    return value


def _safe_session_metadata(row: dict[str, Any]) -> dict[str, Any]:
    safe_keys = (
        "id",
        "source",
        "started_at",
        "ended_at",
        "last_active",
        "message_count",
        "tool_call_count",
        "archived",
    )
    result = {key: row[key] for key in safe_keys if key in row}
    result["has_title"] = bool(row.get("title"))
    return _redact_value(result)


def _safe_message(row: dict[str, Any], allowed_roles: set[str]) -> dict[str, Any] | None:
    requested_internal = set(allowed_roles) & _INTERNAL_MESSAGE_ROLES
    if requested_internal and not env_enabled(ENABLE_SESSION_INTERNAL_CONTENT_ENV):
        raise RuntimeError(
            "Internal session content is disabled. Set "
            f"{ENABLE_SESSION_INTERNAL_CONTENT_ENV}=1 to request system or tool messages."
        )
    role = row.get("role")
    safe_roles = _DEFAULT_MESSAGE_ROLES | _INTERNAL_MESSAGE_ROLES
    if role not in set(allowed_roles) & safe_roles:
        return None
    safe_keys = ("id", "session_id", "role", "timestamp", "content")
    result = {key: row[key] for key in safe_keys if key in row}
    return _redact_value(result)


def _safe_search_message(
    row: dict[str, Any], allowed_roles: set[str]
) -> dict[str, Any] | None:
    """Project a SessionDB search row through the normal message safeguards."""
    projected = dict(row)
    snippet = row.get("snippet")
    if isinstance(snippet, str):
        # Current Hermes search results expose matched text as ``snippet``;
        # older runtimes and test doubles may still expose ``content``.
        projected["content"] = snippet
    return _safe_message(projected, allowed_roles)


def _allowed_message_roles(
    *,
    include_system_messages: bool = False,
    include_tool_messages: bool = False,
) -> set[str]:
    if (include_system_messages or include_tool_messages) and not env_enabled(
        ENABLE_SESSION_INTERNAL_CONTENT_ENV
    ):
        raise RuntimeError(
            "Internal session content is disabled. Set "
            f"{ENABLE_SESSION_INTERNAL_CONTENT_ENV}=1 to request system or tool messages."
        )
    allowed = set(_DEFAULT_MESSAGE_ROLES)
    if include_system_messages:
        allowed.add("system")
    if include_tool_messages:
        allowed.update({"tool", "function"})
    return allowed


def _validate_session_profile(profile: str = "default") -> str:
    """Validate a session-history profile against Hermes/operator policy."""
    canon = op_policy.validate_profile_name(profile)
    hermes_root = _default_hermes_root()
    if canon != "default":
        policy = op_policy.OperatorPolicy()
        policy.require_profile(canon, hermes_root)
    return canon


def _session_profile_db_path(profile: str = "default") -> Path:
    """Return the state.db path for an authorized Hermes profile."""
    canon = _validate_session_profile(profile)
    hermes_root = _default_hermes_root()
    profile_home = op_policy.resolve_profile_home(canon, hermes_root)
    return profile_home / "state.db"


class ReadOnlySessionAdapter:
    """Bounded adapter around Hermes' verified read-only SessionDB API."""

    def __init__(
        self,
        db_factory: Any = None,
        connection_type: type = sqlite3.Connection,
        profile: str = "default",
    ):
        self._db_factory = db_factory if db_factory is not None else SessionDB
        self._connection_type = connection_type
        self._profile = _validate_session_profile(profile)
        self._db = None
        self._disposed = False

    def open(self) -> "ReadOnlySessionAdapter":
        if self._disposed:
            raise RuntimeError("Read-only session adapter has already been disposed.")
        if self._db is not None:
            return self
        if self._db_factory is None:
            raise RuntimeError("Hermes session database is unavailable: SessionDB import failed.")
        try:
            self._db = self._db_factory(
                db_path=_session_profile_db_path(self._profile),
                read_only=True,
            )
        except Exception as exc:
            raise RuntimeError(f"Hermes session database is unavailable: {_redact_error(exc)}") from exc
        return self

    def __enter__(self) -> "ReadOnlySessionAdapter":
        return self.open()

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None:
        self.dispose_safely()

    def _require_db(self) -> Any:
        if self._db is None or self._disposed:
            raise RuntimeError("Read-only session adapter is not open.")
        return self._db

    def list_sessions(self, *, limit: int, offset: int, include_archived: bool = False) -> list[dict[str, Any]]:
        db = self._require_db()
        safe_limit = _validate_limit(limit, "limit", MAX_LIST_LIMIT)
        safe_offset = _validate_offset(offset)
        safe_include_archived = _validate_bool(include_archived, "include_archived")
        return db.list_sessions_rich(
            limit=safe_limit,
            offset=safe_offset,
            include_archived=safe_include_archived,
            compact_rows=True,
        )

    def resolve_session_id(self, session_id_or_prefix: str) -> str | None:
        return self._require_db().resolve_session_id(_validate_session_id(session_id_or_prefix))

    def get_canonical_bot_chat(self) -> dict[str, Any] | None:
        """Resolve this profile's canonical Bot Chat registry row and live tip."""
        db = self._require_db()
        if not hasattr(db, "get_session_by_title") or not hasattr(db, "get_compression_tip"):
            raise RuntimeError("Installed SessionDB runtime lacks canonical Bot Chat lookup support.")
        title = getattr(db, "CANONICAL_BOT_CHAT_TITLE", "Bot Chat")
        registry = db.get_session_by_title(title)
        if not isinstance(registry, dict):
            return None
        if str(registry.get("source") or "").strip().lower() in {"kanban", "tool"}:
            return None
        if bool(registry.get("archived")):
            return None
        registry_id = registry.get("id")
        if not isinstance(registry_id, str) or not registry_id:
            return None
        tip_id = db.get_compression_tip(registry_id) or registry_id
        current = registry
        if tip_id != registry_id:
            if not hasattr(db, "get_session"):
                raise RuntimeError("Installed SessionDB runtime cannot hydrate the Bot Chat compression tip.")
            resolved = db.get_session(tip_id)
            if isinstance(resolved, dict):
                current = resolved
        return {
            "registry": registry,
            "current": current,
            "registry_session_id": registry_id,
            "current_session_id": tip_id,
            "canonical_title": title,
        }

    def get_messages_page(
        self,
        session_id: str,
        *,
        limit: int,
        offset: int,
        include_inactive: bool = False,
        include_system_messages: bool = False,
        include_tool_messages: bool = False,
    ) -> dict[str, Any]:
        db = self._require_db()
        safe_id = _validate_session_id(session_id)
        safe_limit = _validate_limit(limit, "limit", MAX_EXPORT_MESSAGES)
        safe_offset = _validate_offset(offset)
        safe_include_inactive = _validate_bool(include_inactive, "include_inactive")
        safe_include_system = _validate_bool(include_system_messages, "include_system_messages")
        safe_include_tool = _validate_bool(include_tool_messages, "include_tool_messages")
        allowed_roles = _allowed_message_roles(
            include_system_messages=safe_include_system,
            include_tool_messages=safe_include_tool,
        )
        projected: list[dict[str, Any]] = []
        cursor = safe_offset
        rows_examined = 0
        source_exhausted = safe_limit == 0
        while len(projected) < safe_limit and rows_examined < MAX_MESSAGE_SCAN_ROWS:
            fetch_limit = min(
                MAX_PAGE_SIZE,
                MAX_MESSAGE_SCAN_ROWS - rows_examined,
                max(1, safe_limit - len(projected)),
            )
            raw_rows = db.get_messages(
                safe_id,
                limit=fetch_limit,
                offset=cursor,
                include_inactive=safe_include_inactive,
            )
            examined_now = len(raw_rows)
            if examined_now == 0:
                source_exhausted = True
                break
            rows_examined += examined_now
            cursor += examined_now
            for row in raw_rows:
                message = _safe_message(row, allowed_roles)
                if message is not None:
                    projected.append(message)
                    if len(projected) >= safe_limit:
                        break
            if examined_now < fetch_limit:
                source_exhausted = True
                break

        return {
            "messages": projected[:safe_limit],
            "next_offset": cursor,
            "rows_examined": rows_examined,
            "has_more": not source_exhausted,
            "scan_limited": rows_examined >= MAX_MESSAGE_SCAN_ROWS and not source_exhausted,
        }

    def get_messages(
        self,
        session_id: str,
        *,
        limit: int,
        offset: int,
        include_inactive: bool = False,
        include_system_messages: bool = False,
        include_tool_messages: bool = False,
    ) -> list[dict[str, Any]]:
        return self.get_messages_page(
            session_id,
            limit=limit,
            offset=offset,
            include_inactive=include_inactive,
            include_system_messages=include_system_messages,
            include_tool_messages=include_tool_messages,
        )["messages"]

    def search_messages(self, *, query: str, limit: int, offset: int) -> list[dict[str, Any]]:
        db = self._require_db()
        if not hasattr(db, "search_messages"):
            raise _SessionSearchUnavailable(
                "read-only FTS search_messages API is unavailable"
            )
        if hasattr(db, "_fts_enabled") and not bool(getattr(db, "_fts_enabled")):
            raise _SessionSearchUnavailable(
                "read-only FTS is disabled by the installed SessionDB runtime"
            )
        safe_query = _validate_query(query)
        safe_limit = _validate_limit(limit, "limit", MAX_LIST_LIMIT)
        safe_offset = _validate_offset(offset)
        raw_rows = db.search_messages(query=safe_query, limit=safe_limit, offset=safe_offset)
        allowed_roles = _allowed_message_roles()
        projected = []
        for row in raw_rows:
            message = _safe_search_message(row, allowed_roles)
            if message is not None:
                projected.append(message)
        return projected

    def export_session(self, session_id: str) -> dict[str, Any] | None:
        """INTERNAL RAW export; callers must project before client exposure."""
        return self._require_db().export_session(_validate_session_id(session_id))

    def export_session_lineage(self, session_id: str) -> dict[str, Any] | None:
        """INTERNAL RAW lineage export; never return directly from an MCP tool."""
        return self._require_db().export_session_lineage(_validate_session_id(session_id))

    def dispose_safely(self) -> None:
        if self._disposed:
            return
        self._disposed = True
        db = self._db
        if db is None:
            return
        connection = getattr(db, "_conn", None)
        if not isinstance(connection, self._connection_type):
            return
        try:
            connection.close()
        except Exception as exc:
            eprint(f"hermes-gpt: read-only session disposal failed: {_redact_error(exc)}")


def skill_roots() -> list[Path]:
    roots: list[Path] = []
    hermes_home = None
    if callable(get_hermes_home):
        try:
            hermes_home = Path(get_hermes_home())
        except Exception:
            hermes_home = None
    if hermes_home is None:
        env_home = os.environ.get("HERMES_HOME")
        hermes_home = Path(env_home).expanduser() if env_home else Path.home() / ".hermes"

    roots.append(hermes_home / "skills")
    profiles = hermes_home / "profiles"
    if profiles.exists():
        roots.extend(path / "skills" for path in profiles.iterdir() if path.is_dir())
    if HERMES_ROOT:
        roots.append(HERMES_ROOT / "skills")

    unique: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        try:
            resolved = root.expanduser().resolve()
        except Exception:
            continue
        key = str(resolved).lower()
        if resolved.exists() and key not in seen:
            unique.append(resolved)
            seen.add(key)
    return unique


def parse_skill_doc(path: Path) -> dict[str, str]:
    text = path.read_text(encoding="utf-8", errors="replace")
    name = path.parent.name
    description = ""
    body = text
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            body = parts[2]
            for line in parts[1].splitlines():
                if ":" not in line:
                    continue
                key, value = line.split(":", 1)
                key = key.strip().lower()
                value = value.strip().strip("'\"")
                if key == "name" and value:
                    name = value
                elif key == "description" and value:
                    description = value
    if not description:
        for line in body.splitlines():
            clean = line.strip().lstrip("#").strip()
            if clean:
                description = clean[:180]
                break
    return {"name": name, "description": description, "path": str(path)}


def discover_skills() -> list[dict[str, str]]:
    skills: list[dict[str, str]] = []
    for root in skill_roots():
        for skill_md in root.rglob("SKILL.md"):
            try:
                skills.append(parse_skill_doc(skill_md))
            except Exception as exc:
                eprint(f"hermes-gpt: could not read skill {skill_md}: {exc}")
    return sorted(skills, key=lambda item: (item["name"].lower(), item["path"].lower()))


def clean_error(tool_name: str, exc: Exception) -> RuntimeError:
    eprint(f"hermes-gpt: {tool_name} failed: {exc}")
    return RuntimeError(f"{tool_name} failed: {exc}")


from mcp_compat import HermesMCP as FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import CallToolResult, ToolAnnotations

import_hermes()


def tool_meta(extra: dict[str, Any] | None = None) -> dict[str, Any]:
    oauth_config = oauth_auth.config_from_env()
    if oauth_config is not None:
        meta: dict[str, Any] = {
            "securitySchemes": [{"type": "oauth2", "scopes": [oauth_config.scope]}]
        }
    elif oauth_auth.static_bearer_from_env() is not None:
        meta = {"securitySchemes": [{"type": "http", "scheme": "bearer"}]}
    else:
        meta = dict(NOAUTH_META)
    if extra:
        meta.update(extra)
    return meta


def hermes_read_file(path: str, offset: int = 1, limit: int = 500) -> str:
    try:
        require_imports()
        return file_tools.read_file_tool(path=expand_path(path), offset=offset, limit=limit)
    except Exception as exc:
        raise clean_error("hermes_read_file", exc) from exc


def hermes_write_file(path: str, content: str) -> str:
    try:
        require_imports()
        return file_tools.write_file_tool(path=expand_path(path), content=content)
    except Exception as exc:
        raise clean_error("hermes_write_file", exc) from exc


def hermes_patch(
    path: str,
    old_string: str,
    new_string: str,
    mode: str = "replace",
    replace_all: bool = False,
) -> str:
    try:
        require_imports()
        return call_with_supported_kwargs(
            file_tools.patch_tool,
            mode=mode,
            path=expand_path(path),
            old_string=old_string,
            new_string=new_string,
            replace_all=replace_all,
        )
    except Exception as exc:
        raise clean_error("hermes_patch", exc) from exc


def hermes_search_files(
    pattern: str,
    target: str = "content",
    path: str = ".",
    file_glob: str | None = None,
    limit: int = 50,
) -> str:
    try:
        require_imports()
        return call_with_supported_kwargs(
            file_tools.search_tool,
            pattern=pattern,
            target=target,
            path=expand_path(path),
            file_glob=file_glob,
            limit=limit,
        )
    except Exception as exc:
        raise clean_error("hermes_search_files", exc) from exc


def hermes_run_command(command: str, timeout: int = 30, workdir: str | None = None) -> str:
    try:
        require_imports()
        if not env_enabled(ENABLE_TERMINAL_ENV):
            raise RuntimeError(f"Terminal execution is disabled. Set {ENABLE_TERMINAL_ENV}=1 to enable it.")
        capped_timeout = max(1, min(int(timeout), 120))
        return call_with_supported_kwargs(
            terminal_tool.terminal_tool,
            command=command,
            timeout=capped_timeout,
            workdir=expand_path(workdir),
        )
    except Exception as exc:
        raise clean_error("hermes_run_command", exc) from exc


def hermes_memory(
    action: str,
    target: str = "memory",
    content: str | None = None,
    old_text: str | None = None,
) -> str:
    try:
        require_imports()
        if action not in {"add", "replace", "remove", "search"}:
            raise RuntimeError("Unsupported memory action. Use add, replace, remove, or search.")
        if action in {"add", "replace", "remove"} and not env_enabled(ENABLE_MEMORY_WRITE_ENV):
            raise RuntimeError(f"Memory write actions are disabled. Set {ENABLE_MEMORY_WRITE_ENV}=1 to enable them.")
        return memory_tool.memory_tool(action=action, target=target, content=content, old_text=old_text)
    except Exception as exc:
        raise clean_error("hermes_memory", exc) from exc


def hermes_skill_list() -> str:
    try:
        require_imports()
        skills = discover_skills()
        if not skills:
            return "No Hermes skills found."
        # Deduplicate by name, keeping the first (user-level skills take priority)
        seen_names: set[str] = set()
        unique_skills: list[dict[str, str]] = []
        for skill in skills:
            if skill["name"].lower() not in seen_names:
                seen_names.add(skill["name"].lower())
                unique_skills.append(skill)
        lines = []
        for skill in unique_skills:
            desc = f" - {skill['description']}" if skill["description"] else ""
            lines.append(f"- {skill['name']}{desc}\n  {skill['path']}")
        return "\n".join(lines)
    except Exception as exc:
        raise clean_error("hermes_skill_list", exc) from exc


def hermes_skill_view(name: str) -> str:
    try:
        require_imports()
        query = name.strip().lower()
        matches = [
            skill for skill in discover_skills()
            if skill["name"].lower() == query or Path(skill["path"]).parent.name.lower() == query
        ]
        if not matches:
            return f"No skill matched {name!r}."
        if len(matches) > 1:
            return "Multiple skills matched:\n" + "\n".join(f"- {m['name']}: {m['path']}" for m in matches)
        skill_path = Path(matches[0]["path"])
        # Size guard: if file > 80KB, return bounded chunk with guidance
        MAX_VIEW_BYTES = 80_000
        file_size = skill_path.stat().st_size
        if file_size > MAX_VIEW_BYTES:
            text = skill_path.read_text(encoding="utf-8", errors="replace")
            return text[:MAX_VIEW_BYTES] + f"\n\n--- TRUNCATED (showing {MAX_VIEW_BYTES} of {file_size} bytes). Use hermes_read_file for specific sections. ---"
        return skill_path.read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        raise clean_error("hermes_skill_view", exc) from exc


def _session_error(code: str, message: str) -> str:
    payload = {
        "success": False,
        "error": {"code": code, "message": _redact_text(message)},
    }
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _session_page_response(
    item_key: str,
    items: list[dict[str, Any]],
    *,
    offset: int,
    requested_limit: int,
    extra: dict[str, Any] | None = None,
    has_more_override: bool | None = None,
    next_offset_override: int | None = None,
) -> str:
    has_more = requested_limit > 0 and len(items) >= requested_limit
    next_offset = offset + len(items) if has_more else None
    if has_more_override is not None:
        has_more = has_more_override
    if next_offset_override is not None:
        next_offset = next_offset_override
    payload: dict[str, Any] = {
        "success": True,
        item_key: list(items),
        "returned_count": len(items),
        "offset": offset,
        "next_offset": next_offset,
        "has_more": has_more,
        "truncated": False,
    }
    if extra:
        payload.update(extra)

    removed_count = 0
    while (
        _utf8_response_bytes(
            json.dumps(_redact_value(payload), ensure_ascii=False, separators=(",", ":"))
        ) > MAX_RESPONSE_BYTES
        and payload[item_key]
    ):
        payload[item_key].pop()
        removed_count += 1
        payload["returned_count"] = len(payload[item_key])
        payload["truncated"] = True
        payload["has_more"] = True
        payload["next_offset"] = max(
            payload["next_offset"] or 0,
            offset + len(payload[item_key]) + removed_count,
        )

    serialized = json.dumps(_redact_value(payload), ensure_ascii=False, separators=(",", ":"))
    if _utf8_response_bytes(serialized) > MAX_RESPONSE_BYTES:
        return _session_error(
            "SESSION_RESPONSE_TOO_LARGE",
            "The requested session response exceeds the configured response-size limit.",
        )
    return serialized


def hermes_bot_chat_get(profile: str = "default") -> str:
    """Return a profile's canonical Bot Chat; it may be hidden from the general session list."""
    safe_profile = _validate_session_profile(profile)
    adapter = ReadOnlySessionAdapter(profile=safe_profile)
    try:
        require_imports()
        if not env_enabled(ENABLE_SESSION_SEARCH_ENV):
            return _session_error(
                "SESSION_HISTORY_DISABLED",
                f"Session history is disabled. Set {ENABLE_SESSION_SEARCH_ENV}=1 to enable it.",
            )
        adapter.open()
        resolved = adapter.get_canonical_bot_chat()
        if resolved is None:
            return _session_error(
                "BOT_CHAT_NOT_FOUND",
                "No canonical Bot Chat was found for the requested profile.",
            )
        registry = _safe_session_metadata(resolved["registry"])
        current = _safe_session_metadata(resolved["current"])
        payload = {
            "success": True,
            "profile": safe_profile,
            "kind": "bot_chat",
            "canonical_title": resolved["canonical_title"],
            "registry_session_id": resolved["registry_session_id"],
            "current_session_id": resolved["current_session_id"],
            "compression_continuation": resolved["registry_session_id"] != resolved["current_session_id"],
            "session_list_visibility": "canonical_bot_chat_may_be_hidden",
            "preferred_send_tool": "hermes_bot_chat_send",
            "registry": registry,
            "current": current,
        }
        return json.dumps(_redact_value(payload), ensure_ascii=False, separators=(",", ":"))
    except Exception as exc:
        return _session_error("BOT_CHAT_LOOKUP_FAILED", _redact_error(exc))
    finally:
        adapter.dispose_safely()


def hermes_bot_chat_send(
    prompt: str,
    profile: str = "default",
    timeout: int = 900,
) -> dict[str, Any]:
    """Send one bounded turn directly to a profile's canonical Bot Chat."""
    safe_profile = _validate_session_profile(profile)
    adapter = ReadOnlySessionAdapter(profile=safe_profile)
    try:
        require_imports()
        if not env_enabled(ENABLE_SESSION_SEARCH_ENV):
            return op_policy.make_error_envelope(
                layer="session_control",
                code="SESSION_HISTORY_DISABLED",
                safe_message=f"Session history is disabled. Set {ENABLE_SESSION_SEARCH_ENV}=1 to enable Bot Chat targeting.",
                suggested_action="Enable session history on the trusted local MCP server.",
            )
        adapter.open()
        resolved = adapter.get_canonical_bot_chat()
        if resolved is None:
            return op_policy.make_error_envelope(
                layer="session_control",
                code="BOT_CHAT_NOT_FOUND",
                safe_message="No canonical Bot Chat was found for the requested profile.",
                suggested_action="Open Bot Chat for that profile first, then retry.",
            )
        return hermes_session_continue(
            resolved["current_session_id"],
            prompt,
            timeout,
            safe_profile,
        )
    except Exception as exc:
        return op_policy.make_error_envelope(
            layer="session_control",
            code="BOT_CHAT_SEND_FAILED",
            safe_message=_redact_error(exc),
            suggested_action="Check the Bot Chat registry, profile authorization, and Hermes CLI installation.",
        )
    finally:
        adapter.dispose_safely()


def hermes_session_list(
    limit: int = 20,
    offset: int = DEFAULT_SESSION_OFFSET,
    include_archived: bool = False,
    profile: str = "default",
) -> str:
    safe_profile = _validate_session_profile(profile)
    adapter = ReadOnlySessionAdapter(profile=safe_profile)
    try:
        require_imports()
        if not env_enabled(ENABLE_SESSION_SEARCH_ENV):
            return _session_error(
                "SESSION_HISTORY_DISABLED",
                f"Session history is disabled. Set {ENABLE_SESSION_SEARCH_ENV}=1 to enable it.",
            )
        safe_limit = _validate_limit(limit, "limit", MAX_LIST_LIMIT)
        safe_offset = _validate_offset(offset)
        safe_include_archived = _validate_bool(include_archived, "include_archived")
        adapter.open()
        rows = adapter.list_sessions(
            limit=safe_limit,
            offset=safe_offset,
            include_archived=safe_include_archived,
        )
        sessions = [
            _safe_session_metadata(row)
            for row in rows
            if isinstance(row, dict)
        ]
        return _session_page_response(
            "sessions",
            sessions,
            offset=safe_offset,
            requested_limit=safe_limit,
            extra={"profile": safe_profile},
        )
    except Exception as exc:
        return _session_error("SESSION_LIST_FAILED", _redact_error(exc))
    finally:
        adapter.dispose_safely()


def hermes_session_read(
    session_id: str,
    limit: int = 50,
    offset: int = 0,
    include_inactive: bool = False,
    include_system_messages: bool = False,
    include_tool_messages: bool = False,
    profile: str = "default",
) -> str:
    safe_profile = _validate_session_profile(profile)
    adapter = ReadOnlySessionAdapter(profile=safe_profile)
    try:
        require_imports()
        if not env_enabled(ENABLE_SESSION_SEARCH_ENV):
            return _session_error(
                "SESSION_HISTORY_DISABLED",
                f"Session history is disabled. Set {ENABLE_SESSION_SEARCH_ENV}=1 to enable it.",
            )
        safe_id = _validate_session_id(session_id)
        safe_limit = _validate_limit(limit, "limit", MAX_PAGE_SIZE)
        safe_offset = _validate_offset(offset)
        safe_include_inactive = _validate_bool(include_inactive, "include_inactive")
        safe_include_system = _validate_bool(include_system_messages, "include_system_messages")
        safe_include_tool = _validate_bool(include_tool_messages, "include_tool_messages")
        allowed_roles = _allowed_message_roles(
            include_system_messages=safe_include_system,
            include_tool_messages=safe_include_tool,
        )
        adapter.open()
        resolved_id = adapter.resolve_session_id(safe_id)
        if not resolved_id:
            return _session_error(
                "SESSION_ID_NOT_FOUND_OR_AMBIGUOUS",
                "The requested session ID was not found or is ambiguous.",
            )
        page = adapter.get_messages_page(
            resolved_id,
            limit=safe_limit,
            offset=safe_offset,
            include_inactive=safe_include_inactive,
            include_system_messages=safe_include_system,
            include_tool_messages=safe_include_tool,
        )
        return _session_page_response(
            "messages",
            page["messages"],
            offset=safe_offset,
            requested_limit=safe_limit,
            extra={"session_id": resolved_id, "profile": safe_profile},
            has_more_override=page["has_more"],
            next_offset_override=page["next_offset"],
        )
    except Exception as exc:
        return _session_error("SESSION_READ_FAILED", _redact_error(exc))
    finally:
        adapter.dispose_safely()


def _session_markdown_response(
    session_id: str,
    messages: list[dict[str, Any]],
    *,
    offset: int,
    next_offset: int,
    has_more: bool,
    truncated: bool,
) -> str:
    current = list(messages)

    def render() -> str:
        lines = [
            "# Hermes session export",
            "",
            f"Session ID: `{_redact_text(session_id)}`",
            f"Returned count: {len(current)}",
            f"Offset: {offset}",
            f"Next offset: {next_offset}",
            f"Has more: {str(has_more).lower()}",
            f"Truncated: {str(truncated or len(current) < len(messages)).lower()}",
            "",
        ]
        for message in current:
            lines.extend(
                [
                    f"## {message.get('role', '')} — {message.get('timestamp', '')}",
                    f"Message ID: `{message.get('id', '')}`",
                    "",
                    str(message.get("content", "")),
                    "",
                ]
            )
        return "\n".join(lines)

    rendered = render()
    while _utf8_response_bytes(rendered) > MAX_RESPONSE_BYTES and current:
        current.pop()
        rendered = render()
    if _utf8_response_bytes(rendered) > MAX_RESPONSE_BYTES:
        return "# Hermes session export\n\nThe requested session export exceeds the configured response-size limit."
    return rendered


def hermes_session_export(
    session_id: str,
    format: str = "json",
    limit: int = MAX_EXPORT_MESSAGES,
    offset: int = 0,
    include_inactive: bool = False,
    include_system_messages: bool = False,
    include_tool_messages: bool = False,
    include_lineage: bool = False,
    profile: str = "default",
) -> str:
    safe_profile = _validate_session_profile(profile)
    adapter = ReadOnlySessionAdapter(profile=safe_profile)
    try:
        require_imports()
        if not env_enabled(ENABLE_SESSION_SEARCH_ENV):
            return _session_error(
                "SESSION_HISTORY_DISABLED",
                f"Session history is disabled. Set {ENABLE_SESSION_SEARCH_ENV}=1 to enable it.",
            )
        if not isinstance(format, str) or format.lower() not in {"json", "markdown"}:
            raise ValueError("format must be json or markdown.")
        safe_format = format.lower()
        safe_id = _validate_session_id(session_id)
        safe_limit = _validate_limit(limit, "limit", MAX_EXPORT_MESSAGES)
        safe_offset = _validate_offset(offset)
        safe_include_inactive = _validate_bool(include_inactive, "include_inactive")
        safe_include_system = _validate_bool(include_system_messages, "include_system_messages")
        safe_include_tool = _validate_bool(include_tool_messages, "include_tool_messages")
        safe_include_lineage = _validate_bool(include_lineage, "include_lineage")
        if safe_include_lineage:
            return _session_error(
                "SESSION_LINEAGE_EXPORT_UNAVAILABLE",
                "Lineage export is disabled until a bounded safe lineage projection is proven.",
            )
        _allowed_message_roles(
            include_system_messages=safe_include_system,
            include_tool_messages=safe_include_tool,
        )
        adapter.open()
        resolved_id = adapter.resolve_session_id(safe_id)
        if not resolved_id:
            return _session_error(
                "SESSION_ID_NOT_FOUND_OR_AMBIGUOUS",
                "The requested session ID was not found or is ambiguous.",
            )
        page = adapter.get_messages_page(
            resolved_id,
            limit=safe_limit,
            offset=safe_offset,
            include_inactive=safe_include_inactive,
            include_system_messages=safe_include_system,
            include_tool_messages=safe_include_tool,
        )
        if safe_format == "markdown":
            return _session_markdown_response(
                resolved_id,
                page["messages"],
                offset=safe_offset,
                next_offset=page["next_offset"],
                has_more=page["has_more"],
                truncated=page["scan_limited"],
            )
        return _session_page_response(
            "messages",
            page["messages"],
            offset=safe_offset,
            requested_limit=safe_limit,
            extra={"session_id": resolved_id, "format": "json", "profile": safe_profile},
            has_more_override=page["has_more"],
            next_offset_override=page["next_offset"],
        )
    except Exception as exc:
        return _session_error("SESSION_EXPORT_FAILED", _redact_error(exc))
    finally:
        adapter.dispose_safely()


def hermes_session_search(
    query: str,
    limit: int = 20,
    offset: int = DEFAULT_SESSION_OFFSET,
    profile: str = "default",
) -> str:
    safe_profile = _validate_session_profile(profile)
    adapter = ReadOnlySessionAdapter(profile=safe_profile)
    try:
        require_imports()
        if SessionDB is None:
            return "Hermes session search is unavailable in this install: SessionDB import failed."
        rows = adapter.open().search_messages(query=query, limit=limit, offset=offset)
        if not rows:
            return "No matching Hermes session messages found."
        rendered = []
        for row in rows:
            session_id = row.get("session_id", "")
            role = row.get("role", "")
            content = (row.get("content") or "").replace(chr(13), " ").replace(chr(10), " ")
            rendered.append(f"- {session_id} [{role}] {content[:500]}")
        return "\n".join(rendered)
    except _SessionSearchUnavailable as exc:
        message = f"Hermes session search is unavailable in this install: {exc}. Read-only FTS support is unavailable; no FTS activation or rebuild was attempted."
        eprint(f"hermes-gpt: {message}")
        return message
    except Exception as exc:
        message = (
            f"Hermes session search is unavailable in this install: {exc}. "
            "Read-only FTS search was unavailable; no FTS activation or rebuild was attempted."
        )
        eprint(f"hermes-gpt: {message}")
        return message
    finally:
        adapter.dispose_safely()


def hermes_session_continue(
    session_id: str,
    prompt: str,
    timeout: int = DEFAULT_SESSION_TIMEOUT,
    profile: str = "default",
) -> dict[str, Any]:
    """Start one bounded, asynchronous turn in an existing Hermes session for a profile."""
    safe_profile = _validate_session_profile(profile)
    adapter = ReadOnlySessionAdapter(profile=safe_profile)
    try:
        require_imports()
        if not env_enabled(ENABLE_SESSION_CONTROL_ENV):
            return op_session.hermes_session_continue(
                session_id,
                prompt,
                timeout,
                hermes_root=_default_hermes_root(),
                agent_root=HERMES_ROOT,
                profile=safe_profile,
            )
        adapter.open()
        resolved_id = adapter.resolve_session_id(session_id)
        if not resolved_id:
            return op_policy.make_error_envelope(
                layer="session_control",
                code="SESSION_ID_NOT_FOUND_OR_AMBIGUOUS",
                safe_message="The requested session ID was not found or is ambiguous in the requested profile.",
                suggested_action="Use an exact or unique-prefix ID returned by hermes_session_list for that profile.",
            )
        return op_session.hermes_session_continue(
            resolved_id,
            prompt,
            timeout,
            hermes_root=_default_hermes_root(),
            agent_root=HERMES_ROOT,
            profile=safe_profile,
        )
    except Exception as exc:
        return op_policy.make_error_envelope(
            layer="session_control",
            code="SESSION_CONTINUE_FAILED",
            safe_message=_redact_error(exc),
            suggested_action="Check the Hermes session database, profile, and local CLI installation.",
        )
    finally:
        adapter.dispose_safely()


def hermes_session_send(
    session_id: str,
    prompt: str,
    timeout: int = DEFAULT_SESSION_TIMEOUT,
    profile: str = "default",
) -> dict[str, Any]:
    """Alias for profile-aware hermes_session_continue for clients that use send terminology."""
    return hermes_session_continue(session_id, prompt, timeout, profile)


def hermes_session_job_status(job_id: str) -> dict[str, Any]:
    """Return bounded metadata for a Hermes session-control job."""
    return op_session.hermes_session_job_status(job_id, _default_hermes_root())


def hermes_session_job_result(
    job_id: str, max_chars: int = op_session.MAX_RESULT_CHARS
) -> dict[str, Any]:
    """Return the bounded, redacted response from a Hermes session-control job."""
    return op_session.hermes_session_job_result(job_id, max_chars, _default_hermes_root())


# ---------------------------------------------------------------------------
# Hermes tool wrappers (env-gated)
# ---------------------------------------------------------------------------


def hermes_vision_analyze(image_url: str, question: str = "") -> str:
    """Analyze an image using Hermes Agent vision. Env-gated."""
    try:
        require_imports()
        if not env_enabled(ENABLE_VISION_ENV):
            raise RuntimeError(
                f"Vision analysis is disabled. Set {ENABLE_VISION_ENV}=1 to enable it."
            )
        if vision_tool is None:
            raise RuntimeError(
                "Vision tool is not available (import failed at startup)."
            )
        import asyncio

        user_prompt = question if question else "Describe this image in detail."
        result = asyncio.run(
            vision_tool.vision_analyze_tool(
                image_url=image_url, user_prompt=user_prompt
            )
        )
        return result
    except Exception as exc:
        raise clean_error("hermes_vision_analyze", exc) from exc


def hermes_web_search(query: str, limit: int = 5) -> str:
    """Search the web using Hermes Agent web_search. Env-gated."""
    try:
        require_imports()
        if not env_enabled(ENABLE_WEB_ENV):
            raise RuntimeError(
                f"Web search is disabled. Set {ENABLE_WEB_ENV}=1 to enable it."
            )
        if web_tool is None:
            raise RuntimeError(
                "Web tool is not available (import failed at startup)."
            )
        return web_tool.web_search_tool(query=query, limit=limit)
    except Exception as exc:
        raise clean_error("hermes_web_search", exc) from exc


def hermes_web_extract(
    urls: List[str],
    char_limit: int | None = None,
) -> str:
    """Extract content from web pages using Hermes Agent web_extract. Env-gated."""
    try:
        require_imports()
        if not env_enabled(ENABLE_WEB_ENV):
            raise RuntimeError(
                f"Web extract is disabled. Set {ENABLE_WEB_ENV}=1 to enable it."
            )
        if web_tool is None:
            raise RuntimeError(
                "Web tool is not available (import failed at startup)."
            )
        import asyncio

        kwargs = {}
        if char_limit is not None:
            kwargs["char_limit"] = char_limit
        result = asyncio.run(
            web_tool.web_extract_tool(urls=urls, **kwargs)
        )
        return result
    except Exception as exc:
        raise clean_error("hermes_web_extract", exc) from exc


def hermes_finance_analyze(evidence_json: str, timeout: int = 120) -> str:
    """Analyze a bounded finance.evidence/v1 packet with the local Finance profile."""
    return op_finance.hermes_finance_analyze(
        evidence_json=evidence_json,
        timeout=timeout,
        hermes_root=_default_hermes_root(),
        agent_root=HERMES_ROOT,
    )


# ---------------------------------------------------------------------------
# Operator / Owner Mode tools
# ---------------------------------------------------------------------------
#
# These wrap the operator_* modules. They are registered unconditionally
# (so MCP clients can see them and understand why they refuse), but
# mutating tools refuse unless the operator policy is explicitly enabled.
#
# Read-only tools (policy/status/audit_tail, cron list/status, skill diff,
# config get, env status, gateway status, git status/diff) work at any
# enabled level. Mutating tools refuse without sufficient level + apply_mode.


def _hermes_root_for_operator() -> Path | None:
    """Return the Hermes data root for operator operations.

    This intentionally normalizes profile-scoped HERMES_HOME values back to the
    shared Hermes data root so operator/profile tools never treat a profile
    directory or the hermes-agent source checkout as the global root.
    """
    return _default_hermes_root()


def _default_hermes_root() -> Path | None:
    """Return the default Hermes root path (the data root, not the agent source)."""
    env_home = os.environ.get("HERMES_HOME")
    if env_home:
        normalized = op_policy.normalize_hermes_data_root(Path(env_home).expanduser())
        if normalized is not None:
            return normalized
    # The Hermes data root is ~/.hermes (Windows: ~/AppData/Local/hermes).
    # The agent source root lives next to it under hermes-agent/ and is not
    # the same path.
    for cand in [
        Path.home() / "AppData" / "Local" / "hermes",
        Path.home() / ".hermes",
    ]:
        try:
            if cand.is_dir():
                return cand
        except OSError:
            continue
    # Final fallback: ~/.hermes even if it doesn't exist (so tests that
    # monkeypatch this can still pass profile_root into the operator tools).
    return Path.home() / ".hermes"


def _active_profile_name() -> str:
    """Return the active Hermes profile name, or 'default'."""
    try:
        env_home = os.environ.get("HERMES_HOME")
        if env_home:
            p = Path(env_home).expanduser().resolve()
            parts = p.parts
            if "profiles" in parts:
                idx = parts.index("profiles")
                if idx + 1 < len(parts):
                    return parts[idx + 1]
        return "default"
    except Exception:
        return "default"


# --- Policy / status / audit (always registered, read-only) ---------------


def hermes_operator_policy() -> str:
    """Return the current operator policy summary. Read-only. Never secrets."""
    try:
        policy = op_policy.OperatorPolicy()
        summary = policy.to_summary()
        summary["success"] = True
        return json.dumps(summary, indent=2)
    except Exception as exc:
        return json.dumps(
            op_policy.error_from_exception(
                exc,
                layer="operator",
                code="POLICY_SUMMARY_ERROR",
                suggested_action="Check operator environment variables.",
            ),
            indent=2,
        )


def hermes_operator_status() -> str:
    """Return operator runtime status. Read-only. Never secrets."""
    try:
        policy = op_policy.OperatorPolicy()
        project_path = str(Path(__file__).resolve().parent)
        agent_root = str(HERMES_ROOT) if HERMES_ROOT else None
        default_root = str(_default_hermes_root()) if _default_hermes_root() else None
        active_profile = _active_profile_name()

        # Discover registered operator tools by checking this module's
        # attributes. We list the names we explicitly register below.
        registered = [
            "hermes_operator_policy",
            "hermes_operator_status",
            "hermes_operator_audit_tail",
            "hermes_operator_doctor",
            "hermes_operator_snapshot",
            "hermes_release_doctor",
            "hermes_operator_recover",
            "hermes_cron_list",
            "hermes_cron_status",
            "hermes_skill_diff",
            "hermes_config_get",
            "hermes_env_status",
            "hermes_gateway_status",
            "hermes_git_status",
            "hermes_git_diff",
            "hermes_cron_run",
            "hermes_cron_pause",
            "hermes_cron_create",
            "hermes_cron_copy",
            "hermes_cron_move",
            "hermes_skill_create",
            "hermes_skill_edit",
            "hermes_skill_patch",
            "hermes_skill_write_file",
            "hermes_skill_copy",
            "hermes_skill_sync_to_default",
            "hermes_skill_delete",
            "hermes_config_set",
            "hermes_config_patch",
            "hermes_env_set_nonsecret",
            "hermes_env_copy_nonsecret",
            "hermes_gateway_restart",
            "hermes_workspace_read",
            "hermes_export_file",
            "hermes_workspace_patch",
            "hermes_workspace_write_file",
            "hermes_workspace_run_test",
            "hermes_owner_run_command",
            "hermes_owner_patch",
            "hermes_owner_write_file",
            "hermes_fleet_list",
            "hermes_fleet_status",
            "hermes_fleet_dispatch",
            "hermes_fleet_dispatch_work_order",
            "hermes_fleet_task",
            "hermes_fleet_result",
            "hermes_fleet_authority_drift",
            "hermes_mission_overview",
            "hermes_mission_health",
            "hermes_mission_profiles",
            "hermes_mission_fleet",
            "hermes_mission_codex",
            "hermes_mission_cron",
            "hermes_mission_delegations",
            "hermes_mission_failures",
            "hermes_mission_approvals",
            "hermes_mission_vault",
            "hermes_mission_usage",
            "hermes_mission_audit",
            "hermes_mission_create",
            "hermes_mission_get",
            "hermes_mission_list",
            "hermes_mission_update",
            "hermes_mission_attach",
            "hermes_mission_reconcile",
            "hermes_mission_transition",
            "hermes_mission_approve",
            "hermes_plan_create",
            "hermes_plan_get",
            "hermes_plan_list",
            "hermes_plan_validate",
            "hermes_plan_decompose",
            "hermes_plan_review",
            "hermes_plan_node_transition",
            "hermes_plan_set_status",
            "hermes_budget_set",
            "hermes_budget_get",
            "hermes_budget_check",
            "hermes_budget_record",
            "hermes_placement_score",
            "hermes_placement_candidates",
            "hermes_placement_get",
            "hermes_placement_list",
            "hermes_failure_classify",
            "hermes_failure_taxonomy",
            "hermes_recovery_matrix",
            "hermes_controller_plan_list",
            "hermes_live_events_cursor",
            "hermes_live_events_since",
            "hermes_contract_define",
            "hermes_contract_dispatch",
            "hermes_contract_validate",
            "hermes_contract_status",
            "hermes_runner_list",
            "hermes_runner_status",
            "hermes_runner_cancel",
            "hermes_delegation_dispatch",
            "hermes_delegation_get",
            "hermes_delegation_list",
            "hermes_delegation_reconcile",
            "hermes_delegation_cancel",
        ]
        result = {
            "success": True,
            "hermes_gpt_project_path": project_path,
            "hermes_agent_root": agent_root,
            "default_hermes_root": default_root,
            "active_profile": active_profile,
            "enabled": policy.enabled,
            "level": policy.level,
            "apply_mode": policy.apply_mode,
            "owner_active": policy.owner_active,
            "owner_mode_ready": policy.owner_mode_ready,
            "registered_operator_tools": registered,
            "audit_log_path": str(op_policy.audit_log_path()),
        }
        return json.dumps(result, indent=2)
    except Exception as exc:
        return json.dumps(
            op_policy.error_from_exception(
                exc,
                layer="operator",
                code="OPERATOR_STATUS_ERROR",
                suggested_action="Check HERMES_HOME and operator environment variables.",
            ),
            indent=2,
        )


def hermes_operator_audit_tail(limit: int = 20) -> str:
    """Return the last ``limit`` audit records. Read-only."""
    try:
        records = op_policy.audit_tail(limit=limit)
        return json.dumps(
            {"success": True, "count": len(records), "records": records}, indent=2
        )
    except Exception as exc:
        return json.dumps(
            op_policy.error_from_exception(
                exc,
                layer="audit",
                code="AUDIT_TAIL_ERROR",
                suggested_action="Check audit log path and permissions.",
            ),
            indent=2,
        )


def hermes_operator_doctor(profile: str = "default") -> str:
    """Run a read-only health check across operator surfaces."""
    return op_diagnostics.hermes_operator_doctor(
        profile=profile, hermes_root=_default_hermes_root()
    )


def hermes_operator_snapshot(profile: str = "default") -> str:
    """Return a single current-state summary of the operator."""
    return op_diagnostics.hermes_operator_snapshot(
        profile=profile, hermes_root=_default_hermes_root()
    )


def hermes_release_doctor(workdir: str | None = None, full_tests: bool = False, timeout: int = 180) -> str:
    """Check whether the repo/operator is safe to ship."""
    return op_diagnostics.hermes_release_doctor(
        workdir=workdir, full_tests=full_tests, timeout=timeout
    )


def hermes_operator_recover(profile: str = "default", apply: bool = False) -> str:
    """Conservative recovery sequence. Dry-run by default."""
    return op_diagnostics.hermes_operator_recover(
        profile=profile, apply=apply, hermes_root=_default_hermes_root()
    )


def hermes_swarm_reconcile(apply: bool = False) -> str:
    """Reconcile state after a restart (ADR-007): mark interrupted swarm
    stages blocked (never auto-advance) and reload the durable token store.
    Dry-run by default; apply requires workspace+direct."""
    return op_recovery.hermes_operator_reconcile(
        apply=apply, hermes_root=_default_hermes_root()
    )


def hermes_events_query(
    source: str = "",
    subject_id: str = "",
    kind: str = "",
    since: str = "",
    until: str = "",
    limit: int = 50,
) -> str:
    """Query the normalized event timeline (read-only, redacted, bounded)."""
    return op_events.hermes_events_query(
        source=source,
        subject_id=subject_id,
        kind=kind,
        since=since,
        until=until,
        limit=limit,
        hermes_root=_default_hermes_root(),
    )


def hermes_events_tail(limit: int = 20) -> str:
    """Recent events across all allowed sources (read-only, redacted)."""
    return op_events.hermes_events_tail(
        limit=limit, hermes_root=_default_hermes_root()
    )


def hermes_capability_manifest(
    source: str = "",
    include_cache: bool = True,
    limit: int = 100,
) -> str:
    """Query the derived capability manifest (read-only, INV-9, bounded)."""
    return op_capability_manifest.hermes_capability_manifest(
        source=source,
        include_cache=include_cache,
        limit=limit,
        hermes_root=_default_hermes_root(),
    )


def hermes_mission_ledger(
    mission_id: str,
    source: str = "",
    cursor: int | str = 0,
    limit: int = 100,
    replay: bool = False,
) -> str:
    """Query the merged, replayable per-mission ledger (read-only, INV-9).

    ``cursor`` is an opaque watermark token (the ``next_cursor`` value from a
    previous page) or 0 to start from the beginning.
    """
    return op_mission_ledger.hermes_mission_ledger(
        mission_id=mission_id,
        source=source,
        cursor=cursor,
        limit=limit,
        replay=replay,
        hermes_root=_default_hermes_root(),
    )


def hermes_mission_ledger_replay(
    mission_id: str,
    limit: int = 500,
) -> str:
    """Replay a mission's full event history (read-only, INV-9)."""
    return op_mission_ledger.hermes_mission_ledger_replay(
        mission_id=mission_id,
        limit=limit,
        hermes_root=_default_hermes_root(),
    )


def hermes_live_events_cursor() -> str:
    """Return the durable v0.9 live-event high-water cursor."""
    return op_live_events.hermes_live_events_cursor(hermes_root=_default_hermes_root())


def hermes_live_events_since(
    cursor: int = 0,
    mission_id: str = "",
    topic: str = "",
    kind: str = "",
    limit: int = 100,
    wait_ms: int = 0,
) -> str:
    """Read or wait for durable v0.9 live events after a cursor."""
    return op_live_events.hermes_live_events_since(
        cursor=cursor,
        mission_id=mission_id,
        topic=topic,
        kind=kind,
        limit=limit,
        wait_ms=wait_ms,
        hermes_root=_default_hermes_root(),
    )


def hermes_oauth_status() -> str:
    """Durable token store status: presence/expiry only (read-only)."""
    return op_oauth.hermes_oauth_status(hermes_root=_default_hermes_root())


def hermes_oauth_revoke(
    confirm: bool = False, dry_run: bool = True, rotate_key: bool = True
) -> str:
    """Revoke durable OAuth tokens (owner + direct + confirm, pending legal)."""
    return op_oauth.hermes_oauth_revoke(
        confirm=confirm,
        dry_run=dry_run,
        rotate_key=rotate_key,
        hermes_root=_default_hermes_root(),
    )


# --- Fleet wrappers (named A2A peers only) ---------------------------------


def hermes_fleet_list() -> str:
    """List locally registered A2A fleet peers without exposing tokens."""
    return op_fleet.hermes_fleet_list()


def hermes_fleet_status(agent: str, timeout: int = 10) -> str:
    """Check metadata-only compatibility status for one registered fleet peer."""
    return op_fleet.hermes_fleet_status(agent=agent, timeout=timeout)


def hermes_fleet_dispatch(
    agent: str,
    message: str,
    confirm: bool = False,
    dry_run: bool = True,
    timeout: int = 30,
) -> str:
    """Submit a confirmed bounded task to one registered A2A fleet peer."""
    return op_fleet.hermes_fleet_dispatch(
        agent=agent, message=message, confirm=confirm, dry_run=dry_run, timeout=timeout,
    )


def hermes_fleet_task(agent: str, task_id: str, timeout: int = 15) -> str:
    """Return a safe status summary for one task on a registered fleet peer."""
    return op_fleet.hermes_fleet_task(agent=agent, task_id=task_id, timeout=timeout)


def hermes_fleet_dispatch_work_order(
    agent: str,
    task_id: str,
    target_profile: str,
    objective: str,
    workspace: str,
    inputs: list[str],
    constraints: list[str],
    acceptance_checks: list[str],
    deliverables: list[str],
    authorization: dict[str, Any],
    confirm: bool = False,
    dry_run: bool = True,
    timeout: int = 30,
) -> str:
    """Dispatch a canonical, profile-authorized work order to a registered peer."""
    return op_fleet.hermes_fleet_dispatch_work_order(
        agent=agent, task_id=task_id, target_profile=target_profile,
        objective=objective, workspace=workspace, inputs=inputs,
        constraints=constraints, acceptance_checks=acceptance_checks,
        deliverables=deliverables, authorization=authorization,
        confirm=confirm, dry_run=dry_run, timeout=timeout,
    )


def hermes_fleet_result(agent: str, task_id: str, timeout: int = 15) -> str:
    """Return a schema-filtered safe completion bundle."""
    return op_fleet.hermes_fleet_result(agent=agent, task_id=task_id, timeout=timeout)


def hermes_fleet_authority_drift() -> str:
    """Compare registered peers, authority, roles, profiles, and Agent Cards."""
    return op_fleet.hermes_fleet_authority_drift()


# --- Cron wrappers (pass hermes_root through) ----------------------------


def hermes_cron_list(profile: str = "default", include_disabled: bool = False) -> str:
    return op_cron.hermes_cron_list(
        profile=profile, include_disabled=include_disabled,
        hermes_root=_default_hermes_root(),
    )


def hermes_cron_status(profile: str = "default") -> str:
    return op_cron.hermes_cron_status(profile=profile, hermes_root=_default_hermes_root())


def hermes_cron_run(
    profile: str = "default",
    job_id: str = "",
    dry_run: bool = True,
    timeout: int = 1800,
) -> str:
    return op_cron.hermes_cron_run(
        profile=profile, job_id=job_id, dry_run=dry_run, timeout=timeout,
        hermes_root=_default_hermes_root(),
    )


def hermes_cron_pause(profile: str = "default", job_id: str = "", reason: str = "", dry_run: bool = True) -> str:
    return op_cron.hermes_cron_pause(
        profile=profile, job_id=job_id, reason=reason, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_cron_copy(source_profile: str, target_profile: str, job_id: str, dry_run: bool = True) -> str:
    return op_cron.hermes_cron_copy(
        source_profile=source_profile, target_profile=target_profile,
        job_id=job_id, dry_run=dry_run, hermes_root=_default_hermes_root(),
    )


def hermes_cron_create(
    profile: str = "default",
    schedule: str = "",
    prompt: str = "",
    name: str | None = None,
    skills: list[str] | None = None,
    deliver: str | None = None,
    repeat: int | None = None,
    script: str | None = None,
    workdir: str | None = None,
    no_agent: bool | None = None,
    context_from: list[str] | None = None,
    enabled_toolsets: list[str] | None = None,
    model_provider: str | None = None,
    model_name: str | None = None,
    dry_run: bool = True,
) -> str:
    return op_cron.hermes_cron_create(
        profile=profile, schedule=schedule, prompt=prompt, name=name,
        skills=skills, deliver=deliver, repeat=repeat,
        script=script, workdir=workdir, no_agent=no_agent,
        context_from=context_from, enabled_toolsets=enabled_toolsets,
        model_provider=model_provider, model_name=model_name,
        dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_cron_move(
    source_profile: str,
    target_profile: str,
    job_id: str,
    pause_source: bool = True,
    test_run_target: bool = False,
    dry_run: bool = True,
) -> str:
    return op_cron.hermes_cron_move(
        source_profile=source_profile, target_profile=target_profile,
        job_id=job_id, pause_source=pause_source,
        test_run_target=test_run_target, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


# --- Skill wrappers ------------------------------------------------------


def hermes_skill_diff(
    profile: str = "default",
    name: str = "",
    proposed_content: str | None = None,
    old_string: str | None = None,
    new_string: str | None = None,
    file_path: str = "SKILL.md",
) -> str:
    return op_skills.hermes_skill_diff(
        profile=profile, name=name, proposed_content=proposed_content,
        old_string=old_string, new_string=new_string, file_path=file_path,
        hermes_root=_default_hermes_root(),
    )


def hermes_skill_create(profile: str = "default", name: str = "", content: str = "", dry_run: bool = True) -> str:
    return op_skills.hermes_skill_create(
        profile=profile, name=name, content=content, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_skill_edit(profile: str = "default", name: str = "", content: str = "", dry_run: bool = True) -> str:
    return op_skills.hermes_skill_edit(
        profile=profile, name=name, content=content, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_skill_patch(
    profile: str = "default",
    name: str = "",
    old_string: str = "",
    new_string: str = "",
    file_path: str = "SKILL.md",
    replace_all: bool = False,
    dry_run: bool = True,
) -> str:
    return op_skills.hermes_skill_patch(
        profile=profile, name=name, old_string=old_string, new_string=new_string,
        file_path=file_path, replace_all=replace_all, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_skill_write_file(
    profile: str = "default",
    name: str = "",
    file_path: str = "",
    file_content: str = "",
    dry_run: bool = True,
) -> str:
    return op_skills.hermes_skill_write_file(
        profile=profile, name=name, file_path=file_path,
        file_content=file_content, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_skill_copy(source_profile: str, target_profile: str, name: str, dry_run: bool = True) -> str:
    return op_skills.hermes_skill_copy(
        source_profile=source_profile, target_profile=target_profile,
        name=name, dry_run=dry_run, hermes_root=_default_hermes_root(),
    )


def hermes_skill_sync_to_default(source_profile: str, name: str, dry_run: bool = True) -> str:
    return op_skills.hermes_skill_sync_to_default(
        source_profile=source_profile, name=name, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_skill_delete(profile: str = "default", name: str = "", dry_run: bool = True) -> str:
    return op_skills.hermes_skill_delete(
        profile=profile, name=name, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


# --- Config / env wrappers -----------------------------------------------


def hermes_config_get(profile: str = "default", key_path: str | None = None) -> str:
    return op_config.hermes_config_get(
        profile=profile, key_path=key_path, hermes_root=_default_hermes_root(),
    )


def hermes_config_set(profile: str = "default", key_path: str = "", value: Any = None, dry_run: bool = True) -> str:
    return op_config.hermes_config_set(
        profile=profile, key_path=key_path, value=value, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_config_patch(profile: str = "default", old_string: str = "", new_string: str = "", dry_run: bool = True) -> str:
    return op_config.hermes_config_patch(
        profile=profile, old_string=old_string, new_string=new_string,
        dry_run=dry_run, hermes_root=_default_hermes_root(),
    )


def hermes_env_status(profile: str = "default", keys: list[str] | None = None) -> str:
    return op_config.hermes_env_status(
        profile=profile, keys=keys, hermes_root=_default_hermes_root(),
    )


def hermes_env_set_nonsecret(profile: str = "default", key: str = "", value: str = "", dry_run: bool = True) -> str:
    return op_config.hermes_env_set_nonsecret(
        profile=profile, key=key, value=value, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_env_copy_nonsecret(source_profile: str, target_profile: str, key: str, dry_run: bool = True) -> str:
    return op_config.hermes_env_copy_nonsecret(
        source_profile=source_profile, target_profile=target_profile,
        key=key, dry_run=dry_run, hermes_root=_default_hermes_root(),
    )


# --- Gateway / workspace / git / owner wrappers --------------------------


def hermes_gateway_status(profile: str = "default") -> str:
    return op_workspace.hermes_gateway_status(
        profile=profile, hermes_root=_default_hermes_root(),
    )


def hermes_gateway_restart(profile: str = "default", dry_run: bool = True) -> str:
    return op_workspace.hermes_gateway_restart(
        profile=profile, dry_run=dry_run, hermes_root=_default_hermes_root(),
    )


def hermes_workspace_read(path: str, offset: int = 1, limit: int = 500) -> str:
    return op_workspace.hermes_workspace_read(path=path, offset=offset, limit=limit)


def hermes_export_file(path: str) -> CallToolResult:
    return op_export.hermes_export_file(path=path)


def hermes_workspace_patch(
    path: str,
    old_string: str,
    new_string: str,
    replace_all: bool = False,
    dry_run: bool = True,
) -> str:
    return op_workspace.hermes_workspace_patch(
        path=path, old_string=old_string, new_string=new_string,
        replace_all=replace_all, dry_run=dry_run,
    )


def hermes_workspace_write_file(path: str, content: str, dry_run: bool = True) -> str:
    return op_workspace.hermes_workspace_write_file(
        path=path, content=content, dry_run=dry_run,
    )


def hermes_workspace_run_test(command: str, workdir: str | None = None, timeout: int = 120, dry_run: bool = True) -> str:
    return op_workspace.hermes_workspace_run_test(
        command=command, workdir=workdir, timeout=timeout, dry_run=dry_run,
    )


def hermes_git_status(workdir: str) -> str:
    return op_workspace.hermes_git_status(workdir=workdir)


def hermes_git_diff(workdir: str, pathspec: str | None = None, stat: bool = False) -> str:
    return op_workspace.hermes_git_diff(workdir=workdir, pathspec=pathspec, stat=stat)


def hermes_owner_run_command(command: str, timeout: int = 120, workdir: str | None = None, dry_run: bool = True) -> str:
    return op_workspace.hermes_owner_run_command(
        command=command, timeout=timeout, workdir=workdir, dry_run=dry_run,
    )


def hermes_owner_patch(
    path: str,
    old_string: str,
    new_string: str,
    replace_all: bool = False,
    dry_run: bool = True,
) -> str:
    return op_workspace.hermes_owner_patch(
        path=path, old_string=old_string, new_string=new_string,
        replace_all=replace_all, dry_run=dry_run,
    )


def hermes_owner_write_file(path: str, content: str, dry_run: bool = True) -> str:
    return op_workspace.hermes_owner_write_file(path=path, content=content, dry_run=dry_run)


# --- Codex background jobs ------------------------------------------------

def hermes_codex_status() -> dict[str, Any]:
    return op_codex.hermes_codex_status(_default_hermes_root())


def hermes_codex_plan(prompt: str, workdir: str, sandbox: str = "read-only", model: str | None = None,
                      ignore_user_config: bool = False, timeout: int = 900, execution_mode: str = "normal") -> dict[str, Any]:
    return op_codex.hermes_codex_plan(prompt, workdir, sandbox, model, ignore_user_config, timeout, execution_mode=execution_mode)


def hermes_codex_start(prompt: str, workdir: str, sandbox: str = "read-only", model: str | None = None,
                       ignore_user_config: bool = False, timeout: int = 900, confirm: bool = False,
                       dry_run: bool = True, execution_mode: str = "normal") -> dict[str, Any]:
    return op_codex.hermes_codex_start(prompt, workdir, sandbox, model, ignore_user_config, timeout, confirm, dry_run,
                                       _default_hermes_root(), execution_mode=execution_mode)


def hermes_codex_review_start(workdir: str, target: str = "uncommitted", instructions: str = "", model: str | None = None,
                              ignore_user_config: bool = False, timeout: int = 900, confirm: bool = False,
                              dry_run: bool = True) -> dict[str, Any]:
    return op_codex.hermes_codex_review_start(workdir, target, instructions, model, ignore_user_config, timeout, confirm, dry_run, _default_hermes_root())


def hermes_codex_jobs(limit: int = 50) -> dict[str, Any]:
    return op_codex.hermes_codex_jobs(limit, _default_hermes_root())


def hermes_codex_job_status(job_id: str) -> dict[str, Any]:
    return op_codex.hermes_codex_job_status(job_id, _default_hermes_root())


def hermes_codex_job_result(job_id: str, max_chars: int = op_codex.MAX_RESULT_CHARS) -> dict[str, Any]:
    return op_codex.hermes_codex_job_result(job_id, max_chars, _default_hermes_root())


def hermes_codex_cancel(job_id: str, confirm: bool = False, dry_run: bool = True) -> dict[str, Any]:
    return op_codex.hermes_codex_cancel(job_id, confirm, dry_run, _default_hermes_root())


# --- Durable background-job lifecycle ------------------------------------


def hermes_job_status(job_id: str, cursor: int = 0, max_lines: int = 50) -> str:
    """Read durable runner-neutral job state and a cursor-based log tail."""
    return op_jobs.hermes_job_status(
        job_id,
        cursor=cursor,
        max_lines=max_lines,
        hermes_root=_default_hermes_root(),
    )


def hermes_job_wait(
    job_id: str,
    cursor: int = 0,
    wait_seconds: int = op_jobs.MAX_WAIT_SECONDS,
    max_lines: int = 50,
) -> str:
    """Long-poll durable job state for up to 120 seconds and return early on terminal state."""
    return op_jobs.hermes_job_wait(
        job_id,
        cursor=cursor,
        wait_seconds=wait_seconds,
        max_lines=max_lines,
        hermes_root=_default_hermes_root(),
    )


# --- Mission Control (v0.6 M0, read-only) --------------------------------


def hermes_mission_overview(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_overview_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_health(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_health_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_cron(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_cron_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_fleet(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_fleet_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_audit(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_audit_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_profiles(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_profiles_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_delegations(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_delegations_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_failures(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_failures_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_approvals(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_approvals_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_codex(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_codex_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_vault(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_vault_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


def hermes_mission_usage(force_refresh: bool = False) -> str:
    return op_mission.hermes_mission_usage_tool(hermes_root=_default_hermes_root(), force_refresh=force_refresh)


# --- First-class Mission runtime (v0.9) -----------------------------------


def hermes_mission_create(mission_json: str, confirm: bool = False, dry_run: bool = True) -> str:
    return op_mission_runtime.hermes_mission_create(mission_json, confirm, dry_run, _default_hermes_root())


def hermes_mission_get(mission_id: str) -> str:
    return op_mission_runtime.hermes_mission_get(mission_id, _default_hermes_root())


def hermes_mission_list(status: str = "", limit: int = 50) -> str:
    return op_mission_runtime.hermes_mission_list(status, limit, _default_hermes_root())


def hermes_mission_update(mission_id: str, patch_json: str, confirm: bool = False, dry_run: bool = True) -> str:
    return op_mission_runtime.hermes_mission_update(mission_id, patch_json, confirm, dry_run, _default_hermes_root())


def hermes_mission_attach(
    mission_id: str,
    kind: str,
    ref: str,
    relationship: str = "contains",
    state: str = "unknown",
    evidence_ref: str = "",
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    return op_mission_runtime.hermes_mission_attach(
        mission_id,
        kind,
        ref,
        relationship,
        state,
        evidence_ref,
        confirm,
        dry_run,
        _default_hermes_root(),
    )


def hermes_mission_reconcile(mission_id: str, confirm: bool = False, dry_run: bool = True) -> str:
    return op_mission_runtime.hermes_mission_reconcile(mission_id, confirm, dry_run, _default_hermes_root())


def hermes_mission_transition(
    mission_id: str,
    status: str,
    reason: str = "",
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    return op_mission_runtime.hermes_mission_transition(
        mission_id, status, reason, confirm, dry_run, _default_hermes_root()
    )


def hermes_mission_approve(
    mission_id: str,
    approval_reference: str,
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    return op_mission_runtime.hermes_mission_approve(
        mission_id, approval_reference, confirm, dry_run, _default_hermes_root()
    )


# --- MissionPlan (decomposition DAG, additive; read-only re missions) ------


def hermes_plan_create(
    mission_id: str,
    plan_json: str = "",
    confirm: bool = False,
    dry_run: bool = True,
    status: str = "draft",
) -> str:
    """Create (or replace-version) a MissionPlan for a mission (additive, read-only re mission)."""
    return op_mission_plan.hermes_plan_create(
        mission_id, plan_json, confirm=confirm, dry_run=dry_run, status=status, hermes_root=_default_hermes_root()
    )


def hermes_plan_get(mission_id: str) -> str:
    """Read the MissionPlan + plan_nodes for a mission (read-only)."""
    return op_mission_plan.hermes_plan_get(mission_id, _default_hermes_root())


def hermes_plan_list(status: str = "", limit: int = 50) -> str:
    """List MissionPlans (read-only)."""
    return op_mission_plan.hermes_plan_list(status, limit, _default_hermes_root())


def hermes_plan_validate(plan_json: str) -> str:
    """Pure read-only validation of a MissionPlan document."""
    return op_mission_plan.hermes_plan_validate(plan_json)


def hermes_plan_decompose(mission_id: str) -> str:
    """Deterministically decompose a MissionSpec into a bounded plan DAG (read-only)."""
    return op_mission_plan.hermes_plan_decompose(mission_id, _default_hermes_root())


def hermes_plan_review(mission_id: str) -> str:
    """Operator review surface: the bounded DAG + node state (read-only)."""
    return op_mission_plan.hermes_plan_review(mission_id, _default_hermes_root())


def hermes_plan_node_transition(
    mission_id: str,
    node_id: str,
    target_state: str,
    reason: str = "",
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    """Advance a plan node via the validated state machine (read-only re mission)."""
    return op_mission_plan.hermes_plan_node_transition(
        mission_id, node_id, target_state, reason, confirm=confirm, dry_run=dry_run, hermes_root=_default_hermes_root()
    )


def hermes_plan_approve_gate(
    mission_id: str,
    node_id: str,
    reason: str = "",
    confirm: bool = False,
    dry_run: bool = True,
    expected_plan_version: int | None = None,
) -> str:
    """Owner-only: approve a gated plan node (approval or high_impact) to completed in one call.

    Walks the shortest legal node-state path to completed through the existing
    node transition, one step per call. Dry run by default; a direct write needs
    Owner Mode, direct apply mode, dry_run=false and confirm=true.
    """
    return op_mission_plan.hermes_plan_approve_gate(
        mission_id,
        node_id,
        reason,
        confirm=confirm,
        dry_run=dry_run,
        expected_plan_version=expected_plan_version,
        hermes_root=_default_hermes_root(),
    )


def hermes_plan_set_status(
    mission_id: str,
    status: str,
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    """Set the plan-level review status (operator-reviewable, read-only re mission)."""
    return op_mission_plan.hermes_plan_set_status(
        mission_id, status, confirm=confirm, dry_run=dry_run, hermes_root=_default_hermes_root()
    )


# --- Mission budget envelope (spend envelope + budget_check; dry-run) -------


def hermes_budget_set(
    mission_id: str,
    quota: float,
    policy_json: str = "",
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    """Create (or update) the mission-scoped spend envelope (budget_accounts)."""
    return op_mission_budget.hermes_budget_set(
        mission_id, quota, policy_json, confirm=confirm, dry_run=dry_run, hermes_root=_default_hermes_root()
    )


def hermes_budget_get(mission_id: str) -> str:
    """Read the mission spend envelope (read-only)."""
    return op_mission_budget.hermes_budget_get(mission_id, _default_hermes_root())


def hermes_budget_check(mission_id: str) -> str:
    """Evaluate the mission spend envelope (read-only `budget_check` surface)."""
    return op_mission_budget.hermes_budget_check(mission_id, _default_hermes_root())


def hermes_budget_record(
    mission_id: str,
    amount: float,
    ref: str = "",
    reason: str = "",
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    """Record a spend increment against a mission envelope (dry-run enforcement)."""
    return op_mission_budget.hermes_budget_record(
        mission_id, amount, ref, reason, confirm=confirm, dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


# --- Deterministic placement scoring (vNext slice-1, phase 2) -----------------


def hermes_placement_score(
    mission_id: str,
    node_id: str,
    source: str = "",
    features: str = "",
    workspace: str = "",
    backends: str = "",
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    """Score + record a plan node's placement (deterministic, dry-run-first).

    No assignment executes (``would_assign=False``); the controller proposes,
    actual dispatch goes through the existing contract/fleet/delegation surfaces.
    """
    return op_placement.hermes_placement_score(
        mission_id, node_id, source=source, features=features, workspace=workspace,
        backends=backends, confirm=confirm, dry_run=dry_run, hermes_root=_default_hermes_root(),
    )


def hermes_placement_candidates(
    profile: str,
    skills: str = "",
    authorization_class: str = "reversible_write",
    features: str = "",
    workspace: str = "",
    backends: str = "",
    source: str = "",
) -> str:
    """Read-only probe: candidate targets + per-candidate filter/score."""
    return op_placement.hermes_placement_candidates(
        profile, skills=skills, authorization_class=authorization_class, features=features,
        workspace=workspace, backends=backends, source=source, hermes_root=_default_hermes_root(),
    )


def hermes_placement_get(mission_id: str, node_id: str) -> str:
    """Read a recorded placement decision (read-only)."""
    return op_placement.hermes_placement_get(mission_id, node_id, hermes_root=_default_hermes_root())


def hermes_placement_list(mission_id: str, limit: int = 50) -> str:
    """List recorded placement decisions for a mission (read-only)."""
    return op_placement.hermes_placement_list(mission_id, limit, hermes_root=_default_hermes_root())


# --- Semantic failure classification + recovery matrix (vNext slice-1, phase 3)


def hermes_failure_classify(
    mission_id: str,
    node_id: str,
    observation_json: str,
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    """Classify an observation envelope; propose the smallest recovery action.

    Decision output only (§17 item 7): ``would_execute`` is always False; no
    dispatch/reclaim/redispatch/approval path exists. Recording the decision to
    ``controller_plan`` requires workspace + direct + confirm.
    """
    return op_failure_semantics.hermes_failure_classify(
        mission_id, node_id, observation_json,
        confirm=confirm, dry_run=dry_run, hermes_root=_default_hermes_root(),
    )


def hermes_failure_taxonomy() -> str:
    """Read-only: the authoritative 8-class failure taxonomy (§11.1)."""
    return op_failure_semantics.hermes_failure_taxonomy()


def hermes_recovery_matrix(row_key: str = "") -> str:
    """Read-only: the deterministic smallest-first recovery matrix (§11.2)."""
    return op_failure_semantics.hermes_recovery_matrix(row_key)


def hermes_controller_plan_list(mission_id: str, limit: int = 50) -> str:
    """Read-only: recorded failure decisions (controller_plan rows)."""
    return op_failure_semantics.hermes_controller_plan_list(
        mission_id, limit, hermes_root=_default_hermes_root()
    )


# --- Supervised mission controller — shadow/observe reconciler loop (§17 item 6);


def hermes_controller_reconcile(
    mission_id: str,
    trigger_kind: str = "T5_manual",
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    """Run one controller reconciler pass (observe → classify → smallest action).

    L0/L1 (default): the controller observes authoritative
    mission/plan/delegation/runner state, classifies it via the Ops 8-class
    taxonomy, and emits the smallest recovery action — nothing is dispatched.

    ``dry_run=True`` (default) is a truthful preview: no durable writes to any
    mission/plan/delegation/controller state (only the repo-wide Operator
    audit trail every tool call produces).
    ``dry_run=False`` records the pass (controller_plan + controller_telemetry
    + pass lease + heartbeat) and requires workspace level with direct apply
    mode.

    L2 rung (opt-in, v0.12 slice-2): when the machine gate
    ``HERMES_GPT_CONTROLLER_EXECUTE=1`` is set AND ``confirm=True`` here AND the
    live policy is enabled with direct apply mode at workspace level, the pass
    EXECUTES its single smallest action (a dispatch) through the existing
    work-contract/delegation authority surface, keyed idempotently. Every other
    combination stays decision-only with ``would_execute`` False and an additive
    ``execution`` block naming the stable refusal reason. The rung never
    completes, approves, weakens evidence, replans, or retries unboundedly.
    """
    return op_controller.hermes_controller_reconcile(
        mission_id,
        trigger_kind,
        confirm=confirm,
        dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_controller_status() -> str:
    """Read-only controller health surface (§12.2): liveness, passes, counts."""
    return op_controller.hermes_controller_status(_default_hermes_root())


def hermes_controller_lease_list(mission_id: str = "") -> str:
    """Read-only: current per-mission pass leases + trigger-queue conflation state."""
    return op_controller.hermes_controller_lease_list(
        mission_id, hermes_root=_default_hermes_root()
    )


def hermes_controller_trigger(mission_id: str, trigger_kind: str, ref: str = "") -> str:
    """Enqueue a T1–T5 work request for the reconciler (advisory; shadow)."""
    return op_controller.hermes_controller_trigger(
        mission_id, trigger_kind, ref, hermes_root=_default_hermes_root()
    )


# --- Owner inbox and advisory review assist (v0.15) -----------------------
#
# The wrappers hide hermes_root from the MCP input schema and pass the
# server's data root, matching the other operator wrappers.


def hermes_owner_inbox(limit: int = 50, include_acknowledged: bool = False) -> str:
    """Read-only list of what is waiting on the Owner (approvals, Autopilot, controller attention).

    Lists items and suggests the existing gated tool to use; never approves, advances or changes anything.
    Acknowledged items are hidden unless include_acknowledged is true.
    Check ``sources`` and ``complete`` before treating an empty list as no pending work.
    """
    return op_owner_inbox.hermes_owner_inbox(
        limit=limit,
        include_acknowledged=include_acknowledged,
        hermes_root=_default_hermes_root(),
    )


def hermes_owner_inbox_ack(item_ids: list[str], dry_run: bool = True) -> str:
    """Hide Owner-inbox items by id. Acknowledging is not handling and approves nothing.

    Dry run by default. A direct write needs the workspace Operator level, direct apply mode and dry_run=false.
    Only ids in the current inbox are acknowledged; others are reported as unknown.
    """
    return op_owner_inbox.hermes_owner_inbox_ack(
        item_ids=item_ids,
        dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_attention_delivery_status() -> str:
    """Read-only status of the attention delivery relay: configuration state and per-target health.

    Registered only when HERMES_GPT_ATTENTION_DELIVERY=1. It reports and never sends a message.
    """
    return json.dumps(op_attention_delivery.status(_default_hermes_root()), sort_keys=True)


async def hermes_review_assess(contract_sha256: str, artifact: str | None = None) -> str:
    """Advisory Jev score of a dispatched Work Contract's state. Sends text to TypeSafe; never evidence or acceptance.

    Registered only when HERMES_GPT_ENABLE_JEV=1 and HERMES_GPT_REVIEW_ASSIST=1 are both set.
    """
    return await op_review_assist.hermes_review_assess(
        contract_sha256, artifact, _default_hermes_root()
    )


# --- Autopilot (v0.13 PR1) --------------------------------------------------
#
# Durable runtime only: places a Mission under Autopilot control via a
# detached worker process (survives MCP disconnect/restart) and reports
# truthful status by reconciling worker liveness, never a cached belief. The
# worker itself does not yet dispatch any node (see docs/design/v0.13-autopilot.md).
# Default OFF: gated both by tool registration below (HERMES_GPT_AUTOPILOT=1)
# and, redundantly, by a live re-read inside op_autopilot for any direct call.


def hermes_autopilot_start(
    mission_id: str,
    max_concurrency: int = 3,
    max_replans: int = 2,
    confirm: bool = False,
    dry_run: bool = True,
    max_attempts_per_node: int = 3,
    max_runtime_seconds: int = 86400,
) -> str:
    """Place a Mission under durable Autopilot control.

    Dry-run-first; a direct call additionally requires confirm=true and the
    HERMES_GPT_AUTOPILOT=1 machine gate. Idempotent while a non-terminal run
    already exists for the Mission. Limits: max_concurrency (1-16), max_replans
    (0-10), max_attempts_per_node (1-10, first attempt included) and
    max_runtime_seconds (60-604800; new work stops at the limit and the run ends
    once in-flight work has drained). New dispatch also stops whenever the
    Mission's budget envelope is not verifiably within.
    """
    return op_autopilot.hermes_autopilot_start(
        mission_id, max_concurrency=max_concurrency, max_replans=max_replans,
        confirm=confirm, dry_run=dry_run, hermes_root=_default_hermes_root(),
        max_attempts_per_node=max_attempts_per_node, max_runtime_seconds=max_runtime_seconds,
    )


def hermes_autopilot_status(mission_id: str) -> str:
    """Read-only Autopilot status for a Mission; reconciles worker liveness first."""
    return op_autopilot.hermes_autopilot_status(mission_id, hermes_root=_default_hermes_root())


def hermes_autopilot_stop(
    mission_id: str,
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    """Request that a Mission's Autopilot worker stop. Always allowed (the safe direction)."""
    return op_autopilot.hermes_autopilot_stop(
        mission_id, confirm=confirm, dry_run=dry_run, hermes_root=_default_hermes_root(),
    )


def hermes_mission_launch(
    spec_json: str,
    budget_json: str | None = None,
    autopilot_limits_json: str | None = None,
    dry_run: bool = True,
    confirm: bool = False,
    request_id: str | None = None,
) -> str:
    """Objective to running Autopilot in one call: create Mission, derive plan, set budget, start Autopilot.

    Dry run by default and writes nothing. Apply needs dry_run=false and confirm=true, plus the
    workspace Operator level in direct apply mode and HERMES_GPT_AUTOPILOT=1. Approval is not
    touched: the Mission still stops at awaiting_approval. An optional request_id
    returns the same durable receipt on replay and never resumes partial work.
    """
    return op_mission_launch.hermes_mission_launch(
        spec_json=spec_json,
        budget_json=budget_json,
        autopilot_limits_json=autopilot_limits_json,
        dry_run=dry_run,
        confirm=confirm,
        request_id=request_id,
        hermes_root=_default_hermes_root(),
    )


# --- Work Contracts (v0.6 M1) ----------------------------------------------


def hermes_contract_define(contract_json: str) -> str:
    return op_contract.hermes_contract_define(contract_json=contract_json, hermes_root=_default_hermes_root())


def hermes_contract_dispatch(
    contract_json: str,
    confirm: bool = False,
    dry_run: bool = True,
    timeout: int = 30,
) -> str:
    return op_contract.hermes_contract_dispatch(
        contract_json=contract_json,
        confirm=confirm,
        dry_run=dry_run,
        timeout=timeout,
        hermes_root=_default_hermes_root(),
    )


def hermes_contract_validate(contract_json: str) -> str:
    return op_contract.hermes_contract_validate(contract_json=contract_json, hermes_root=_default_hermes_root())


def hermes_contract_status(contract_json: str) -> str:
    return op_contract.hermes_contract_status(contract_json=contract_json, hermes_root=_default_hermes_root())


# --- Pluggable Runner Backends ---------------------------------------------


def hermes_runner_list() -> str:
    return op_runners.hermes_runner_list(hermes_root=_default_hermes_root())


def hermes_runner_status(task_id: str) -> str:
    return op_runners.hermes_runner_status(task_id=task_id, hermes_root=_default_hermes_root())


def hermes_runner_cancel(
    task_id: str,
    backend: str = "",
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    return op_runners.hermes_runner_cancel(
        task_id=task_id,
        backend=backend,
        confirm=confirm,
        dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


# --- Unified Delegation Lifecycle (v0.9) -----------------------------------


def hermes_delegation_dispatch(
    contract_json: str,
    mission_id: str = "",
    delegation_id: str = "",
    confirm: bool = False,
    dry_run: bool = True,
    timeout: int = 30,
) -> str:
    return op_delegations.hermes_delegation_dispatch(
        contract_json=contract_json,
        mission_id=mission_id,
        delegation_id=delegation_id,
        confirm=confirm,
        dry_run=dry_run,
        timeout=timeout,
        hermes_root=_default_hermes_root(),
    )


def hermes_delegation_get(delegation_id: str) -> str:
    return op_delegations.hermes_delegation_get(
        delegation_id=delegation_id,
        hermes_root=_default_hermes_root(),
    )


def hermes_delegation_list(
    mission_id: str = "",
    state: str = "",
    limit: int = 50,
) -> str:
    return op_delegations.hermes_delegation_list(
        mission_id=mission_id,
        state=state,
        limit=limit,
        hermes_root=_default_hermes_root(),
    )


def hermes_delegation_reconcile(
    delegation_id: str,
    contract_json: str = "",
    apply: bool = False,
) -> str:
    return op_delegations.hermes_delegation_reconcile(
        delegation_id=delegation_id,
        contract_json=contract_json,
        apply=apply,
        hermes_root=_default_hermes_root(),
    )


def hermes_delegation_cancel(
    delegation_id: str,
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    return op_delegations.hermes_delegation_cancel(
        delegation_id=delegation_id,
        confirm=confirm,
        dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_review_accept(
    contract_sha256: str,
    task_id: str,
    assignee: str,
    reviewer: str,
    verdict: str,
    evidence_refs: list[str] | None = None,
    approval_reference: str = "",
    dry_run: bool = True,
    confirm: bool = False,
) -> str:
    """Write a review-acceptance record for a contract (owner-gated, distinct
    reviewer enforced, audited). Evidence is referenced, never copied."""
    return op_review.hermes_review_accept(
        contract_sha256=contract_sha256,
        task_id=task_id,
        assignee=assignee,
        reviewer=reviewer,
        verdict=verdict,
        evidence_refs=evidence_refs,
        approval_reference=approval_reference,
        dry_run=dry_run,
        confirm=confirm,
        hermes_root=_default_hermes_root(),
    )


# --- Swarm Orchestration (v0.6 M2) ----------------------------------------


def hermes_swarm_workflow_create(workflow_json: str, confirm: bool = False, dry_run: bool = True) -> str:
    return op_swarm.hermes_swarm_workflow_create(
        workflow_json=workflow_json,
        confirm=confirm,
        dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_swarm_workflow_list() -> str:
    return op_swarm.hermes_swarm_workflow_list(hermes_root=_default_hermes_root())


def hermes_swarm_workflow_status(workflow_id: str) -> str:
    return op_swarm.hermes_swarm_workflow_status(workflow_id=workflow_id, hermes_root=_default_hermes_root())


def hermes_swarm_workflow_validate(workflow_json: str) -> str:
    return op_swarm.hermes_swarm_workflow_validate(workflow_json=workflow_json, hermes_root=_default_hermes_root())


def hermes_swarm_stage_dispatch(
    workflow_id: str,
    stage_id: str,
    confirm: bool = False,
    dry_run: bool = True,
    timeout: int = 30,
) -> str:
    return op_swarm.hermes_swarm_stage_dispatch(
        workflow_id=workflow_id,
        stage_id=stage_id,
        confirm=confirm,
        dry_run=dry_run,
        timeout=timeout,
        hermes_root=_default_hermes_root(),
    )


def hermes_swarm_stage_advance(
    workflow_id: str,
    stage_id: str,
    confirm: bool = False,
    dry_run: bool = True,
) -> str:
    return op_swarm.hermes_swarm_stage_advance(
        workflow_id=workflow_id,
        stage_id=stage_id,
        confirm=confirm,
        dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def hermes_swarm_approve(workflow_id: str, confirm: bool = False, dry_run: bool = True) -> str:
    return op_swarm.hermes_swarm_approve(
        workflow_id=workflow_id,
        confirm=confirm,
        dry_run=dry_run,
        hermes_root=_default_hermes_root(),
    )


def oauth_state_from_env() -> oauth_auth.OAuthState | None:
    config = oauth_auth.config_from_env()
    if config is None:
        return None
    state = oauth_auth.OAuthState(config)
    # v0.7 S5: restore durable tokens from the encrypted envelope so a
    # restart does not invalidate issued credentials (ADR-001). Best-effort:
    # a missing/corrupt envelope fails closed to empty stores.
    try:
        state.restore_tokens(_default_hermes_root())
    except Exception:
        pass
    return state


def auth_enabled() -> bool:
    return oauth_auth.static_bearer_from_env() is not None or oauth_auth.config_from_env() is not None


def trusted_proxy_ips_from_env() -> str:
    raw_value = os.environ.get(TRUSTED_PROXY_IPS_ENV, "").strip()
    if not raw_value:
        return ""
    addresses: list[str] = []
    for value in raw_value.split(","):
        candidate = value.strip()
        try:
            address = ipaddress.ip_address(candidate)
        except ValueError as exc:
            raise ValueError(f"{TRUSTED_PROXY_IPS_ENV} must contain only comma-separated IP addresses.") from exc
        if not address.is_loopback:
            raise ValueError(f"{TRUSTED_PROXY_IPS_ENV} accepts loopback proxy addresses only.")
        addresses.append(str(address))
    return ",".join(dict.fromkeys(addresses))


def authenticated_http_security_options(
    *,
    profile: str,
    host: str,
    cert: str | None,
    key: str | None,
    configured_auth: bool,
) -> tuple[bool, str]:
    if bool(cert) != bool(key):
        raise SystemExit("TLS requires both --cert and --key.")
    if profile != REMOTE_PROFILE or not configured_auth:
        return False, ""
    if cert and key:
        return False, ""
    try:
        trusted_proxies = trusted_proxy_ips_from_env()
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    if not trusted_proxies or not is_loopback_host(host):
        raise SystemExit(
            "Authenticated remote mode requires direct TLS (--cert and --key), or a loopback bind behind an "
            f"explicit trusted HTTPS proxy configured with {TRUSTED_PROXY_IPS_ENV}."
        )
    return True, trusted_proxies


async def health_root(_request: Request) -> JSONResponse:
    return JSONResponse({"status": "ok", "server": "hermes-gpt", "mcp_path": "/mcp"})


def _fleet_peer_name() -> str:
    return os.environ.get("HERMES_GPT_FLEET_PEER_NAME", "").strip() or "hermes-peer"


def _fleet_peer_url() -> str:
    return (
        os.environ.get("HERMES_GPT_FLEET_PEER_URL", "").strip()
        or f"http://{os.environ.get('HERMES_GPT_HOST', '127.0.0.1')}:{os.environ.get('HERMES_GPT_PORT', '4750')}"
    )


async def _fleet_agent_card(_request: Request) -> JSONResponse:
    """Agent Card for this Fleet peer. The fleet authority manifest pins
    expected_card_identity to HERMES_GPT_FLEET_PEER_NAME; this route attests
    that identity. No secrets, tokens, or credentials are returned."""
    peer_name = _fleet_peer_name()
    peer_url = _fleet_peer_url()
    return JSONResponse(
        {
            "protocolVersion": "1.0",
            "name": peer_name,
            "description": "Hermes Fleet peer",
            "version": os.environ.get("HERMES_GPT_FLEET_PEER_VERSION", "0.20.5"),
            "url": peer_url,
            "capabilities": {},
            "defaultInputModes": ["application/json"],
            "defaultOutputModes": ["application/json"],
            "skills": [
                {
                    "id": "hermes-agent-v1",
                    "name": "Hermes Agent",
                    "description": "Local-first Hermes Agent",
                    "tags": ["hermes", "fleet"],
                }
            ],
            "supportedInterfaces": [
                {
                    "url": peer_url,
                    "protocolBinding": "JSONRPC",
                    "protocolVersion": "1.0",
                }
            ],
        }
    )


def _register_fleet_local_card() -> None:
    """Publish this peer's own Agent Card for in-process loopback verification.

    Keeps the fleet drift/status tools from deadlocking when they fetch the
    card of a co-located peer over 127.0.0.1. The identity here must match the
    fleet authority manifest entry (expected_card_identity = HERMES_GPT_FLEET_PEER_NAME).
    """
    try:
        import operator_fleet as _op

        peer_name = _fleet_peer_name()
        peer_url = _fleet_peer_url()
        _op.register_local_agent_card(
            peer_url,
            {
                "protocolVersion": "1.0",
                "name": peer_name,
                "description": "Hermes Fleet peer",
                "version": os.environ.get("HERMES_GPT_FLEET_PEER_VERSION", "0.20.5"),
                "url": peer_url,
                "capabilities": {},
                "defaultInputModes": ["application/json"],
                "defaultOutputModes": ["application/json"],
                "skills": [
                    {
                        "id": "hermes-agent-v1",
                        "name": "Hermes Agent",
                        "description": "Local-first Hermes Agent",
                        "tags": ["hermes", "fleet"],
                    }
                ],
                "supportedInterfaces": [
                    {
                        "url": peer_url,
                        "protocolBinding": "JSONRPC",
                        "protocolVersion": "1.0",
                    }
                ],
            },
        )
    except Exception:  # noqa: BLE001
        pass


def build_asgi_app(server: FastMCP, *, http: bool) -> Any:
    oauth_state = getattr(server, "_hermes_oauth_state", None)
    if oauth_state is not None and not http:
        raise ValueError("Built-in OAuth is supported only with streamable HTTP (--http).")
    raw_mcp_app = server.streamable_http_app() if http else server.sse_app()
    mcp_app = oauth_auth.DefaultMcpAcceptMiddleware(raw_mcp_app)
    static_bearer = oauth_auth.static_bearer_from_env() or ""

    async def live_websocket_authorized(websocket: Any) -> bool:
        """Reuse the normal Hermes HTTP auth authority for WebSocket handshakes."""
        if oauth_state is None and not static_bearer:
            return True
        admitted = False

        async def admitted_app(_scope: dict[str, Any], _receive: Any, _send: Any) -> None:
            nonlocal admitted
            admitted = True

        auth_middleware = oauth_auth.BearerAuthMiddleware(
            admitted_app,
            oauth_state,
            static_token=static_bearer,
        )
        scope = dict(websocket.scope)
        scope.update(
            {
                "type": "http",
                "http_version": scope.get("http_version", "1.1"),
                "scheme": "http",
                "method": "POST",
                "path": "/mcp",
                "raw_path": b"/mcp",
                "query_string": b"",
            }
        )
        request_sent = False

        async def receive() -> dict[str, Any]:
            nonlocal request_sent
            if request_sent:
                return {"type": "http.disconnect"}
            request_sent = True
            return {"type": "http.request", "body": b"", "more_body": False}

        async def send(_message: dict[str, Any]) -> None:
            return None

        await auth_middleware(scope, receive, send)
        return admitted

    routes: list[BaseRoute] = [Route("/", health_root, methods=["GET", "POST", "OPTIONS"])]
    # Fleet Agent Card (env-driven identity; generic across peers). Behind the
    # same outer Bearer/OAuth middleware as MCP. No secret material returned.
    routes.extend(
        [
            Route("/.well-known/agent-card.json", _fleet_agent_card, methods=["GET"]),
            Route("/.well-known/agent.json", _fleet_agent_card, methods=["GET"]),
        ]
    )
    if oauth_state is not None:
        async def resource_metadata(request: Request) -> JSONResponse:
            return oauth_auth.protected_resource_metadata(request, oauth_state)

        async def authorization_server_metadata(request: Request) -> JSONResponse:
            return oauth_auth.authorization_metadata(request, oauth_state)

        async def authorize(request: Request) -> Response:
            return oauth_auth.authorize(request, oauth_state)

        async def token(request: Request) -> JSONResponse:
            return await oauth_auth.token(request, oauth_state)

        routes.extend(
            [
                Route("/.well-known/oauth-protected-resource", resource_metadata, methods=["GET"]),
                Route("/.well-known/oauth-protected-resource/mcp", resource_metadata, methods=["GET"]),
                Route("/.well-known/oauth-authorization-server", authorization_server_metadata, methods=["GET"]),
                Route("/oauth/authorize", authorize, methods=["GET"]),
                Route("/oauth/token", token, methods=["POST"]),
            ]
        )
    # Mount browser UI routes before the MCP catch-all. The UI remains opt-in
    # and a missing optional UI module must not change the MCP-only server.
    ui_enabled = False
    try:
        import ui_security as _ui_security

        ui_enabled = _ui_security.ui_enabled()
    except Exception:  # noqa: BLE001
        ui_enabled = os.environ.get("HERMES_GPT_UI_ENABLED") == "1"
    if ui_enabled:
        try:
            import ui_api

            try:
                import ui_ops
            except ImportError:
                eprint("UI operator module unavailable")
            else:
                ui_ops.set_agent_root_provider(lambda: HERMES_ROOT)

            routes.extend(ui_api.routes())
        except Exception as exc:  # noqa: BLE001
            eprint(f"UI mount skipped: {exc.__class__.__name__}: {exc}")
    # v0.9 live-event delivery is read-only and remains behind the same outer
    # Bearer/OAuth middleware as MCP and the browser UI.
    routes.extend(
        op_live_events.websocket_routes(
            _default_hermes_root,
            auth_check=live_websocket_authorized,
        )
    )
    routes.append(Mount("/", app=mcp_app))
    app = Starlette(routes=routes, lifespan=raw_mcp_app.router.lifespan_context)
    issuer = oauth_state.config.issuer if oauth_state is not None else ""
    parsed_issuer = urllib.parse.urlparse(issuer)
    issuer_origin = f"{parsed_issuer.scheme}://{parsed_issuer.netloc}" if parsed_issuer.netloc else ""
    origins = [origin for origin in ("https://chatgpt.com", issuer_origin) if origin]
    return CORSMiddleware(
        oauth_auth.BearerAuthMiddleware(app, oauth_state, static_token=static_bearer),
        allow_origins=origins,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["*"],
        max_age=86400,
    )


def build_server(
    *,
    host: str = "127.0.0.1",
    port: int = 7677,
    http: bool = False,
    include_local_settings: bool = False,
) -> FastMCP:
    oauth_state = oauth_state_from_env()
    allowed_hosts = [host, f"{host}:{port}", "127.0.0.1", f"127.0.0.1:{port}", "localhost", f"localhost:{port}"]
    extra_allowed_hosts = [
        item.strip()
        for item in os.environ.get(ALLOWED_HOSTS_ENV, "").split(",")
        if item.strip()
    ]
    allowed_hosts.extend(extra_allowed_hosts)
    allowed_origins = ["https://chatgpt.com"]
    if oauth_state is not None:
        issuer = urllib.parse.urlparse(oauth_state.config.issuer)
        if issuer.hostname:
            allowed_hosts.append(issuer.hostname)
            if issuer.port:
                allowed_hosts.append(f"{issuer.hostname}:{issuer.port}")
        allowed_origins.append(f"{issuer.scheme}://{issuer.netloc}")
    server = FastMCP(
        "hermes-gpt",
        version=VERSION,
        host=host,
        port=port,
        streamable_http_path="/mcp",
        sse_path="/sse",
        message_path="/messages/",
        stateless_http=http,
        json_response=http,
        transport_security=TransportSecuritySettings(
            allowed_hosts=list(dict.fromkeys(allowed_hosts)),
            allowed_origins=list(dict.fromkeys(allowed_origins)),
        ),
    )
    setattr(server, "_hermes_oauth_state", oauth_state)
    if oauth_state is not None:
        # v0.7 S5: persist every token issuance/refresh through token_store.
        # Persistence failures PROPAGATE: the strict exchange path turns them
        # into OAuth errors instead of handing out uncommitted credentials.
        def _persist(state, kind: str) -> None:
            state.persist_tokens(_default_hermes_root())

        oauth_auth.set_persist_hook(_persist)
        # Durable revocation (hermes_oauth_revoke) must also drop this
        # process's in-memory token caches, or the next issuance would
        # re-persist the revoked tokens through _persist.
        oauth_auth.set_revocation_hook(oauth_state.clear_live_tokens)
    register_tools(server)
    return server


ToolEntry = tool_registry.ToolEntry


def _plain(*fns: Any) -> list[ToolEntry]:
    """Ungated entries, in the order given."""
    return [ToolEntry(fn) for fn in fns]


def _env_gate(name: str) -> Callable[[], bool]:
    return lambda: env_enabled(name)


def _jev_annotations() -> ToolAnnotations:
    return ToolAnnotations(
        readOnlyHint=True, destructiveHint=False,
        idempotentHint=False, openWorldHint=True,
    )


def _core_tools() -> list[ToolEntry]:
    return _plain(
        hermes_read_file,
        hermes_search_files,
        hermes_memory,
        hermes_skill_list,
        hermes_skill_view,
    )


def _write_tools() -> list[ToolEntry]:
    gate = _env_gate(ENABLE_WRITE_ENV)
    return [ToolEntry(hermes_write_file, gate=gate), ToolEntry(hermes_patch, gate=gate)]


def _terminal_tools() -> list[ToolEntry]:
    return [ToolEntry(hermes_run_command, gate=_env_gate(ENABLE_TERMINAL_ENV))]


def _session_search_tools() -> list[ToolEntry]:
    gate = _env_gate(ENABLE_SESSION_SEARCH_ENV)
    return [
        ToolEntry(hermes_session_search, gate=gate),
        ToolEntry(hermes_session_list, gate=gate),
        ToolEntry(hermes_session_read, gate=gate),
        ToolEntry(hermes_session_export, gate=gate),
        ToolEntry(hermes_bot_chat_get, gate=gate),
    ]


def _session_control_tools() -> list[ToolEntry]:
    control = _env_gate(ENABLE_SESSION_CONTROL_ENV)
    search = _env_gate(ENABLE_SESSION_SEARCH_ENV)
    return [
        ToolEntry(hermes_session_continue, gate=control),
        ToolEntry(hermes_session_send, gate=control),
        # Chat send needs the session-search gate as well (nested in the original).
        ToolEntry(hermes_bot_chat_send, gate=lambda: control() and search()),
        ToolEntry(hermes_session_job_status, gate=control),
        ToolEntry(hermes_session_job_result, gate=control),
    ]


def _vision_tools() -> list[ToolEntry]:
    return [ToolEntry(hermes_vision_analyze, gate=_env_gate(ENABLE_VISION_ENV))]


def _web_tools() -> list[ToolEntry]:
    gate = _env_gate(ENABLE_WEB_ENV)
    return [ToolEntry(hermes_web_search, gate=gate), ToolEntry(hermes_web_extract, gate=gate)]


def _finance_tools() -> list[ToolEntry]:
    # Lazy: the finance gate also reads the Hermes data root marker.
    return [
        ToolEntry(
            hermes_finance_analyze,
            gate=lambda: op_finance.finance_enabled(_default_hermes_root()),
        ),
    ]


def _jev_tools() -> list[ToolEntry]:
    # External typed judgments are opt-in and never alter Operator authority.
    gate = lambda: jev_bridge.enabled()  # noqa: E731
    return [
        ToolEntry(jev_bridge.hermes_jev_yes_no, gate=gate, annotations=_jev_annotations()),
        ToolEntry(jev_bridge.hermes_jev_choose, gate=gate, annotations=_jev_annotations()),
        ToolEntry(jev_bridge.hermes_jev_score, gate=gate, annotations=_jev_annotations()),
    ]


def _review_assist_tools() -> list[ToolEntry]:
    # Advisory review assist (v0.15): default OFF. Needs both the Jev gate and
    # HERMES_GPT_REVIEW_ASSIST=1. The score is advisory and never evidence.
    return [
        ToolEntry(
            hermes_review_assess,
            gate=lambda: op_review_assist.enabled(),
            annotations=ToolAnnotations(
                title="Advisory Jev review score for a Work Contract (never evidence)",
                readOnlyHint=True,
                destructiveHint=False,
                idempotentHint=False,
                openWorldHint=True,
            ),
        ),
    ]


# --- Operator / Owner Mode tools ---------------------------------------------
#
# Read-only tools are always registered. Mutating tools are registered
# unconditionally too (per spec: "register with refusal so the user can see why
# unavailable") — the wrappers return a JSON error string when the operator
# policy is not enabled / level is insufficient / apply_mode is dry_run / owner
# ack is missing.


def _operator_tools() -> list[ToolEntry]:
    return _plain(
        hermes_operator_policy,
        hermes_operator_status,
        hermes_operator_audit_tail,
        hermes_operator_doctor,
        hermes_operator_snapshot,
        hermes_release_doctor,
        hermes_operator_recover,
    ) + [
        ToolEntry(
            hermes_swarm_reconcile,
            annotations=ToolAnnotations(
                title="Reconcile state after a restart (dry-run by default; apply requires workspace + direct)"
            ),
        ),
    ]


def _fleet_tools() -> list[ToolEntry]:
    # Fleet routing: named peers in the local authenticated A2A registry only.
    return _plain(
        hermes_fleet_list,
        hermes_fleet_status,
        hermes_fleet_dispatch,
        hermes_fleet_dispatch_work_order,
        hermes_fleet_task,
        hermes_fleet_result,
        hermes_fleet_authority_drift,
    )


def _cron_tools() -> list[ToolEntry]:
    return _plain(
        hermes_cron_list,
        hermes_cron_status,
        hermes_cron_create,
        hermes_cron_run,
        hermes_cron_pause,
        hermes_cron_copy,
        hermes_cron_move,
    )


def _mission_control_tools() -> list[ToolEntry]:
    # Mission Control (v0.6 M0): read-only operational view. Each surface
    # enforces HERMES_GPT_MISSION_ALLOWED_SURFACES and audits every call.
    return _plain(
        hermes_mission_overview,
        hermes_mission_health,
        hermes_mission_profiles,
        hermes_mission_fleet,
        hermes_mission_codex,
        hermes_mission_cron,
        hermes_mission_delegations,
        hermes_mission_failures,
        hermes_mission_approvals,
        hermes_mission_vault,
        hermes_mission_usage,
        hermes_mission_audit,
    )


def _owner_inbox_tools() -> list[ToolEntry]:
    # Owner inbox (v0.15): read-only projection. Acknowledging hides an item only;
    # it is gated internally (workspace level plus direct apply; dry run default).
    return [
        ToolEntry(
            hermes_owner_inbox,
            annotations=ToolAnnotations(
                title="List work waiting on the Owner (read-only)",
                readOnlyHint=True,
                destructiveHint=False,
                idempotentHint=True,
                openWorldHint=False,
            ),
        ),
        ToolEntry(
            hermes_owner_inbox_ack,
            annotations=ToolAnnotations(
                title="Hide Owner-inbox items by id (workspace direct; dry run by default)",
                readOnlyHint=False,
                destructiveHint=False,
                idempotentHint=True,
                openWorldHint=False,
            ),
        ),
    ]


def _attention_tools() -> list[ToolEntry]:
    # Attention relay status (v0.16): registered only when the relay is enabled.
    # Read-only and never sends a message.
    return [
        ToolEntry(
            hermes_attention_delivery_status,
            gate=lambda: op_attention_delivery.enabled(),
            annotations=ToolAnnotations(
                title="Attention delivery relay status (read-only; sends nothing)",
                readOnlyHint=True,
                destructiveHint=False,
                idempotentHint=True,
                openWorldHint=False,
            ),
        ),
    ]


def _mission_runtime_tools() -> list[ToolEntry]:
    # Durable Mission runtime (v0.9). Authority is enforced by
    # operator_mission_runtime; final approval is Owner-gated.
    return _plain(
        hermes_mission_create,
        hermes_mission_get,
        hermes_mission_list,
        hermes_mission_update,
        hermes_mission_attach,
        hermes_mission_reconcile,
        hermes_mission_transition,
        hermes_mission_approve,
    )


def _plan_tools() -> list[ToolEntry]:
    # MissionPlan (additive DAG). Mutations touch only the plan store.
    return [
        *_plain(
            hermes_plan_create,
            hermes_plan_get,
            hermes_plan_list,
            hermes_plan_validate,
            hermes_plan_decompose,
            hermes_plan_review,
            hermes_plan_node_transition,
        ),
        # Owner-only gate approval (v0.16.1): dry run by default, Owner Mode for any write.
        ToolEntry(
            hermes_plan_approve_gate,
            annotations=ToolAnnotations(
                title="Owner approval of a gated plan node to completed (dry run by default; Owner Mode)",
                readOnlyHint=False,
                destructiveHint=False,
                idempotentHint=False,
                openWorldHint=False,
            ),
        ),
        *_plain(hermes_plan_set_status),
    ]


def _budget_tools() -> list[ToolEntry]:
    # Mission budget envelope (Phase-2 dry-run slice).
    return _plain(
        hermes_budget_set,
        hermes_budget_get,
        hermes_budget_check,
        hermes_budget_record,
    )


def _placement_tools() -> list[ToolEntry]:
    # Deterministic placement scoring (D7): dry-run only.
    return _plain(
        hermes_placement_score,
        hermes_placement_candidates,
        hermes_placement_get,
        hermes_placement_list,
    )


def _failure_tools() -> list[ToolEntry]:
    # Semantic failure classification and recovery matrix: decision output only.
    return _plain(
        hermes_failure_classify,
        hermes_failure_taxonomy,
        hermes_recovery_matrix,
        hermes_controller_plan_list,
    )


def _controller_tools() -> list[ToolEntry]:
    # Supervised mission controller: read-only surfaces and a single-pass shadow
    # reconcile that never dispatches, completes or approves.
    return _plain(
        hermes_controller_reconcile,
        hermes_controller_status,
        hermes_controller_lease_list,
        hermes_controller_trigger,
    )


def _autopilot_tools() -> list[ToolEntry]:
    # Autopilot (v0.13) — default OFF. Registered only when HERMES_GPT_AUTOPILOT=1.
    # See docs/autopilot.md.
    gate = _env_gate(op_autopilot.AUTOPILOT_ENV)
    return [
        ToolEntry(hermes_autopilot_start, gate=gate),
        ToolEntry(hermes_autopilot_status, gate=gate),
        ToolEntry(hermes_autopilot_stop, gate=gate),
        # One-call launch (v0.16): same machine gate as the Autopilot tools.
        ToolEntry(
            hermes_mission_launch,
            gate=gate,
            annotations=ToolAnnotations(
                title="One-call Mission launch (dry run by default; apply needs confirm and direct workspace)",
                readOnlyHint=False,
                destructiveHint=False,
                idempotentHint=False,
                openWorldHint=False,
            ),
        ),
    ]


def _events_tools() -> list[ToolEntry]:
    # Event history (v0.7 S4) and live events. readOnlyHint is advisory for
    # client-side filtering; it is not authority and never gates a call.
    return [
        ToolEntry(
            hermes_events_query,
            annotations=ToolAnnotations(
                title="Query the normalized Hermes GPT event timeline",
                readOnlyHint=True,
            ),
        ),
        ToolEntry(
            hermes_events_tail,
            annotations=ToolAnnotations(
                title="Tail recent Hermes GPT events across allowed sources",
                readOnlyHint=True,
            ),
        ),
        ToolEntry(
            hermes_live_events_cursor,
            annotations=ToolAnnotations(
                title="Read the durable v0.9 live-event cursor",
                readOnlyHint=True,
            ),
        ),
        ToolEntry(
            hermes_live_events_since,
            annotations=ToolAnnotations(
                title="Read or wait for durable v0.9 live events",
                readOnlyHint=True,
            ),
        ),
    ]


def _ledger_tools() -> list[ToolEntry]:
    # Derived capability manifest and per-mission ledger: read-only views.
    return [
        ToolEntry(
            hermes_capability_manifest,
            annotations=ToolAnnotations(
                title="Query the derived capability manifest (read-only)",
                readOnlyHint=True,
            ),
        ),
        ToolEntry(
            hermes_mission_ledger,
            annotations=ToolAnnotations(
                title="Query the merged, replayable per-mission ledger (read-only)",
                readOnlyHint=True,
            ),
        ),
        ToolEntry(
            hermes_mission_ledger_replay,
            annotations=ToolAnnotations(
                title="Replay a mission's full ledger event history (read-only)",
                readOnlyHint=True,
            ),
        ),
    ]


def _oauth_tools() -> list[ToolEntry]:
    # Trusted-client OAuth (v0.7 S5): status is read-only; revoke is owner-gated.
    return [
        ToolEntry(
            hermes_oauth_status,
            annotations=ToolAnnotations(
                title="Durable OAuth token store status",
                readOnlyHint=True,
            ),
        ),
        ToolEntry(
            hermes_oauth_revoke,
            annotations=ToolAnnotations(
                title="Revoke durable OAuth tokens",
                destructiveHint=True,
            ),
        ),
    ]


def _contract_tools() -> list[ToolEntry]:
    # Work Contracts (v0.6 M1): dispatch enforces workspace level, dry-run-first
    # and confirm gates; validate enforces D6 test gating internally.
    return _plain(
        hermes_contract_define,
        hermes_contract_dispatch,
        hermes_contract_validate,
        hermes_contract_status,
    )


def _runner_tools() -> list[ToolEntry]:
    # Pluggable execution backends: list/status read-only; cancel is gated.
    return _plain(hermes_runner_list, hermes_runner_status, hermes_runner_cancel)


def _job_tools() -> list[ToolEntry]:
    # Runner-neutral durable job status. The wait tool carries the polling contract.
    return [
        ToolEntry(
            hermes_job_status,
            annotations=ToolAnnotations(
                title="Read durable background-job status and log cursor",
                readOnlyHint=True,
            ),
        ),
        ToolEntry(
            hermes_job_wait,
            annotations=ToolAnnotations(
                title="Wait up to 120 seconds for a background job to finish",
                readOnlyHint=True,
            ),
        ),
    ]


def _delegation_tools() -> list[ToolEntry]:
    # Unified delegation lifecycle (v0.9). Underlying authority gates are preserved.
    return _plain(
        hermes_delegation_dispatch,
        hermes_delegation_get,
        hermes_delegation_list,
        hermes_delegation_reconcile,
        hermes_delegation_cancel,
    )


def _review_accept_tools() -> list[ToolEntry]:
    # Review-evidence writer (v0.7 S3): owner-gated, distinct reviewer.
    return [
        ToolEntry(
            hermes_review_accept,
            annotations=ToolAnnotations(
                title="Accept a review verdict for a Work Contract"
            ),
        ),
    ]


def _swarm_tools() -> list[ToolEntry]:
    # Swarm Orchestration (v0.6 M2): each tool enforces its own gates and audits.
    return _plain(
        hermes_swarm_workflow_create,
        hermes_swarm_workflow_list,
        hermes_swarm_workflow_status,
        hermes_swarm_workflow_validate,
        hermes_swarm_stage_dispatch,
        hermes_swarm_stage_advance,
        hermes_swarm_approve,
    )


def _skill_tools() -> list[ToolEntry]:
    return _plain(
        hermes_skill_diff,
        hermes_skill_create,
        hermes_skill_edit,
        hermes_skill_patch,
        hermes_skill_write_file,
        hermes_skill_copy,
        hermes_skill_sync_to_default,
        hermes_skill_delete,
    )


def _config_tools() -> list[ToolEntry]:
    return _plain(
        hermes_config_get,
        hermes_config_set,
        hermes_config_patch,
        hermes_env_status,
        hermes_env_set_nonsecret,
        hermes_env_copy_nonsecret,
    )


def _workspace_owner_tools() -> list[ToolEntry]:
    # Gateway / workspace / git / owner.
    return _plain(
        hermes_gateway_status,
        hermes_gateway_restart,
        hermes_workspace_read,
    ) + [
        ToolEntry(
            hermes_export_file,
            annotations=ToolAnnotations(
                title="Export an authorized local file as an MCP embedded resource",
                readOnlyHint=True,
            ),
        ),
    ] + _plain(
        hermes_workspace_patch,
        hermes_workspace_write_file,
        hermes_workspace_run_test,
        hermes_git_status,
        hermes_git_diff,
        hermes_owner_run_command,
        hermes_owner_patch,
        hermes_owner_write_file,
    )


def _codex_tools() -> list[ToolEntry]:
    return _plain(
        hermes_codex_status,
        hermes_codex_plan,
        hermes_codex_start,
        hermes_codex_review_start,
        hermes_codex_jobs,
        hermes_codex_job_status,
        hermes_codex_job_result,
        hermes_codex_cancel,
    )


def _tool_groups() -> list[tuple[str, list[ToolEntry]]]:
    """Ordered registration groups. Order here is the registration order."""
    return [
        ("core", _core_tools()),
        ("write", _write_tools()),
        ("terminal", _terminal_tools()),
        ("session_search", _session_search_tools()),
        ("session_control", _session_control_tools()),
        ("vision", _vision_tools()),
        ("web", _web_tools()),
        ("finance", _finance_tools()),
        ("jev", _jev_tools()),
        ("review_assist", _review_assist_tools()),
        ("operator", _operator_tools()),
        ("fleet", _fleet_tools()),
        ("cron", _cron_tools()),
        ("mission_control", _mission_control_tools()),
        ("owner_inbox", _owner_inbox_tools()),
        ("attention_delivery", _attention_tools()),
        ("mission_runtime", _mission_runtime_tools()),
        ("plan", _plan_tools()),
        ("budget", _budget_tools()),
        ("placement", _placement_tools()),
        ("failure", _failure_tools()),
        ("controller", _controller_tools()),
        ("autopilot", _autopilot_tools()),
        ("events", _events_tools()),
        ("ledger", _ledger_tools()),
        ("oauth", _oauth_tools()),
        ("contract", _contract_tools()),
        ("runner", _runner_tools()),
        ("job", _job_tools()),
        ("delegation", _delegation_tools()),
        ("review_accept", _review_accept_tools()),
        ("swarm", _swarm_tools()),
        ("skill", _skill_tools()),
        ("config", _config_tools()),
        ("workspace_owner", _workspace_owner_tools()),
        ("codex", _codex_tools()),
    ]


def register_tools(server: FastMCP) -> None:
    # Connector tool profile (HERMES_GPT_TOOL_PROFILE). Invalid values raise
    # ValueError here so build_server fails closed at startup. "full" (the
    # default) registers into the server unchanged; other profiles only skip
    # tools and never bypass the env gates in the groups above.
    profile = tool_profiles.profile_from_env()
    if profile != tool_profiles.FULL_PROFILE:
        server = tool_profiles.ProfileFilteredServer(server, profile)  # type: ignore[assignment]
    tool_registry.register(server, _tool_groups(), meta_factory=tool_meta)



def _codex_gateway_diagnostics() -> dict[str, Any]:
    """Combine the general doctor with the state-file-aware gateway status."""
    def decoded(value: Any) -> Any:
        if isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return value
        return value

    return {
        "operator_doctor": decoded(hermes_operator_doctor()),
        # operator_workspace has the gateway_state.json fallback required for
        # macOS installs when gateway.pid is stale or absent.
        "gateway_status": decoded(hermes_gateway_status()),
    }


def build_codex_mcp_server(
    *,
    host: str = "127.0.0.1",
    port: int = 7677,
    http: bool = False,
) -> FastMCP:
    """Build the deliberately compact Codex-facing MCP registry.

    The existing ``build_server`` remains the backwards-compatible legacy
    surface.  Codex gets only the high-leverage tools defined in codex_mcp.
    """
    from codex_core import CodexToolCore
    from codex_mcp import build_codex_server

    def imports_ready() -> bool:
        return IMPORT_ERROR is None and HERMES_ROOT is not None

    core = CodexToolCore(
        version=CODEX_BATCH_VERSION,
        imports_ready=imports_ready,
        gateway_snapshot=lambda: hermes_gateway_status(),
        gateway_diagnostics_callback=_codex_gateway_diagnostics,
        vision_analyze=lambda image_path, prompt: hermes_vision_analyze(image_url=image_path, question=prompt),
        web_search=lambda query, limit: hermes_web_search(query=query, limit=limit),
        web_extract=lambda urls, limit: hermes_web_extract(urls=urls, char_limit=limit),
        cron_create_callback=lambda schedule, prompt, dry_run: hermes_cron_create(schedule=schedule, prompt=prompt, dry_run=dry_run),
        skill_create_callback=lambda name, content, dry_run: hermes_skill_create(name=name, content=content, dry_run=dry_run),
    )
    operator_tools = {
        "hermes_operator_policy": hermes_operator_policy,
        "hermes_operator_status": hermes_operator_status,
        "hermes_operator_audit_tail": hermes_operator_audit_tail,
        "hermes_operator_doctor": hermes_operator_doctor,
        "hermes_operator_snapshot": hermes_operator_snapshot,
        "hermes_release_doctor": hermes_release_doctor,
        "hermes_operator_recover": hermes_operator_recover,
        "hermes_operator_cron_list": hermes_cron_list,
        "hermes_operator_cron_status": hermes_cron_status,
        "hermes_operator_cron_run": hermes_cron_run,
        "hermes_operator_cron_pause": hermes_cron_pause,
        "hermes_operator_cron_create": hermes_cron_create,
        "hermes_operator_cron_copy": hermes_cron_copy,
        "hermes_operator_cron_move": hermes_cron_move,
        "hermes_operator_skill_list": hermes_skill_list,
        "hermes_operator_skill_view": hermes_skill_view,
        "hermes_operator_skill_diff": hermes_skill_diff,
        "hermes_operator_skill_create": hermes_skill_create,
        "hermes_operator_skill_edit": hermes_skill_edit,
        "hermes_operator_skill_patch": hermes_skill_patch,
        "hermes_operator_skill_write_file": hermes_skill_write_file,
        "hermes_operator_skill_copy": hermes_skill_copy,
        "hermes_operator_skill_sync_to_default": hermes_skill_sync_to_default,
        "hermes_operator_skill_delete": hermes_skill_delete,
        "hermes_operator_config_get": hermes_config_get,
        "hermes_operator_config_set": hermes_config_set,
        "hermes_operator_config_patch": hermes_config_patch,
        "hermes_operator_env_status": hermes_env_status,
        "hermes_operator_env_set_nonsecret": hermes_env_set_nonsecret,
        "hermes_operator_env_copy_nonsecret": hermes_env_copy_nonsecret,
        "hermes_operator_gateway_status": hermes_gateway_status,
        "hermes_operator_gateway_restart": hermes_gateway_restart,
    }
    return build_codex_server(core, host=host, port=port, http=http, operator_tools=operator_tools)


mcp = build_server()


def _run_codex_mcp(argv: list[str]) -> None:
    parser = argparse.ArgumentParser(prog="hermes-gpt mcp", description="Run the Hermes GPT Codex MCP server.")
    parser.add_argument("--http", action="store_true", help="Run streamable HTTP instead of stdio.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7677)
    args = parser.parse_args(argv)
    server = build_codex_mcp_server(host=args.host, port=args.port, http=args.http)
    if not args.http:
        eprint("hermes-gpt Codex MCP server starting in stdio mode.")
        server.run(transport="stdio")
        return
    eprint(f"hermes-gpt Codex MCP server running at http://{args.host}:{args.port}/mcp")
    import uvicorn

    # No forwarded_allow_ips override: uvicorn defaults to loopback-only
    # proxy trust (or the operator-set FORWARDED_ALLOW_IPS env). A wildcard
    # here would trust client-supplied X-Forwarded-For from any peer
    # (security review t_f9925699 hardening note).
    uvicorn.run(server.streamable_http_app(), host=args.host, port=args.port, proxy_headers=True)


def _run_legacy_server(argv: list[str]) -> None:
    parser = argparse.ArgumentParser(description="Hermes Agent MCP sidecar.")
    parser.add_argument("--http", action="store_true", help="Run streamable HTTP transport instead of stdio.")
    parser.add_argument("--sse", action="store_true", help="Run legacy SSE transport instead of stdio.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7677)
    parser.add_argument("--cert", help="Path to SSL certificate file (enables HTTPS)")
    parser.add_argument("--key", help="Path to SSL key file (enables HTTPS)")
    parser.add_argument(
        "--profile",
        choices=[LOCAL_DEV_PROFILE, REMOTE_PROFILE],
        default=LOCAL_DEV_PROFILE,
        help="Release safety profile. Remote mode requires authentication unless unsafe no-auth is explicitly acknowledged.",
    )
    parser.add_argument(
        UNSAFE_REMOTE_ACK,
        action="store_true",
        dest="unsafe_remote_ack",
        help="Allow remote profile without auth. For experiments only; not release-safe.",
    )
    args = parser.parse_args(argv)

    if args.http and args.sse:
        raise SystemExit("Choose only one of --http or --sse.")
    configured_auth = auth_enabled()
    proxy_headers, forwarded_allow_ips = authenticated_http_security_options(
        profile=args.profile,
        host=args.host,
        cert=args.cert,
        key=args.key,
        configured_auth=configured_auth,
    )
    remote_unsafe_noauth = args.unsafe_remote_ack and env_enabled(UNSAFE_REMOTE_ENV)
    if args.profile == REMOTE_PROFILE and not (configured_auth or remote_unsafe_noauth):
        raise SystemExit(
            "Remote profile requires real authentication. Configure a static bearer token or confidential-client OAuth. "
            f"For temporary experiments only, pass {UNSAFE_REMOTE_ACK} and set {UNSAFE_REMOTE_ENV}=1."
        )
    if args.profile == LOCAL_DEV_PROFILE and not is_loopback_host(args.host) and not configured_auth:
        eprint(
            "WARNING: local-dev profile is bound to a non-loopback host. "
            "Do not expose hermes-gpt without real authentication."
        )
    if args.profile == REMOTE_PROFILE and remote_unsafe_noauth and not configured_auth:
        eprint("WARNING: remote no-auth mode is explicitly unsafe and intended only for temporary experiments.")

    transport = "streamable-http" if args.http else "sse" if args.sse else "stdio"
    server = build_server(host=args.host, port=args.port, http=args.http)
    if transport == "stdio":
        eprint("hermes-gpt MCP server starting in stdio mode.")
        server.run(transport="stdio")
    else:
        path = "/mcp" if args.http else "/sse"
        eprint(f"hermes-gpt MCP server running at http://{args.host}:{args.port}{path}")

        # Run with uvicorn instead of FastMCP.run() so TLS can be enabled for
        # local-only testing when cert/key are provided.
        import uvicorn
        app = build_asgi_app(server, http=args.http)
        _register_fleet_local_card()

        uvicorn.run(
            app,
            host=args.host,
            port=args.port,
            ssl_certfile=args.cert if args.cert else None,
            ssl_keyfile=args.key if args.key else None,
            proxy_headers=proxy_headers,
            forwarded_allow_ips=forwarded_allow_ips,
        )


def main(argv: list[str] | None = None) -> None:
    """Run legacy MCP, the Codex MCP alias, or the Codex installer helpers."""
    args = list(sys.argv[1:] if argv is None else argv)
    if args and args[0] == "mcp":
        if "HERMES_AGENT_ROOT" in os.environ:
            require_imports()
        _run_codex_mcp(args[1:])
        return
    if args and args[0] == "update":
        import updater

        updater.main(args[1:])
        return
    if args and args[0] == "codex":
        if len(args) > 1 and args[1] == "mcp":
            if "HERMES_AGENT_ROOT" in os.environ:
                require_imports()
            _run_codex_mcp(args[2:])
            return
        import codex_config

        def list_tools() -> list[str]:
            return [tool.name for tool in asyncio.run(build_codex_mcp_server().list_tools())]

        def status() -> dict[str, Any]:
            try:
                data = json.loads(hermes_gateway_status())
                return {
                    "ok": bool(data.get("success")),
                    "gateway": "running" if data.get("gateway_running") else "not_running",
                    "gateway_pid_source": data.get("gateway_pid_source"),
                }
            except Exception:
                return {"ok": False, "gateway": "unknown"}

        codex_config.main(args[1:], list_tools=list_tools, status=status)
        return
    if "HERMES_AGENT_ROOT" in os.environ:
        require_imports()
    _run_legacy_server(args)


if __name__ == "__main__":
    main()
