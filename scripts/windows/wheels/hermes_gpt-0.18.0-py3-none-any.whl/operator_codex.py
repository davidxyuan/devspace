"""Asynchronous, policy-gated Codex CLI jobs for trusted Operator clients."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import threading
from datetime import datetime, timezone, timedelta
from typing import Any
from uuid import uuid4

import operator_job_supervisor as job_supervisor
import operator_policy as op

ENABLE_CODEX_RUNNER_ENV = "HERMES_GPT_ENABLE_CODEX_RUNNER"
ALLOW_CODEX_WRITE_ENV = "HERMES_GPT_ALLOW_CODEX_WRITE"
CODEX_EXE_ENV = "HERMES_GPT_CODEX_EXE"
WINDOWS_APPS_MARKER = "WindowsApps"
CODEX_PROBE_TIMEOUT = 10
MAX_RESULT_CHARS = 24_000
MIN_TIMEOUT = 10
MAX_TIMEOUT = 3600
_MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$")
_SHA_RE = re.compile(r"^[0-9a-fA-F]{7,64}$")
_lock = threading.RLock()
RETENTION_DAYS = 30


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _root(hermes_root: Path | None = None) -> Path:
    base = op.normalize_hermes_data_root(hermes_root or Path(os.environ.get("HERMES_HOME", Path.home() / ".hermes")))
    return Path(base or Path.home() / ".hermes") / "codex-jobs"


def _paths(job_id: str, hermes_root: Path | None = None) -> tuple[Path, Path]:
    root = _root(hermes_root)
    return root / f"{job_id}.json", root / f"{job_id}.jsonl"


def _request_path(job_id: str, hermes_root: Path | None = None) -> Path:
    return _root(hermes_root) / f"{job_id}.request.json"


def _save_request(job_id: str, value: dict[str, Any], hermes_root: Path | None = None) -> None:
    path = _request_path(job_id, hermes_root)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    try:
        temp.chmod(0o600)
    except OSError:
        pass
    temp.replace(path)


def _safe_error(code: str, message: str, action: str) -> dict[str, Any]:
    return op.make_error_envelope(layer="operator", code=code, safe_message=message, suggested_action=action)


def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _redact(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_redact(v) for v in value)
    if isinstance(value, str):
        return op.redact_output(value)
    return value


def _normalize_execution_mode(execution_mode: str) -> str | dict[str, Any]:
    mode = str(execution_mode or "normal").strip().lower()
    if mode not in {"normal", "nolo"}:
        return _safe_error("INVALID_EXECUTION_MODE", "execution_mode must be normal or nolo.", "Choose normal or nolo.")
    return mode


def _save(meta: dict[str, Any], hermes_root: Path | None = None) -> None:
    path, _ = _paths(meta["job_id"], hermes_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(meta, indent=2, sort_keys=True), encoding="utf-8")
    temp.replace(path)


def _load(job_id: str, hermes_root: Path | None = None) -> dict[str, Any] | None:
    if not re.fullmatch(r"[0-9a-f]{32}", job_id or ""):
        return None
    path, _ = _paths(job_id, hermes_root)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def _policy(workdir: str, sandbox: str, execution_mode: str = "normal", *, confirm: bool, dry_run: bool) -> tuple[op.OperatorPolicy, Path, str] | dict[str, Any]:
    policy = op.OperatorPolicy()
    try:
        policy.require_level("workspace")
        policy.require_workspace_path(workdir)
    except (PermissionError, ValueError) as exc:
        return _safe_error("POLICY_REFUSED", str(exc), "Enable Operator workspace level and approve the work directory.")
    mode = _normalize_execution_mode(execution_mode)
    if isinstance(mode, dict):
        return mode
    if sandbox not in {"read-only", "workspace-write"}:
        return _safe_error("INVALID_SANDBOX", "sandbox must be read-only or workspace-write.", "Choose a supported Codex sandbox.")
    if not op.env_truthy(ENABLE_CODEX_RUNNER_ENV):
        return _safe_error("RUNNER_DISABLED", "Codex runner execution is disabled.", f"Set {ENABLE_CODEX_RUNNER_ENV}=1.")
    if sandbox == "workspace-write" and not op.env_truthy(ALLOW_CODEX_WRITE_ENV):
        return _safe_error("WRITE_DISABLED", "Codex write-capable execution is disabled.", f"Set {ALLOW_CODEX_WRITE_ENV}=1 or use read-only mode.")
    if not dry_run and (not confirm or policy.apply_mode != "direct"):
        return _safe_error("DIRECT_CONFIRMATION_REQUIRED", "Execution requires direct apply mode and confirm=true.", "Review the plan, set direct mode, and retry with confirm=true and dry_run=false.")
    if policy.level == "owner" and not policy.owner_mode_ready:
        return _safe_error("OWNER_ACK_REQUIRED", "Configured Owner Mode is not acknowledged.", f"Set {op.OWNER_ACK_ENV} to the documented acknowledgement.")
    return policy, Path(workdir).expanduser().resolve(), mode


def _is_protected_windows_apps(path: Path) -> bool:
    """True when a path component is the protected WindowsApps directory."""
    return any(part.lower() == WINDOWS_APPS_MARKER.lower() for part in path.parts)


def _probe_codex_version(exe: Path) -> str | None:
    """Return the Codex CLI version string, or None when it cannot launch."""
    try:
        result = subprocess.run([str(exe), "--version"], text=True, capture_output=True, shell=False, timeout=CODEX_PROBE_TIMEOUT, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    return (result.stdout or result.stderr or "").strip()


def _path_candidates() -> list[Path]:
    """All `codex` candidates from PATH in order, deduplicated by resolved path."""
    seen: set[str] = set()
    candidates: list[Path] = []
    for entry in os.environ.get("PATH", "").split(os.pathsep):
        if not entry:
            continue
        found = shutil.which("codex", path=entry)
        if not found:
            continue
        try:
            candidate = Path(found).expanduser().resolve(strict=True)
        except OSError:
            continue
        key = os.path.normcase(str(candidate))
        if key in seen:
            continue
        seen.add(key)
        candidates.append(candidate)
    return candidates


def resolve_codex_exe() -> dict[str, Any]:
    """Resolve a launchable Codex CLI executable for status checks and launches.

    Priority: an explicit ``HERMES_GPT_CODEX_EXE`` override (validated: absolute
    file path, exists, is a regular file, not a protected WindowsApps shim, and
    passes a ``codex --version`` probe), then the first PATH candidate that is
    neither protected nor unlaunchable. Returns:
    ``{"path", "source" ("env"|"path"|"none"), "version", "reason", "skipped"}``
    where ``path`` is None when no launchable executable could be found.
    """
    override = os.environ.get(CODEX_EXE_ENV, "").strip()
    if override:
        try:
            candidate = Path(override).expanduser().resolve(strict=True)
        except OSError as exc:
            return {"path": None, "source": "env", "version": None,
                    "reason": f"{CODEX_EXE_ENV} does not resolve to an existing file: {exc}", "skipped": []}
        if not candidate.is_file():
            return {"path": None, "source": "env", "version": None,
                    "reason": f"{CODEX_EXE_ENV} is not a regular file: {candidate}", "skipped": []}
        if _is_protected_windows_apps(candidate):
            return {"path": None, "source": "env", "version": None,
                    "reason": f"{CODEX_EXE_ENV} points into the protected {WINDOWS_APPS_MARKER} directory and cannot be launched.",
                    "skipped": []}
        version = _probe_codex_version(candidate)
        if version is None:
            return {"path": None, "source": "env", "version": None,
                    "reason": f"{CODEX_EXE_ENV} exists but could not be executed (version probe failed).", "skipped": []}
        return {"path": str(candidate), "source": "env", "version": version, "reason": None, "skipped": []}

    skipped: list[str] = []
    for candidate in _path_candidates():
        if _is_protected_windows_apps(candidate):
            skipped.append(str(candidate))
            continue
        version = _probe_codex_version(candidate)
        if version is None:
            skipped.append(str(candidate))
            continue
        return {"path": str(candidate), "source": "path", "version": version, "reason": None, "skipped": skipped}
    reason = "No launchable Codex CLI executable was found on PATH."
    if skipped:
        reason += f" Skipped {len(skipped)} protected or unlaunchable candidate(s): " + ", ".join(skipped) + "."
    return {"path": None, "source": "none", "version": None, "reason": reason, "skipped": skipped}


def _argv(*, workdir: Path, sandbox: str, execution_mode: str, prompt: str, model: str | None, ignore_user_config: bool,
          review: bool = False, review_target: str = "uncommitted") -> list[str] | dict[str, Any]:
    resolution = resolve_codex_exe()
    if not resolution["path"]:
        return _safe_error("CODEX_EXE_UNAVAILABLE", resolution["reason"] or "No launchable Codex CLI executable was found.",
                           f"Install the standalone Codex CLI, or set {CODEX_EXE_ENV} to an absolute path outside {WINDOWS_APPS_MARKER}.")
    codex = resolution["path"]
    argv = [codex]
    if execution_mode == "nolo" and not review:
        # Approval policy is a top-level Codex option in 0.147.0; `codex exec`
        # does not accept -a/--ask-for-approval in its subcommand arguments.
        argv += ["-a", "never"]
    argv.append("exec")
    if review:
        argv += ["review", "--json", "--ephemeral"]
        if review_target == "uncommitted":
            argv.append("--uncommitted")
        elif review_target.startswith("base:") and re.fullmatch(r"base:[A-Za-z0-9._/-]{1,128}", review_target):
            argv += ["--base", review_target[5:]]
        elif review_target.startswith("commit:") and _SHA_RE.fullmatch(review_target[7:]):
            argv += ["--commit", review_target[7:]]
        else:
            return _safe_error("INVALID_REVIEW_TARGET", "Review target must be uncommitted, base:<branch>, or commit:<sha>.", "Choose exactly one supported review target.")
    else:
        argv += ["--json", "--ephemeral", "-C", str(workdir), "-s", sandbox]
    if model:
        if not _MODEL_RE.fullmatch(model):
            return _safe_error("INVALID_MODEL", "model contains unsupported characters.", "Use a configured model identifier without flags or whitespace.")
        argv += ["--model", model]
    if ignore_user_config:
        argv += ["-c", "mcp_servers={}"]
    if prompt:
        argv.append(prompt)
    return argv


def hermes_codex_status(hermes_root: Path | None = None) -> dict[str, Any]:
    _reconcile(hermes_root)
    policy = op.OperatorPolicy()
    resolution = resolve_codex_exe()
    status: dict[str, Any] = {
        "success": True,
        "enabled": op.env_truthy(ENABLE_CODEX_RUNNER_ENV),
        "write_enabled": op.env_truthy(ALLOW_CODEX_WRITE_ENV),
        "operator_enabled": policy.enabled,
        "operator_level": policy.level,
        "apply_mode": policy.apply_mode,
        "codex_available": resolution["path"] is not None,
        "codex_path": resolution["path"],
        "codex_source": resolution["source"],
        "jobs_root": str(_root(hermes_root)),
    }
    if resolution["version"]:
        status["codex_version"] = resolution["version"]
    if resolution["reason"]:
        status["codex_reason"] = resolution["reason"]
    if resolution["skipped"]:
        status["codex_skipped"] = list(resolution["skipped"])
    return status


def hermes_codex_plan(prompt: str, workdir: str, sandbox: str = "read-only", model: str | None = None,
                      ignore_user_config: bool = False, timeout: int = 900, review: bool = False,
                      review_target: str = "uncommitted", execution_mode: str = "normal") -> dict[str, Any]:
    return _start(prompt, workdir, sandbox, model, ignore_user_config, timeout, False, True, execution_mode, review, review_target, None)


def _start(prompt: str, workdir: str, sandbox: str, model: str | None, ignore_user_config: bool, timeout: int,
           confirm: bool, dry_run: bool, execution_mode: str, review: bool, review_target: str, hermes_root: Path | None) -> dict[str, Any]:
    checked = _policy(workdir, sandbox, execution_mode, confirm=confirm, dry_run=dry_run)
    if isinstance(checked, dict):
        return checked
    _, resolved, execution_mode = checked
    timeout = max(MIN_TIMEOUT, min(int(timeout), MAX_TIMEOUT))
    built = _argv(workdir=resolved, sandbox=sandbox, execution_mode=execution_mode, prompt=prompt, model=model, ignore_user_config=ignore_user_config, review=review, review_target=review_target)
    if isinstance(built, dict):
        return built
    sanitized_argv = ["<prompt>" if item == prompt and prompt else item for item in built]
    plan = {"success": True, "dry_run": dry_run, "mode": "review" if review else "task", "workdir": str(resolved),
            "sandbox": sandbox, "execution_mode": execution_mode, "model": model, "timeout": timeout, "argv": sanitized_argv,
            "prompt_len": len(prompt), "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest()}
    if dry_run:
        return _redact(plan)
    job_id = uuid4().hex
    meta = {**plan, "job_id": job_id, "status": "queued", "created_at": _now(), "started_at": None,
            "ended_at": None, "pid": None, "return_code": None, "thread_id": None, "cancel_requested": False}
    meta.pop("argv", None)
    path, output = _paths(job_id, hermes_root)
    _save(meta, hermes_root)
    _save_request(job_id, {"argv": built, "workdir": str(resolved), "timeout": timeout}, hermes_root)
    job_supervisor.register_job(
        job_id,
        backend="codex",
        workspace=resolved,
        log_path=output,
        source_record=path,
        hermes_root=hermes_root,
    )
    try:
        proc = subprocess.Popen(
            [sys.executable, str(Path(__file__).resolve()), "--worker", job_id, "--root", str(_root(hermes_root))],
            cwd=resolved,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
            shell=False,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0,
            start_new_session=os.name != "nt",
        )
    except (OSError, ValueError) as exc:
        try:
            _request_path(job_id, hermes_root).unlink()
        except OSError:
            pass
        meta.update({"status": "failed", "ended_at": _now()})
        _save(meta, hermes_root)
        job_supervisor.terminalize(job_id, "failed", summary=op.redact_output(str(exc)), hermes_root=hermes_root)
        return _safe_error("CODEX_START_FAILED", op.redact_output(str(exc)), "Check Codex CLI installation, authentication, and model configuration.")
    # The detached worker owns durable Codex metadata transitions. The parent
    # records only the canonical process identity so a fast worker cannot finish
    # and then be overwritten back to running by this MCP server process.
    job_supervisor.mark_running(job_id, proc.pid, hermes_root=hermes_root)
    op.audit_record(tool="hermes_codex_review_start" if review else "hermes_codex_start", level=checked[0].level,
                    apply_mode=checked[0].apply_mode, dry_run=False, success=True, changed=True, job_id=job_id,
                    path=str(resolved), prompt=prompt, extra={"mode": meta["mode"], "sandbox": sandbox,
                    "execution_mode": execution_mode, "model": model or ""})
    return _redact({"success": True, "dry_run": False, "job_id": job_id, "status": "running", "execution_mode": execution_mode})


def hermes_codex_start(prompt: str, workdir: str, sandbox: str = "read-only", model: str | None = None,
                       ignore_user_config: bool = False, timeout: int = 900, confirm: bool = False,
                       dry_run: bool = True, hermes_root: Path | None = None, execution_mode: str = "normal") -> dict[str, Any]:
    return _start(prompt, workdir, sandbox, model, ignore_user_config, timeout, confirm, dry_run, execution_mode, False, "uncommitted", hermes_root)


def hermes_codex_review_start(workdir: str, target: str = "uncommitted", instructions: str = "", model: str | None = None,
                              ignore_user_config: bool = False, timeout: int = 900, confirm: bool = False,
                              dry_run: bool = True, hermes_root: Path | None = None) -> dict[str, Any]:
    return _start(instructions, workdir, "read-only", model, ignore_user_config, timeout, confirm, dry_run, "normal", True, target, hermes_root)


def hermes_codex_jobs(limit: int = 50, hermes_root: Path | None = None) -> dict[str, Any]:
    _reconcile(hermes_root)
    jobs = []
    for path in sorted(_root(hermes_root).glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:max(1, min(limit, 200))]:
        try:
            jobs.append(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            continue
    return _redact({"success": True, "count": len(jobs), "jobs": jobs})


def hermes_codex_job_status(job_id: str, hermes_root: Path | None = None) -> dict[str, Any]:
    _reconcile(hermes_root)
    meta = _load(job_id, hermes_root)
    return _redact({"success": True, "job": meta}) if meta else _safe_error("JOB_NOT_FOUND", "Codex job was not found.", "Check the job ID with hermes_codex_jobs.")


def hermes_codex_job_result(job_id: str, max_chars: int = MAX_RESULT_CHARS, hermes_root: Path | None = None) -> dict[str, Any]:
    _reconcile(hermes_root)
    meta = _load(job_id, hermes_root)
    if not meta:
        return _safe_error("JOB_NOT_FOUND", "Codex job was not found.", "Check the job ID with hermes_codex_jobs.")
    _, output = _paths(job_id, hermes_root)
    latest, usage, thread_id = "", None, meta.get("thread_id")
    try:
        for line in output.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            thread_id = event.get("thread_id") or event.get("threadId") or thread_id
            if event.get("usage") is not None:
                usage = event["usage"]
            message = event.get("message") or event.get("text")
            item = event.get("item")
            if isinstance(item, dict) and item.get("type") in {"agent_message", "message"}:
                message = item.get("text") or item.get("content") or message
            if isinstance(message, str):
                latest = message
    except OSError:
        pass
    cap = max(500, min(int(max_chars), MAX_RESULT_CHARS))
    latest = op.redact_output(latest)
    truncated = len(latest) > cap
    latest = latest[:cap]
    return _redact({"success": True, "status": meta.get("status"), "return_code": meta.get("return_code"),
                                "execution_mode": meta.get("execution_mode", "normal"), "thread_id": thread_id,
                                "usage": usage, "response": latest, "truncated": truncated})


def _terminate(proc: subprocess.Popen[str]) -> None:
    if os.name == "nt":
        try:
            completed = subprocess.run(
                ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
                check=False,
            )
            if completed.returncode == 0:
                return
        except (OSError, subprocess.TimeoutExpired):
            pass
        proc.kill()
        return
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        proc.wait(timeout=3)
    except Exception:
        proc.kill()


def _worker(job_id: str, jobs_root: Path) -> int:
    hermes_root = jobs_root.parent
    request_path = jobs_root / f"{job_id}.request.json"
    meta = _load(job_id, hermes_root) or {"job_id": job_id}
    try:
        request = json.loads(request_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        meta.update({"status": "failed", "ended_at": _now(), "return_code": None})
        _save(meta, hermes_root)
        try:
            job_supervisor.terminalize(job_id, "failed", summary="Codex worker request missing", hermes_root=hermes_root)
        except FileNotFoundError:
            pass
        return 2
    try:
        request_path.unlink()
    except OSError:
        pass
    argv = request.get("argv")
    workdir = request.get("workdir")
    if not isinstance(argv, list) or not argv or not all(isinstance(item, str) for item in argv) or not isinstance(workdir, str):
        meta.update({"status": "failed", "ended_at": _now(), "return_code": None})
        _save(meta, hermes_root)
        job_supervisor.terminalize(job_id, "failed", summary="Codex worker request invalid", hermes_root=hermes_root)
        return 2
    timeout = max(MIN_TIMEOUT, min(int(request.get("timeout") or 900), MAX_TIMEOUT))
    meta.update({"status": "running", "started_at": meta.get("started_at") or _now(), "pid": os.getpid()})
    _save(meta, hermes_root)
    try:
        job_supervisor.mark_running(job_id, os.getpid(), hermes_root=hermes_root)
    except FileNotFoundError:
        pass
    _, output = _paths(job_id, hermes_root)
    output.parent.mkdir(parents=True, exist_ok=True)
    status = "failed"
    return_code: int | None = None
    try:
        with output.open("w", encoding="utf-8") as out_handle:
            proc = subprocess.Popen(
                argv,
                cwd=Path(workdir).expanduser().resolve(),
                stdout=out_handle,
                stderr=subprocess.STDOUT,
                text=True,
                shell=False,
            )
            try:
                proc.wait(timeout=timeout)
                return_code = proc.returncode
                status = "completed" if proc.returncode == 0 else "failed"
            except subprocess.TimeoutExpired:
                _terminate(proc)
                return_code = proc.poll()
                status = "timed_out"
    except Exception as exc:  # noqa: BLE001
        status = "failed"
        return_code = None
        meta["worker_error"] = op.redact_output(str(exc))[:500]
    canonical = job_supervisor.terminalize(
        job_id,
        status,
        returncode=return_code,
        summary=meta.get("worker_error") or "",
        hermes_root=hermes_root,
    )
    meta = _load(job_id, hermes_root) or meta
    meta.update(
        {
            "status": canonical.get("status", status),
            "return_code": return_code,
            "ended_at": canonical.get("ended_at") or _now(),
            "cancel_requested": bool(canonical.get("cancel_requested")),
        }
    )
    _save(meta, hermes_root)
    return int(return_code or 0) if status == "completed" else 1


def _reconcile(hermes_root: Path | None = None) -> None:
    """Reconcile persisted Codex metadata from the durable job supervisor."""
    root = _root(hermes_root)
    if not root.exists():
        return
    cutoff = datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)
    for path in root.glob("*.json"):
        if path.name.endswith(".request.json"):
            continue
        try:
            meta = json.loads(path.read_text(encoding="utf-8"))
            created = datetime.fromisoformat(str(meta.get("created_at", "")).replace("Z", "+00:00"))
        except (OSError, ValueError, TypeError):
            continue
        job_id = str(meta.get("job_id", ""))
        if created < cutoff and meta.get("status") not in {"queued", "starting", "running"}:
            try:
                path.unlink()
                _, output = _paths(job_id, hermes_root)
                output.unlink(missing_ok=True)
            except OSError:
                pass
            continue
        if meta.get("status") in {"queued", "starting", "running"}:
            observed = job_supervisor.get_job(job_id, hermes_root=hermes_root, reconcile=True)
            if not observed:
                continue
            observed_status = str(observed.get("status") or "")
            if observed_status in job_supervisor.TERMINAL_STATES:
                meta.update(
                    {
                        "status": observed_status,
                        "return_code": observed.get("returncode"),
                        "ended_at": observed.get("ended_at") or _now(),
                        "cancel_requested": bool(observed.get("cancel_requested")),
                    }
                )
            elif observed.get("reconciliation"):
                meta["reconciliation"] = observed["reconciliation"]
            _save(meta, hermes_root)


def hermes_codex_cancel(job_id: str, confirm: bool = False, dry_run: bool = True, hermes_root: Path | None = None) -> dict[str, Any]:
    meta = _load(job_id, hermes_root)
    if not meta:
        return _safe_error("JOB_NOT_FOUND", "Codex job was not found.", "Check the job ID with hermes_codex_jobs.")
    checked = _policy(str(meta.get("workdir", "")), str(meta.get("sandbox", "read-only")),
                      str(meta.get("execution_mode", "normal")), confirm=confirm, dry_run=dry_run)
    if isinstance(checked, dict):
        return checked
    if dry_run:
        return {"success": True, "dry_run": True, "job_id": job_id, "would_cancel": meta.get("status") == "running"}
    result = job_supervisor.request_cancel(job_id, hermes_root=hermes_root)
    if not result.get("success"):
        return _safe_error(
            str(result.get("code") or "JOB_CANCEL_FAILED"),
            str(result.get("safe_message") or "Codex job process could not be safely cancelled."),
            "Refresh durable job status and retry only if process identity can be verified.",
        )
    refreshed = _load(job_id, hermes_root) or meta
    if result.get("changed"):
        refreshed.update(
            {
                "status": result.get("status") or "cancelled",
                "ended_at": _now(),
                "cancel_requested": True,
            }
        )
    elif result.get("status"):
        refreshed["status"] = result["status"]
    _save(refreshed, hermes_root)
    return {
        "success": True,
        "dry_run": False,
        "job_id": job_id,
        "status": refreshed.get("status"),
        "changed": bool(result.get("changed")),
    }


def _main(argv: list[str]) -> int:
    if len(argv) >= 3 and argv[1] == "--worker":
        job_id = argv[2]
        if not re.fullmatch(r"[0-9a-f]{32}", job_id or ""):
            return 2
        jobs_root = _root()
        if len(argv) >= 5 and argv[3] == "--root":
            jobs_root = Path(argv[4]).expanduser().resolve()
        return _worker(job_id, jobs_root)
    return 2


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv))
